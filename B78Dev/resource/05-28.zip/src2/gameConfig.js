var MH = MH || {};
MH.gameConfig = {
	VERSION : "1.0.5",
	APPNAME : "slotvip",
	BASE_URL : "https://daohoa.github.io/B78/resource"
};