var MH = MH || {};
MH.gameConfig = {
	VERSION : "1.0.10", // for web || mobile reset from manifest
	APPNAME : "slotvip",
	BASE_URL : "https://daohoa.github.io/B78/resource/"
};