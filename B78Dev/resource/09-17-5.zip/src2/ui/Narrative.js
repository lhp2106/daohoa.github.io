var Narrative = cc.Node.extend({
	ctor: function(size, textContents){
		this._super();
		this.setPosition(0, 0);

		if (!size) size = cc.size(220, 53);

		this.textContents = textContents;

		var bg = new ccui.Scale9Sprite("#button/dialog.png", cc.rect(0, 0, 0, 0));
	    bg.setContentSize(size.width, size.height);
	    bg.setPosition(cc.p2(cc.Global.GameView.width / 2 - bg.width/2, - bg.height/2 + cc.Global.GameView.height / 2));
	    this.addChild(bg);
	    this.bg = bg;

	    this.label = new cc.LabelTTF('', MH.getFont("Font_Default"), 32, null, cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_CENTER);

	    this.label.setAnchorPoint(.5,.5);
	    this.label.setPosition(cc.p2(size.width / 2, size.height / 2));
	    bg.addChild(this.label);
	},
	hideLine: function(){
		this.visible = false;
	},
	showLine: function(lineId){
		this.visible = true;
    	this.label.setString(this.textContents[lineId]);
	},
	showText: function(text){
		this.visible = true;
    	this.label.setString(text);
	},
	showTextKeCua: function(text, opacity){
		if(!opacity) opacity =255;
	},
	showTextRich: function (text, opacity) {
		if(!opacity) opacity =255;
	}
});