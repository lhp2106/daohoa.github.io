var CountDownNode = cc.Node.extend({
	ctor: function(size){
		this._super();
		this.setPosition(0, 0);
		this.numberRemain = 0;

		if( !size ) size = cc.size(550, 60);

		// var bg = new PIXI.mesh.NineSlicePlane(PIXI.Texture.fromFrame("button/dialog.png"), 5, 5, 5, 5);
		var bg = new ccui.Scale9Sprite("#button/dialog.png", cc.rect(0, 0, 0, 0));
	    // bg.width = size.width;
	    // bg.height = size.height;
	    bg.setContentSize(size.width, size.height);
	    bg.setPosition(cc.p2(cc.Global.GameView.width / 2  - bg.width/2, - bg.height/2 + cc.Global.GameView.height / 2));
	    this.addChild(bg);
	    this.bg = bg;

	    this.lblPointResult = new cc.LabelTTF('Ván chơi bắt đầu sau           giây', MH.getFont("Font_Default"), 32, cc.size(550, 60), cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_CENTER);
	    this.lblPointResult.setAnchorPoint(0.5, 0.5);
	    this.lblPointResult.setPosition(cc.p2(size.width / 2, bg.height / 2 + 0));
	    bg.addChild(this.lblPointResult);

	    // this.numRemain = new cc.LabelBmtFont("5","font_do");
	    this.numRemain = new newui.LabelBMFont("5", "res/fonts_new/font_do.fnt", cc.TEXT_ALIGNMENT_LEFT);

	    this.numRemain.setPosition(cc.p2(size.width / 2 + 110, size.height / 2 - 45));
	    bg.addChild(this.numRemain);
	},
	hide: function(){
		this.visible = false;
	},
	showWithTime: function(time){
		this.visible = true;
    	this.showTimeCountDown(time);
	},
	showTimeCountDown: function (timeInSeconds, maxTime){
		if (!maxTime) maxTime = timeInSeconds;
	    var thiz = this;
	    thiz.timeRemain = timeInSeconds;
	    thiz.numRemain.setString("" + Math.floor(this.timeRemain));

	    var timeRemain = timeInSeconds * (timeInSeconds / maxTime);

	    if(this.timerAction){
	        this.timerAction.stop();
	        this.timerAction.remove();
	        this.timerAction = null;
	    }
	    this.timerAction  = new hiepnh.ActionTimer(timeInSeconds, function (dt) {

	        //var timeRemain = (1.0 - dt) * startValue;//
	        timeRemain -= dt;
	        if (timeRemain <= 0) {
	            thiz.visible = false;
	        }
	        thiz.numRemain.text = "" + Math.floor(timeRemain);
	        //cc.log("percent "+thiz.timer.getPercentage() );
	    });

	    cc.director.getScheduler().unscheduleAllForTarget(this);

	    cc.director.getScheduler().schedule(function(){
			timeRemain -=1;
			if (timeRemain < 0) {
	            this.visible = false;
	            cc.director.getScheduler().unscheduleAllForTarget(this);
	        }else{
	        	this.numRemain.setString("" + Math.floor(timeRemain));
	        }
		}.bind(this), this, 1, false);
	}
});