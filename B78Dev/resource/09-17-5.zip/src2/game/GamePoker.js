/**
 * Created by kk on 5/29/2017.
 */

var state_poker = state_poker || {};
state_poker.SHAPCARD = 0;
state_poker.UP_BAI = 1;
state_poker.THEO = 2;
state_poker.XEM = 3;
state_poker.TO = 4;
state_poker.XA_LANG = 5;
state_poker.DANG_CO_LUOT = 6;

var POKER_PLAYER_STATE = {
    SHAPCARD: 0,
    UP_BAI: 1,
    THEO: 2,
    XEM: 3,
    TO: 4,
    XA_LANG: 5,
    DANG_CO_LUOT: 6
};

var POKER_CMD = {
    CMD_WITHDRAW: 699,
    CMD_WITHDRAW_FOR_SIT: 755,
    CMD_AUTO_READY  : 204,
    CMD_CHIA_BAI:750,
    CMD_END_GAME: 752,
    CMD_ON_COUNT_DOWN : 754,
    CMD_CHOSE_CARD_SHOW : 805,//SEND CHON cay bai tẩy
    CMD_SHOW_CARD : 802,//show cay bai tẩy (khi hết thời gian mà tất cả chưa lật xong)
    CMD_CHANGE_TURN: 751,
    CMD_STAND_UP: 756,
    CMD_TO: 757,
    CMD_THEO: 758,
    CMD_UP_BAI: 759,
    CMD_XEM_BAI: 760,
    CMD_NEW_ROUND: 753
};

var GamePoker = GameScene.extend({ //
	ctor: function(dataGame){
		this._super(dataGame);
		this.setPosition(0, 0);
		this.roomID = LobbyClient.getInstance().getCurrentRoomId();
	    this.registerQuit = false;
	    this.totalPlayerPlaying = 0;
	    this.selectedCards = [];
	    this.playerPlayed =[];
	    this.data = dataGame;
	    this.type = "GamePoker";

	    this.countDownNode = new CountDownNode();
	    this.countDownNode.displayGroup = MyPixi.gameContainerLayer;
	    this.countDownNode.y += 50;
	    MyPixi.gameContainer.addChild(this.countDownNode);
	    this.countDownNode.visible = false;

	    var texts = [
        	"Nặn bài"
	    ];
	    this.lblNarrativeResult = new Narrative(cc.size(180,52), texts);
	    this.lblNarrativeResult.y += 130;
	    this.lblNarrativeResult.displayGroup = MyPixi.gameContainerLayer;
	    MyPixi.gameContainer.addChild(this.lblNarrativeResult);
	    this.lblNarrativeResult.visible = false;

	    // this.init();
	    this.registerQuit=false;
	    this.currentTurn = 0;
	    this.ideGameNumber = 0;
	    this.IDE_GAME_KICK = 3;
	    //

	    this.initDialog();
	    this.initGame();
	},
	// init: function(){},
	initGame: function(){
		var data = this.data;
	    this.timeTurn = 20000;//data.tft;
	    this.shapeTime = 10000;
	    this.tfeg = data.tfeg / 1000;//time4endgame
	    // gS == 3 la dang dem nguoc => ko change to playing
	    //if (data.gS === GAME_STATE.CHIA_BAI) data.gS = GAME_STATE.PLAYING;
	    var gameState = data.gS;//GAME_STATE.WAIT_PLAYER;
	    this.gameState = gameState;
	    this.aid = data.aid;

	    this.initPlayer();
	    this.initButton();
	    this.initCardContainer();
	    this.updateGame(this.data);
	},
	initDialog: function(){
		//8 : standupoRqUIT
	    //4: WithdrawMoney
	    //5 : RaiseMoney
	    //6 :ShapCardShow
	    //7: UserInfoDialog : CLICK AVATAR
	    this.dialogs = [];
	    this.dialogWithdrawMoney = new WithdrawMoneyDialog(this);
	    this.dialogWithdrawMoney.show(false);
	    this.dialogRaiseMoney = new RaiseMoney(this);
	    this.dialogRaiseMoney.show(false);
	    this.dialogShapCardShow = new ChoseCardShow(this);
	    //this.dialogShapCardShow.init([0,1,2], [0,0,1]);
	    this.dialogShapCardShow.show(false);

	    var thiz = this;
	    this.dialogStandUpQuit = new MessageConfirmDialog();
	    MyHelper.addLblButton(this.dialogStandUpQuit.okButton, "Đứng lên", 16);
	    MyHelper.addLblButton(this.dialogStandUpQuit.cancelButton, "Rời bàn", 16);
	    this.dialogStandUpQuit.setMessage("Bạn muốn đứng lên hay thoát bàn?");
	    this.dialogStandUpQuit.okButtonHandler = function(){
	        thiz.onStandUp();
	        //dialog.hide();
	    };
	    this.dialogStandUpQuit.cancelButtonHandler = function(){
	        //quit room
	        thiz.quitRoom();
	        //dialog.hide();
	    };
	    this.dialogStandUpQuit.hide = function(){
	        if(thiz.dialogStandUpQuit.parent){
	            thiz.dialogStandUpQuit.stopAllActions();

	            var scaleAction =  cc.scaleTo(0.2, 0);
	            var ac = cc.sequence(scaleAction, cc.callFunc(function(){
	                thiz.dialogStandUpQuit.visible = false;
	            }));
	            thiz.dialogStandUpQuit.runAction(thiz.dialogStandUpQuit.bgHide, ac);
	        }
	    }
	    this.dialogStandUpQuit.show(false);
	},
	updateGame: function(data){
		cc.log("updateGame "+JSON.stringify(data));
	    var thiz = this;
	    this.betValue = data.b;
	    this.currentBet = data.cb;
	    this.timeEndGame = data.tfeg;
	    this.maxPlayer = data.Mu;
	    this.mMBI = data.mMBI;
	    this.MMBI = data.MMBI;
	    var gameState = data.gS;
	    this.gameState = gameState;
	    var remainTime = data.rmT;///1000;//time danh bai cua player co turn hien tai
	    var players = data.ps;
	    var listPlayer = data.ps;
	    this.arrangePlayerInGame();
	    this.players = data.ps;

	    if(gameState == GAME_STATE.PLAYING || gameState === 5){
	        if(!data.re){
	            var pots = data.pots;
	            if(pots && pots.length){
	                thiz.initPotsData(pots);
	            }
	            var dealerUid = data.D;
	            var snallBlinderUid = data.sb;
	            var bigBlinderUid = data.bb;
	            var cardShow = data.cmc;
	            this.chiabaiNewRound(cardShow);
	            /*if(cardShow){
	                var cards = [];
	                for (var k = 0; k < cardShow.length; k++) {
	                    cards.push(Utils.getCardFromServer(cardShow[k]));
	                }
	                thiz.cardOnTable.dealCards(cards, false, CardAlign.LEFT);
	            }*/

	            var isShapCardTime = true;
	            this.setStatePlayer(PlayerMe.uid, state_player.DANG_XEM);
	            thiz.isViewing = true;
	            MH.showMessage("Bàn đang chơi. Vui lòng chờ");
	            cc.each(thiz.allSlot, function(slot, index){
	                if( slot != null){
	                   slot.showDealer(slot.uid === dealerUid);
	                    for(var i= 0 ; i < players.length; i++){
	                        var p = players[i];
	                        if( slot.uid == p.uid){
	                            var cardArray = p.cs ? p.cs : [] ;
	                            var isRoomMaster = p.C;
	                            var playerState = p.pS;
	                            var pi = p.pi;//dang choi hay ngoi xem
	                            var rr = p.rr;
	                            var currentBet = p.cb;
	                            if(pi){

	                                if(p.uid == PlayerMe.uid){
	                                    //MY PLAYER la view=> se ko vao duoc day
	                                }else{
	                                    //oponent ko co card tra ve, fix tam, khi show result se update lai card cua no tu server
	                                    if(!cardArray.length){
	                                        //chua lat cay nao trong 2 cay dau`
	                                        cardArray.unshift(0);//adds one or more elements to the beginning of an array
	                                        cardArray.unshift(0);
	                                        slot.cardList.onAddCardArray(slot, cardArray, null, false);
	                                    }else{
	                                        slot.cardList.onAddCardArray(slot, cardArray, fc);
	                                    }
	                                }
	                                if(currentBet && currentBet > 0){
	                                    thiz.tossChip( slot.uid, currentBet, true, false);
	                                }


	                                if(playerState === POKER_PLAYER_STATE.SHAPCARD){//===0
	                                    thiz.onUpdateTurn(slot.uid, remainTime,isShapCardTime);
	                                }else{

	                                    if(playerState === POKER_PLAYER_STATE.DANG_CO_LUOT){//===6
	                                        thiz.onUpdateTurn(slot.uid, remainTime);
	                                    }else if(playerState >0 && playerState < POKER_PLAYER_STATE.DANG_CO_LUOT){
	                                        //slot.showStatePlayer(playerState);
	                                        thiz.setStatePlayerGameTo(slot.uid, playerState);
	                                    }
	                                }

	                            }else{
	                                //another viewer
	                                thiz.setStatePlayer(slot.uid, state_player.DANG_XEM);
	                                //slot.showViewerText(true);
	                            }
	                            continue;

	                        }
	                    }

	                }

	            });
	        }

	    }

	    cc.each(listPlayer, function(value, index){
	        if(value.C ==true){
	            thiz.idRoomMaster = index;
	        }
	    });
	    if(data.re){
	        this.isPlaying = true;
	        this.onReconnect(data);
	        if(this.isPlaying) this.getSlotByUid(PlayerMe.uid).showRutTienBtn(false);

	    }else{
	        this.currentBet = 0;//this.betValue;
	    }
	},
	onReconnect: function(data){
		var thiz =  this;
	    thiz.meSitDown = true;
	    var listPlayer = data.ps;
	    var gameState = data.gS;
	    thiz.gameState = data.gS;
	    var pots = data.pots;
	    var mb = data.mb;
	    var remainTime = data.rmT;//time danh bai cua player co turn hien tai
	    // cc.log('remainTime '+remainTime);

	    var isReconnect = true;
	    var isShapCardTime = true;
	    var fi = data;

	    var dealerUid = data.D;
	    var snallBlinderUid = data.sb;
	    var bigBlinderUid = data.bb;
	    var cardShow = data.cmc;
	    this.chiabaiNewRound(cardShow);

	    for(var i= 0 ; i < listPlayer.length; i++){
	        if(listPlayer.pS !==0) {
	            isShapCardTime =false;
	            break;
	        }
	    }
	    if(pots && pots.length){
	        thiz.initPotsData(pots);
	    }

	    cc.each(thiz.allSlot, function(slot, index){
	        if(slot){
	            //slot.onShowBtnWhenPlaying(false);//hide ready chb, kick icon
	            slot.showDealer(slot.uid === dealerUid);
	            for(var i= 0 ; i < listPlayer.length; i++){
	                var p = listPlayer[i];
	                if(slot.uid === p.uid){
	                    var cardArray = p.cs ? p.cs : [];
	                    var faceCard = p.fc;
	                    var currentBet = p.cb;
	                    var isRoomMaster = p.C;
	                    var playerState = p.pS;
	                    var pi = p.pi;//dang choi hay ngoi xem

	                    if(pi){
	                        thiz.totalPlayerPlaying++;
	                        //slot.showReadyChbox(false);

	                        if(slot.uid === PlayerMe.uid ){
	                            thiz.currentBet = currentBet;

	                            if(playerState === POKER_PLAYER_STATE.DANG_CO_LUOT){//===6
	                                thiz.turnButtons.showAll(true);
	                            }else{
	                                thiz.turnButtons.showAll(false);
	                            }

	                            if(thiz.currentBet === mb){
	                                // show xem (not theo)
	                                thiz.turnButtons.showTextXem(true);
	                            }else{
	                                // show theo (not xem)
	                                thiz.turnButtons.showTextXem(false);
	                            }
	                            slot.cardList.onAddCardArray(slot, cardArray, faceCard);

	                            thiz.myCards = cardArray;
	                        }else{
	                            if(!cardArray.length){
	                                //chua lat cay nao trong 2 cay dau`
	                                cardArray.unshift(0);
	                                cardArray.unshift(0);
	                                slot.cardList.onAddCardArray(slot, cardArray, null, false);
	                            }else{
	                                slot.cardList.onAddCardArray(slot, cardArray,  null, false);
	                            }
	                            p.totalCard = cardArray.length ;
	                        }
	                        if(currentBet && currentBet > 0){
	                            thiz.tossChip( slot.uid, currentBet, true, false);
	                        }


	                        if(playerState === POKER_PLAYER_STATE.SHAPCARD && isShapCardTime){//===0
	                            //slot.activeTurnDuration(true, remainTime, isShapCardTime);
	                            thiz.onUpdateTurn(slot.uid, remainTime,isShapCardTime);

	                        }else{

	                            if(playerState === POKER_PLAYER_STATE.DANG_CO_LUOT){//===6
	                                //slot.activeTurnDuration(true, remainTime, false);
	                                thiz.onUpdateTurn(slot.uid, remainTime);
	                            }else if(playerState >0 && playerState < POKER_PLAYER_STATE.DANG_CO_LUOT){
	                                //slot.showStatePlayer(playerState);
	                                thiz.setStatePlayerLieng(slot.uid, playerState);
	                            }

	                        }

	                    }else{
	                        //viewer
	                        //var isViewer = true;
	                        //slot.showViewerText(true);
	                        thiz.setStatePlayer(slot.uid, state_player.DANG_XEM);

	                    }
	                    break;
	                }

	            }

	        }

	    });

	    thiz.changeSitToInviteBg();

	},
	initCardContainer: function(){
		this.potOnTable= [];
	    var  y = -cc.winSize.height + 70.0;
	    var startX = cc.winSize.width/2 - 600;
	    for(var i = 0 ; i < GameLieng.MAX_SLOT; i++){
	        var chipColumnPot = new ChipColumnList(cc.size(30, 100),.3, ChipColumnList.LBL_BOT);
	        chipColumnPot.setPosition(startX+ i*150, y);
	        chipColumnPot.displayGroup = MyPixi.chipLayer;
	        MyPixi.gameContainer.addChild(chipColumnPot);
	        if(TEST_MODE) chipColumnPot.showBlurBg(true);
	        this.potOnTable.push(chipColumnPot);
	    }
	    var list = [this.potOnTable[0], this.potOnTable[1], this.potOnTable[7], this.potOnTable[8]];
	    startX = cc.winSize.width/2 - 225;
	    for(var i = 0 ; i < list.length; i++){
	        list[i].setPosition(startX + i*150, y +25);
	        if(TEST_MODE) list[i].showBlurBg(true);
	    }

	    var pos = cc.p(cc.winSize.width /2 + 70, cc.winSize.height/2+20);
	    var cardOnTable = new PokerCardList(pos, cc.size(cc.winSize.width/2, 150));
	    cardOnTable.cardAlign = LiengCardList.ALIGN_LEFT;
	    cardOnTable.displayGroup = MyPixi.gameContainerLayer;
	    MyPixi.gameContainer.addChild(cardOnTable);
	    cardOnTable.setDeckPoint(cc.p(cc.winSize.width/2, cc.winSize.height/2 -200));
	    //cardOnTable.showBlurBg(true);
	    this.cardOnTable = cardOnTable;
	},
	changeSitToInviteBg: function(){
		var totalSit = 9;//tong so cho ngoi luon la 9 voi lieng
	    //cc.log("this.meSitDown "+this.meSitDown);
	    for(var i=0; i< this.playerView.length; i++){
	        var slot = this.playerView[i];
	        if(!slot.uid || slot.uid === "") {
	            // cc.log("changeToSmallBg");
	            slot.changeToSmallBg(this.meSitDown);
	            slot.showInfoLayer(false);
	        }
	    }
	},
	hideAllBtnPlay: function(){
		for(var i = 0 ; i < this.turnButtons.length; i++){
	        this.turnButtons[i].visible = false;
	    }
	},
	onUpdateTurn:  function(uid, currentTime, isTimeShapCard ){
		var timeTurn = this.timeTurn;
	    if(isTimeShapCard ) timeTurn = this.shapeTime;
	    for (var i = 0; i < this.allSlot.length; i++) {
	        if (this.allSlot[i].uid == uid) {
	            this.allSlot[i].showTimeRemain(currentTime,timeTurn);
	        }
	        else {
	            if(!isTimeShapCard) this.allSlot[i].stopTimeRemain();
	        }
	    }
	},
	handlePendingBack: function(){
		this.isPlaying =false;
	    this.isShowingResult =false;
	    if(this.registerQuit){
	        this.quitRoom();
	        return false;
	    }
	    this.resetNewGame();

	    if(this.ideGameNumber >= this.IDE_GAME_KICK   ){
	        this.ideGameNumber++ ;
	        this.quitRoom(true);
	        this.idleKick = true;
	        return false;
	    }
	    return true;
	},
	resetNewGame:  function (igNoreCheckReady) {
		this.isPlaying = false;
	    this.totalPlayerPlaying = 0;
	    this.isViewing = false;
	    this.lblNarrativeResult.hideLine();
	    this.gameState = GAME_STATE.WAIT_PLAYER;
	    this.data.gS = this.gameState;
	    for( var i=0; i< this.chipColumns.length; i++){
	        // delete chip and lbl money chip taij vi tri ko co player
	        this.chipColumns[i].onReset();
	    }

	    for( var i=0; i< this.potOnTable.length; i++){
	        // delete chip and lbl money chip taij vi tri ko co player
	        this.potOnTable[i].onReset();
	    }
	    this.cardOnTable.removeAll();

	    this.myCards =[];
	    this.currentBet = this.betValue;
	    this.maxBet = this.currentBet;
	    this.meUpBai = false;
	    this.showResultTotalTime = 0;
	    this.showResultBegin = 0;
	    this.dataResult ='';
	    this.isShowingResult = false;
	    this.isPlaying = false;
	    this.currentTurn = 0;
	    cc.log("reset----------------------------");
	    cc.each(this.data.ps, function(player, index){
	        player.pi = false;//update
	    });

	    for(var i=0;i<this.allSlot.length;i++){
	        this.allSlot[i].resetEndGame();
	        this.allSlot[i].cardList.removeAll();
	        this.allSlot[i].showDealer(false);
	    }
	    this.clearStatePlayer();// xoa dang xem neu vua vao1 xem de van moi mat di
	    this.arrangePlayerInGame();
	},
	_onRoomPluginMsg:  function (command, dataObj){
		//cc.log(command+ " _onRoomPluginMsg in GamePoker => "+ JSON.stringify(dataObj));
	    var cmd = dataObj[1][Constant.CONSTANT.CMD];
	    if (cmd == Constant.CMD_RESULT.ERROR) {
	        this.onErrorResponse(dataObj);
	    } else if (cmd == 7) {
	        this.onServerNotifyResponse(dataObj);
	    } else if (cmd == Constant.CMD_RESULT.USER_JOIN_OUT) {
	        this.onUserInOut(dataObj);
	        if(dataObj[1].t ===1) {//sitdown
	            if( dataObj[1].p.uid === PlayerMe.uid){
	                //send rut tien thanh cong thi close dilaog rut tien di
	                //self.dialogs[4].getComponent('WithdrawMoney').showDialog(false); pending
	                this.dialogWithdrawMoney.show(false);
	                if(this.gameState === 4 || this.gameState === 5){
	                    //dang choi hoac dang so ket qua
	                    //==> my player vao torng giai doan nay deu la viewer het
	                    this.isViewing = true;
	                }else{
	                    this.isViewing = false;
	                }
	                this.meSitDown = true;
	            }
	        }else if(dataObj[1].t ===2) {//standup
	            if( dataObj[1].p.uid === PlayerMe.uid){
	                this.meSitDown = false;
	                this.dialogStandUpQuit.hide();
	                if(this.playerView[0]){
	                    this.playerView[0].showRutTienBtn(false);
	                }
	                //cc.log(`stand thiz.meSitDown ${thiz.meSitDown}`);
	                if(this.gameState ===4 || this.gameState ===5){
	                    this.isViewing = true;
	                }
	            }
	        }
	        if(dataObj[1].p.uid === PlayerMe.uid || this.meSitDown){
	            this.changeSitToInviteBg();
	        }
	        if (this.data.ps.length === 1){
	            //stop dem nguoc
	            this.countDownNode.hide();
	        }
	    } else if (cmd == Constant.CMD_RESULT.ROOM_MASTER_CHANGE) {
	        this.onRoomMasterResponse(dataObj);

	    }else if(cmd ==  Constant.CMD_RESULT.LIST_INVITE){

	        this.onInviteResponse(dataObj);

	    } else if (cmd === 205) {
	        this.updateGoldAllPlayerFromServer(dataObj);

	    }else if(cmd === POKER_CMD.CMD_WITHDRAW){
	        this.onWithDrawResponse(dataObj[1]);
	    }else if(cmd === POKER_CMD.CMD_AUTO_READY) {
	        this.onAutoReadyResponse(dataObj);
	    }else if(cmd ==  POKER_CMD.CMD_CHIA_BAI){
	        this.chiabai(dataObj[1]);
	    }else if(cmd ==  POKER_CMD.CMD_END_GAME){//
	        this.onEndGame(dataObj[1]);
	    }else if(cmd ==  POKER_CMD.CMD_ON_COUNT_DOWN){
	        this.onCountDownResponse(dataObj);
	    }else if(cmd ==  POKER_CMD.CMD_SHOW_CARD){
	        this.onShowCard(dataObj);
	    }else if(cmd ==  POKER_CMD.CMD_CHANGE_TURN) {
	        this.onChangeTurn(dataObj);
	    }else if(cmd ===  POKER_CMD.CMD_NEW_ROUND){
	        // {"mb":0,"cmc":[24,37,27,6],"fP":{"uid":"483ce64e-6ed7-4e6f-bca2-08f27bcca5aa","pS":3,"dn":"fucker","m":18000,"cb":0},
	        // "pots":[{"id":1,"m":2000}],"cmd":753,"tP":{"uid":"7c4bf83d-1b35-433c-b0b3-2ed502981cdb","dn":"zzzzzzzzzzzzzzz"}}
	        cc.log('CMD_NEW_ROUND maxBet '+JSON.stringify(dataObj));
	        this.currentBet = 0;
	        this.onChangeTurn(dataObj);

	    }else if(cmd ==  Constant.CMD_RESULT.PLAYER_READY){
	        var uid = dataObj[1].uid;
	        //var displayName = dataObj[1].dn;
	        cc.each(this.data.ps, function(value, index){
	            if(value.uid == uid){
	                value.r = true;
	            }
	        });
	    }
	},
	onServerNotifyResponse:  function (dataObj) {
		//catch trong LobbyClient roi - o day chi la regist quit no nua thoi
	    // nen ko can show dialog
	    //pop up show error/ thong bao / bao tri
	    var type = dataObj[1].t;
	    if (type === 3) this.registerQuit = true; // bao tri
	    //pop up show error/ thong bao / bao tri
	    //var dialog = new MessageOkDialog();
	    //dialog.setMessage(dataObj[1].message);
	    //dialog.showWithAnimationScale();
	},
	onErrorResponse:  function (dataObj) {
		//{"c":101,"mgs":"","cmd":1}]
	    var errorCode = dataObj[1].c;
	    cc.log('cmd 1 error show showDialogNotice '+errorCode);
	    //{"c":305,"mgs":"Bạn không được đặt cược quá 100 lần mức cược","cmd":1}
	    var errorStr = Constant.ERROR_STR[errorCode] ?  Constant.ERROR_STR[errorCode] : dataObj[1].mgs;//Constant.ERROR_STR[errorCode];
	    if(errorStr === undefined) errorStr = "Hành động không hợp lệ (mã lỗi = "+errorCode + ")";

	    if(errorCode === 1000 ) errorStr ='Không còn chỗ trống để ngồi';
	    if(errorCode != 600 && errorCode != 750 && errorCode != 1000) return;
	    MH.showMessage(errorStr);
	},
	onRoomMasterResponse:  function (dataObj) {
		var newMasterUid = dataObj[1].uid;
	    cc.log("chu phong moi la " + dataObj[1].dn + " " + dataObj[1].uid);
	    cc.each(this.data.ps, function (value, index) {
	        if (value.uid == newMasterUid) {
	            value.C = true;
	            value.r = false;
	        } else {
	            value.C = false;
	        }
	    });

	    if (this.gameState === 4 || this.gameState === 5) {
	        //chu phong quit khi so ket qua thi ko lam gi
	        //doi so ket qua xong se co event arrangePlayerInGame
	    } else {
	        this.arrangePlayerInGame();
	    }
	},
	onInviteResponse:  function (dataObj) {
		var listUser = dataObj[1].us;
	    cc.log("LIST_INVITE " + JSON.stringify(listUser));
	    LoadingDialog.getInstance().hide();
	    if (!listUser || !listUser.length) {
	    	MH.showMessage("Không có người chơi để mời");
	    }else {
	        /*var dialog = new InviteDialog();
	         dialog.initData(listUser);
	         dialog.showWithAnimationScale();*/
	        this.showInviteDialog(listUser);
	    }
	},
	updateGoldAllPlayerFromServer:  function (dataObj) {
		var playerArr = dataObj[1].ps;
	    /*ps:Array = [
	     {
	     uid:String = USER_ID,
	     m:MOney= MONEYCAI
	     }
	     ]*/

	    if (playerArr) {
	        for (var idx in this.allSlot) {
	            var slot = this.allSlot[idx];
	            if (!slot) continue;
	            for (var i = 0; i < playerArr.length; i++) {
	                if (playerArr[i].uid === slot.uid) {
	                    this.updateRealMoneyPlayer(playerArr[i]);
	                    //slot.setTotalGoldWithEffect(playerArr[i].rM);
	                    //cc.log(playerArr[i].uid + 'update money ' + playerArr[i].m);
	                    break;
	                }
	            }
	        }
	    }
	},
	onWithDrawResponse:  function (data) {
		var thiz = this;
	    this.updateMoneyPlayer(data);
	    cc.each(this.allSlot, function(slot, index){
	        if(slot && slot.uid === data.uid){
	            slot.setTotalGoldWithEffect(data.m);
	            if(data.uid === PlayerMe.uid ){
	                //thiz.dialogs[4].getComponent('WithdrawMoney').showDialog(false); pending
	                thiz.dialogWithdrawMoney.show(false);
	            }
	        }
	    });
	},
	onAutoReadyResponse:  function(dataObj){
		cc.log("onAutoReadyResponse "+ JSON.stringify(dataObj));
	    cc.log('send ready');  //JsonArray = [5, zoneName:String, roomId:Int, params:JsonObject]
	    var sendObj = [
	        command.RoomPluginMessage,
	        Constant.CONSTANT.ZONE_NAME,
	        LobbyClient.getInstance().getCurrentRoomId(),
	        {'cmd':Constant.CMD_RESULT.PLAYER_READY}
	    ];
	    LobbyClient.getInstance().send(sendObj);
	},
	onCountDownResponse:  function(dataObj){
		cc.log("onCountDownResponse "+ JSON.stringify(dataObj));
	    this.checkLeaveRoomIfCan();

	    var timeCountDown = dataObj[1].T/1000;
	    cc.log(timeCountDown + " timeCountDown");
	    //this.clock.showTimeCountDown(timeCountDown);
	    var thiz = this;
	    cc.log("vao day nao");
	    thiz.resetNewGame();
	    thiz.arrangePlayerInGame();//prevent vao xem dung luk dang so kq roi
	    // => ko co anim show result => ko sap xep lai vi tri
	    var cb = function(){
	        thiz.requestStart();
	        thiz.countDownNode.hide();
	    };

	    this.countDownNode.showWithTime(timeCountDown);
	    this.runAction(cc.sequence(cc.delayTime(timeCountDown), cc.callFunc(cb)));
	},
	requestStart:  function(){
		cc.log('aaaa send 800 to server');  //JsonArray = [5, zoneName:String, roomId:Int, params:JsonObject]
	    //this.countDownNode.visible = false;
	    var sendObj = [
	        command.RoomPluginMessage,
	        Constant.CONSTANT.ZONE_NAME,
	        LobbyClient.getInstance().getCurrentRoomId(),
	        {'cmd':POKER_CMD.CMD_ON_COUNT_DOWN}
	    ];
	    LobbyClient.getInstance().send(sendObj);
	},
	onReadyResponse:  function (dataObj) {
		var uid = dataObj[1].uid;
	    var displayName = dataObj[1].dn;//
	    var isReady = true;
	    cc.log("onReadyResponse "+ JSON.stringify(dataObj));
	    cc.log("PLAYER_READY "+ uid + " => "  +displayName);
	    cc.each(this.data.ps, function(value, index){
	        if(value.uid == uid){
	            value.r = isReady;
	        }
	    });

	    if(isReady) this.setStatePlayer(uid, state_player.READY);
	    else this.setStatePlayer(uid, state_player.NOTHING);
	},
	onShowCard:  function(dataObj){
		//{"cs":[40,39],"uid":"483ce64e-6ed7-4e6f-bca2-08f27bcca5aa","cmd":709}
	    if(TEST_MODE){
	        dataObj = [5,{"ps":[{"cs":dataObj[1].cs,"uid":PlayerMe.uid,"dn":"benzamamu"}],"cmd":802}]

	    }
	    //[5,{"ps":[{"cs":32,"uid":"05577704-8592-4504-a77b-448d04780a7c","dn":"benzamamu"}],"cmd":802,"tP":{"cs":36,"uid":"6f24996a-4d40-47bd-a67c-fa8288b3253c","dn":"ongthantai7979"}}]
	    cc.log("onShowCard "+ JSON.stringify(dataObj));
	    var thiz = this;
	    var ps = dataObj[1].ps;
	    var tP = dataObj[1].tP;
	    if(tP){
	        ps.push(tP);
	        if(tP.uid === PlayerMe.uid){
	            thiz.turnButtons.showAll(true);
	            thiz.turnButtons.showAllAuto(false);
	            // show xem (not theo) , first turn of all player
	            thiz.turnButtons.showTextXem(true);
	            this.dialogShapCardShow.show(false);
	            this.dialogRaiseMoney.show(false);

	        }else{
	            if(!thiz.isViewing){
	                thiz.turnButtons.showAll(false);
	                thiz.turnButtons.showAllAuto(true);
	            }
	        }
	    }


	    var myUid = PlayerMe.uid;
	    cc.each(thiz.allSlot, function(slot, index){
	        if(slot){
	            thiz.changeTurnPlayer(tP, slot);
	            var actorUid = slot.uid;
	            cc.each(ps, function(player, index){
	                var senderUid = player.uid;
	                if(actorUid ===  senderUid){
	                    if(actorUid === myUid){
	                        //move  card ra vi tri dau tien va` blur card di
	                        thiz.dialogShapCardShow.show(false);
	                        thiz.meChoseCardShow = true;
	                        if( !hiepnh.isUndefined(player.cs)){ // if(player.cs) false if  player.cs = 0 or = false
	                            //http://stackoverflow.com/questions/5113374/javascript-check-if-variable-exists-is-defined-initialized
	                            var cardData = Utils.getCardFromServer(player.cs);
	                            //cc.log(`move card myplayer pos2 ${cardData.pointName}${cardData.suitName}`);
	                            slot.cardList.changeCardAndShow([player.cs], true);
	                        }
	                    }else{
	                        if( !hiepnh.isUndefined(player.cs)){ // if(player.cs) false if  player.cs = 0 or = false
	                           var cardData = Utils.getCardFromServer(player.cs);
	                            slot.cardList.changeCardAndShow([player.cs], false);
	                        }
	                    }
	                    slot.stopTimeRemain();
	                }
	            });

	        }
	    });
	    if(tP ){
	        thiz.onUpdateTurn(tP.uid, this.timeTurn);
	    }
	},
	tossChip:  function(uid, moneyToss , isReconnect, animation){
		if(cc.isUndefined(moneyToss)) moneyToss = 100;
	    if(cc.isUndefined(isReconnect)) isReconnect = false;
	    if(cc.isUndefined(animation)) animation = true;
	    //if(!isReconnect) audioMng.playTossChip();
	    //cc.log("tosschip sitID "+sitId);
	    var slot = this.getSlotByUid(uid);
	    var typeChip = this.getIdCoinImg(moneyToss/this.betValue);
	    var slotPos = slot.convertToWorldSpace(slot.getPosition()); //slot.getGlobalPosition();
	    slotPos.x += slot.widthBG/2;
	    slotPos.y += slot.heightBG/2;

	    var pos = this.chipColumns[slot.sitId].convertToNodeSpace(slotPos); // cc.convertToNodeSpace(this.chipColumns[slot.sitId], slotPos);
	    //cc.log("toss chip at sit "+sitId);
	    this.chipColumns[slot.sitId].show(true);
	    var animTime = this.chipColumns[slot.sitId].addNewChip([typeChip], moneyToss, animation, pos, 0.5);
	},
	onChangeTurn:  function(dataObj){
		cc.log("changeturn "+JSON.stringify(dataObj));
	    if(TEST_MODE){
	        pS = [];
	        for(var i = 0 ; i <5;i++){
	            pS.push({"cs":[32,46,1,12,13],"uid":this.allSlot[i].uid,"dn":"fucker","m":18250,"cb":0});
	        }
	        dataObj = [5,{"mb":2500,"fP":{"uid":PlayerMe.uid,"pS":4,"dn":"52haivip1","m":45726,"cb":2500},"cmd":803,
	            "pots":[{"id":1,"m":2000}],
	            "ps": pS,
	            "tP":{"uid":this.allSlot[1].uid,"dn":"fb_vanduong105"}}];

	    }
	    var thiz = this;
	    thiz.lblNarrativeResult.hideLine();
	    this.dialogRaiseMoney.show(false);
	    var mb = dataObj[1].mb;//số tiền cược lớn nhất của tất cả người
	    thiz.maxBet = mb;
	    var pS = dataObj[1].ps;
	    var cardShow =  dataObj[1].cmc;
	    var pots = dataObj[1].pots;//[{"id":1,"m":1000},...]
	    var tP = dataObj[1].tP;
	    if(tP && pS) pS.push(tP);
	    if(pS){
	        cc.each(thiz.players, function(p, i){
	            for(var j = 0 ; j< pS.length; j++){
	                if(p.uid == pS[j]){
	                    p.pi =true;
	                    break;
	                }
	            }
	        });
	    }else{
	        //turn dau tien sau khi chon cay bai tay
	        // if(tP) self.updateMoneyPlayer(tP);     
	        // if(fromPlayer) self.updateMoneyPlayer(fromPlayer);     

	    }
	    var fromPlayer = dataObj[1].fP;
	    if(fromPlayer){
	        cc.each(thiz.data.ps, function(p, i){
	            if(p.uid == fromPlayer.uid ){
	                p.pS =fromPlayer.pS;
	            }
	            if(tP && p.uid == tP.uid ){
	                // self.updateMoneyPlayer(pS);
	                p.pS =tP.pS;
	            }
	        });
	    }
	    if(fromPlayer && PlayerMe.uid == fromPlayer.uid){
	        thiz.currentBet  =fromPlayer.cb;
	    }
	    // active cac btn to, bao,...
	    thiz.turnButtons.showAll(false);
	    var isTossChip = false;
	    var newTurn = cardShow? true: false;
	    cc.each(thiz.allSlot, function(slot, index){
	        if(slot){
	            thiz.changeTurnPlayer(tP, slot);
	            if(fromPlayer.uid === slot.uid ){
	                isTossChip = thiz.updateFromPlayer(fromPlayer, slot, newTurn);//call truoc handleAutoPlay de set lai currentBet
	            }
	            thiz.handleAutoPlay(tP, slot, mb, false);
	        }
	    });

	    if(cardShow){
	        if(pots) this.gopChipNewRound(pots, isTossChip);
	        this.chiabaiNewRound(cardShow);
	        cc.each(this.allSlot, function(slot, index){
	            if(slot){
	                if(slot.getStatePlayer()!== state_poker.UP_BAI && slot.getStatePlayer()!== state_poker.XA_LANG){//ko phai up bai OR XA LANG
	                    //slot.showStatePlayer(-1);
	                    thiz.setStatePlayer(slot.uid, state_player.NOTHING);
	                }
	            }
	        });

	    }
	    cc.each(this.allSlot, function(slot, index){
	        if(tP && slot.uid == tP.uid){
	            if(slot.getStatePlayer()!== state_poker.UP_BAI && slot.getStatePlayer()!== state_poker.XA_LANG){//ko phai up bai OR XA LANG
	                //slot.showStatePlayer(-1);
	                thiz.setStatePlayer(slot.uid, state_player.NOTHING);
	            }

	        }
	    });

	   /* if(pS){
	        for(var j = 0 ; j< pS.length; j++){
	            if(PlayerMe.uid == pS[j].uid){
	                this.updateMoneyPlayer(pS[j]);
	                //cc.log(`---- newturn mymoney = ${self.getMoneyPlayer(globalData.getPlayerData().uid)} `);
	                break;
	            }
	        }
	    }*/

	    // updateMoneyPlayer call cuoi cung de dung money tinh ra addbet fromPlayer
	    this.updateMoneyPlayer(fromPlayer);
	    if(tP && tP.uid === PlayerMe.uid){
	        if(this.getMaxRaise() <=0 ){
	            //tien con lai <= to them cua payer # => chi theo duoc, => blur btn to'
	            this.turnButtons.showTo(false);
	        }

	    }
	},
	handleAutoPlay: function( tP,slot, mb , isFirstTurnInRound ){
		if(!tP || !slot) return;
	    if(cc.isUndefined(mb) ) mb = null;
	    if(cc.isUndefined(isFirstTurnInRound) ) isFirstTurnInRound = false;
	    var thiz = this;

	    if(slot.uid === PlayerMe.uid ){
	        this.dialogRaiseMoney.show(false);
	        if(tP.uid === PlayerMe.uid ){
	            if(thiz.isXemUp || thiz.isTheoTat){
	                thiz.turnButtons.showAll(false);
	                thiz.turnButtons.showAllAuto(false);
	                if (thiz.isTheoTat) {
	                    if (mb && mb === thiz.currentBet) {
	                        thiz.onXem();
	                    }else{
	                        thiz.onTheo();
	                    }
	                }else{
	                    if (thiz.isXemUp) {
	                        cc.log("thiz.isXemUp mb = "+mb + " currentBet = "+thiz.currentBet);
	                        if ( mb === thiz.currentBet) {
	                            thiz.onXem();
	                        }else {
	                            thiz.onUpBai();
	                        }
	                    }
	                }
	            }else{
	                thiz.turnButtons.showAll(true);
	                thiz.turnButtons.showAllAuto(false);

	                //cc.log(`handleAutoPlay mb${mb} currentBet ${thiz.currentBet} isFirstTurnInRound ${isFirstTurnInRound}`);
	                //mb = 0 la new round nhung player first new round click xem
	                if( (mb ===0 || mb && thiz.currentBet === mb) || isFirstTurnInRound){
	                    // show xem (not theo)
	                    thiz.turnButtons.showTextXem(true);
	                }else{
	                    // show theo (not xem)
	                    thiz.turnButtons.showTextXem(false);
	                }
	                if((mb - thiz.currentBet) >= thiz.getMoneyPlayer(PlayerMe.uid)
	                    ||  thiz.getMaxRaise() <=0){
	                    //tien con lai <= to them cua payer # => chi theo duoc, => blur btn to'
	                    thiz.turnButtons.showTo(false);
	                }
	            }
	        }else{
	            if(!thiz.isViewing){
	                thiz.turnButtons.showAll(false);
	                var slotMe = thiz.getSlotByUid(PlayerMe.uid);
	                if(slotMe && slotMe.getStatePlayer()!== state_poker.UP_BAI){//ko phai up bai
	                    thiz.turnButtons.showAllAuto(true);
	                }else{
	                    thiz.turnButtons.showAllAuto(false);
	                }
	            }else{
	                thiz.turnButtons.showAll(false);
	                thiz.turnButtons.showAllAuto(false);
	            }

	        }
	    }
	},
	updateFromPlayer: function(fromPlayer, slot, isFirstTurnNewRound){
		if(!fromPlayer || !slot) return false;
	    ////{"uid":"483ce64e-6ed7-4e6f-bca2-08f27bcca5aa","pS":3,"dn":"fucker","m":18250,"cb":0}
	    var isTossChip = false;
	    var thiz = this;
	    if(fromPlayer && slot.uid === fromPlayer.uid ){
	        thiz.setStatePlayerGameTo(slot.uid, fromPlayer.pS);
	        //cc.log('fromPlayer.pS ' +fromPlayer.pS);
	        if(fromPlayer.pS ===2 || fromPlayer.pS ===4 || fromPlayer.pS ===5){
	            //to them, theo, xa lang
	            //{"mb":5400,"fP":{"uid":"7c4bf83d-1b35-433c-b0b3-2ed502981cdb","pS":4,"dn":"zzzzzzzzzzzzzzz","m":12850,"cb":5400},"cmd":803,
	            // "tP":{"uid":"483ce64e-6ed7-4e6f-bca2-08f27bcca5aa","dn":"fucker"}}
	            // var addBet = fromPlayer.cb - thiz.currentBet;
	            var addBet = thiz.getMoneyPlayer(fromPlayer.uid) - fromPlayer.m;
	            cc.log('fromPlayer.pS addBet' +addBet);
	            if(addBet > 0){
	                cc.log('toss chip ' +fromPlayer);
	                thiz.tossChip(slot.uid, addBet, false, !isFirstTurnNewRound);//isFirstTurnNewRound = true thi coi nhu reconnect de add luon ko anim
	                //thiz.tossChip(index, addBet, isFirstTurnNewRound);
	                slot.reduceMoney(-addBet);
	                isTossChip =  true;
	            }

	        }else if(fromPlayer.pS === 1){
	            //up bai
	            if(fromPlayer.uid === PlayerMe.uid){
	                thiz.turnButtons.showAll(false);
	                thiz.turnButtons.showAllAuto(false);
	            }

	        }
	        if(slot.uid === PlayerMe.uid ) thiz.currentBet = fromPlayer.cb;
	    }
	    return isTossChip;
	},
	changeTurnPlayer: function(tP, slot){
		if(!tP || !slot) return;
	    if(tP.uid === slot.uid){
	        this.onUpdateTurn(slot.uid, this.timeTurn);
	    }else{
	        slot.stopTimeRemain();
	    }
	},
	chiabai:  function(data){
		//  {"cs":[34,24],"cmd":801} = > chiabai cho myself thoi
	    if(TEST_MODE){
	        var player =[];
	        for(var i = 0 ; i < this.allSlot.length;i++){
	            player.push(this.allSlot[i].uid);
	        }
	        data ={"cs":[30,18],"lpi":player, "sb":500, "bb":1000, "tP":{"uid":this.allSlot[0].uid},"cmd":801};
	    }
	    /*if(PlayerMe.displayName.indexOf("dohimi")!= -1){
	        data.cs = [30,18];
	    }else{
	        data.cs = [8,37];
	    }*/

	    this.dialogWithdrawMoney.show(false);
	    this.dialogStandUpQuit.visible = false;
	    cc.log("chiabai "+ JSON.stringify(data));
	    var thiz = this;
	    thiz.disablePendindAndReset = true;
	    var playerArr = data.ps;
	    if(playerArr){
	        for(var idx in thiz.allSlot){
	            var slot = thiz.allSlot[idx];
	            if(!slot) continue;
	            for(var i =0; i < playerArr.length; i++){
	                if(playerArr[i].uid === slot.uid ){
	                    thiz.updateRealMoneyPlayer(playerArr[i]);
	                    break;
	                }
	            }
	        }
	    }

	    thiz.ideGameNumber++;
	    thiz.resetNewGame();
	    //thiz.lblNarrativeResult.showText('Nặn bài');

	    thiz.gameState = GAME_STATE.PLAYING;
	    thiz.data.gS = GAME_STATE.PLAYING;
	    var dealerUid = data.D;
	    var listPlayer = data.lpi;
	    thiz.listPlayer = listPlayer;
	    if(listPlayer.indexOf(PlayerMe.uid) !== -1 ) thiz.isViewing = false;
	    else thiz.isViewing = true;

	    if(!thiz.isViewing) thiz.isPlaying = true;
	    thiz.playSoundAction("chiabai");
	    var smallBlind = data.sb;
	    var bigBlind  = data.bb;
	    thiz.maxBet = bigBlind.cb;
	    thiz.currentBet = 0;
	    var toPlayer = data.tP;
	    var cardArray = data.cs;
	    if(listPlayer.indexOf(PlayerMe.uid) !== -1 ) thiz.myCards = data.cs;

	    if(thiz.isPlaying){
	        if(PlayerMe.uid === smallBlind.uid) thiz.currentBet = smallBlind.cb;
	        else if(PlayerMe.uid === bigBlind.uid) thiz.currentBet = bigBlind.cb;
	    }

	    cc.each(thiz.data.ps, function(p, i){
	        for(var j = 0 ; j< listPlayer.length; j++){
	            if(p.uid == listPlayer[j]){
	                p.pi =true;
	                p.pS =0;
	                p.totalCard = 2;
	                break;
	            }
	        }
	    });

	    thiz.updateMoneyPlayerBlinder(smallBlind, bigBlind);
	    cc.each(thiz.allSlot, function(slot, index){
	        if(slot){
	            slot.showDealer(slot.uid === dealerUid);
	            if(thiz.isViewing) cardArray =[0,0];//default
	            if(listPlayer.indexOf(slot.uid) > -1 ){
	                //thiz.onUpdateTurn(toPlayer.uid, thiz.shapeTime, true );
	                thiz.setStatePlayer(slot.uid, state_player.NOTHING);//remove chk ready,...
	                var isFirstTurnNewRound = false;
	                //turn dau tien van choi, nguoi choi chi co the theo vi small blind va big blind deu tu dong dat cuoc
	                thiz.handleAutoPlay(toPlayer, slot, thiz.maxBet, isFirstTurnNewRound);
	                if(slot.uid === smallBlind.uid){
	                    thiz.tossChip(slot.uid, smallBlind.cb, false);//
	                }else if(slot.uid === bigBlind.uid){
	                    thiz.tossChip(slot.uid, bigBlind.cb, false);//
	                }
	                thiz.animChiaBaiToPlayer(cardArray, slot, true, false,false);//scale o day ko co gia tri
	                if( slot.uid == PlayerMe.uid ) {
	                    slot.showRutTienBtn(false);
	                    slot.cardList.checkPokerRank([]);
	                }
	            } else {
	                //viewer
	                thiz.setStatePlayer(slot.uid, state_player.DANG_XEM);
	                if( slot.uid == PlayerMe.uid ) slot.showRutTienBtn(false);
	            }
	        }
	    });
	    thiz.onUpdateTurn(toPlayer.uid, thiz.timeTurn );
	},
	getPlayer: function(uid){
		var thiz = this;
	    var p =null;
	    cc.each(thiz.players, function(_player, index){
	        if(_player){
	            if(_player.uid === uid){
	                p = _player;
	            }
	        }
	    });
	    return p;
	},
	chiabaiNewRound:  function (cardShow) {
		cc.log("chiabaiNewRound = "+ JSON.stringify(cardShow) );

	    if(cardShow.length){
	        var oldLength = this.cardOnTable.getCards().length;
	        var cards = [];
	        for (var k = oldLength; k < cardShow.length; k++) {
	            cards.push(Utils.getCardFromServer(cardShow[k]));
	        }
	        //cards, isMe, animation, originShowBack, originScale, remove
	        this.cardOnTable.dealCardsOnTable(cards, false, true, false, GamePoker.cardOriginScaleOnTable, false);
	        if(!this.isViewing){
	            var slot = this.getSlotByUid(PlayerMe.uid);
	            if(slot) slot.cardList.checkPokerRank(this.cardOnTable.getCards());
	        }
	    }
	},
	animChiaBaiToPlayer: function (cardArray, slot, animation, isReconnect, isToss, isChiaBai) {
		if(cc.isUndefined(animation)) animation = true;
	    if(cc.isUndefined(isReconnect)) isReconnect = false;
	    if(cc.isUndefined(isToss)) isToss = true;
	    if(cc.isUndefined(isChiaBai)) isChiaBai = false;
	    if(isToss){
	        this.tossChip(slot.uid, this.betValue, isReconnect, animation);
	        slot.reduceMoney(-this.betValue);
	    }


	    var cards = [];
	    for (var k = 0; k < cardArray.length; k++) {
	        cards.push(Utils.getCardFromServer(cardArray[k]));
	    }
	    var isMe = slot.uid == PlayerMe.uid;
	    var showBackCard = isMe ? false : true;
	    var originScale =isMe ?  0.7 : 0.7;
	    slot.cardList.dealCards(cards, isMe, animation, showBackCard, originScale, false, isChiaBai);
	    //cc.log("chia bai cho", slot.username);
	},
	initButton: function () {
		var thiz = this;
	    var x = cc.winSize.width/2;
	    var y = cc.winSize.height/2;

	    var upBt = MyHelper.createButton("button/btn_button2.png", true,function () {
	        thiz.onUpBai();
	    });
	    upBt.setPosition(x + 387 , -(y + 311) );
	    upBt.displayGroup = MyPixi.animationLayer;
	    MyPixi.gameContainer.addChild(upBt);
	    MyHelper.addLblButton(upBt, "Úp", 16);
	    upBt.visible = false;

	    var latBt = MyHelper.createButton("button/btn_button2.png", true,function () {
	        thiz.onLatBai();
	    });

	    latBt.setPosition(x +553 , -(y + 311) );
	    MyPixi.gameContainer.addChild(latBt);
	    latBt.displayGroup = MyPixi.animationLayer;
	    MyHelper.addLblButton(latBt, "Lật", 16);
	    latBt.visible = false;

	    var xemBt = MyHelper.createButton("button/btn_button2.png", true,function () {
	        thiz.onXem();
	    });
	    xemBt.setPosition(x +387, -(y + 240) );
	    MyPixi.gameContainer.addChild(xemBt);
	    xemBt.displayGroup = MyPixi.animationLayer;
	    MyHelper.addLblButton(xemBt, "Xem", 16);
	    xemBt.visible = false;

	    var toBt = MyHelper.createButton("button/btn_button2.png", true,function () {
	        thiz.onShowTo();
	    } );
	    toBt.setPosition(x +553 , -(y + 240) );
	    MyPixi.gameContainer.addChild(toBt);
	    toBt.displayGroup = MyPixi.animationLayer;
	    MyHelper.addLblButton(toBt, "Tố", 16);
	    toBt.visible = false;

	    var xemUpBt = new ButtonToggle("button/btn_1_checked.png", "button/btn_1_check.png");
	    xemUpBt.setText("Xem úp");
	    xemUpBt.setAnchorPoint(.5,.5);
	    xemUpBt.setPosition(x+367, -(y +311));
	    MyPixi.gameContainer.addChild(xemUpBt);
	    xemUpBt.displayGroup = MyPixi.animationLayer;

	    xemUpBt.onSelect = function ( selected) {
	        thiz.theoTatBt.unSelect();
	        thiz.onUpTheo();
	    };
	    xemUpBt.onUnSelect = function ( selected) {
	        thiz.onUpTheo();
	    };
	    xemUpBt.visible = false;

	    var theoTatBt = new ButtonToggle("button/btn_1_checked.png", "button/btn_1_check.png");
	    theoTatBt.setText("Theo tất");
	    theoTatBt.setAnchorPoint(.5,.5);
	    theoTatBt.setPosition(x+553, -(y +311));
	    MyPixi.gameContainer.addChild(theoTatBt);
	    theoTatBt.displayGroup = MyPixi.animationLayer;

	    theoTatBt.onSelect = function ( selected) {
	        thiz.xemUpBt.unSelect();
	        thiz.onTheoTat();
	    };
	    theoTatBt.onUnSelect = function ( selected) {
	        thiz.onTheoTat();
	    };
	    theoTatBt.visible = false;
	    this.theoTatBt = theoTatBt;
	    this.xemUpBt = xemUpBt;

	    var btnList = [upBt, xemBt, toBt];
	    var btnListAuto = [xemUpBt, theoTatBt];

	    this.turnButtons = new TurnButtonUI(btnList, btnListAuto);
	},
	updateRealMoneyPlayer: function(data){
		// cc.log(`updateMoneyPlayer/////`);
	    if(!data) return;
	    var thiz = this;
	    var length = this.data.ps.length;
	    for (var j = 0; j < length;j++) {
	        var el = this.data.ps[j];
	        if(el.uid === data.uid){
	            el.rM = data.m;//server tra ve m chu ko phai rm :(
	            // cc.log(`update real money ${el.rM} = ${data.m}`);
	            break;
	        }
	    }
	},
	updateMoneyPlayer: function(data){
		//cc.log(`updateMoneyPlayer/////`);
	    if(!data) return;
	    var thiz = this;
	    var length = this.data.ps.length;
	    for (var j = 0; j < length;j++) {
	        var el = this.data.ps[j];
	        if(el.uid === data.uid){
	            el.m = data.m;
	            if(data.rM) el.rM = data.rM;
	            // cc.log(`update money ${el.dn} = ${data.m}`);
	            break;
	        }
	    }
	},
	getMoneyPlayer: function(uid){
		var thiz = this;
	    var length = thiz.data.ps.length;
	    for (var j = 0; j < length;j++) {
	        var el = thiz.data.ps[j];
	        if(el.uid === uid){
	            return el.m ;
	        }
	    }
	    return -1;
	},
	getIdCoinImg: function(ratio){
		var id = ChipType.WHITE;
	    if (ratio >= 20 ) id = ChipType.RED;
	    else if (ratio >= 10 ) id = ChipType.VIOLET;
	    else if (ratio >= 4 ) id = ChipType.BLUE;
	    else if (ratio >= 2 ) id = ChipType.GREEN;
	    else  if (ratio >= 1 ) id = ChipType.WHITE;
	    return id;
	},
	getPlayerIndexByUid:  function(uid){
		for(var idx in this.allSlot){
	        if(this.allSlot[idx] ===  uid ){
	            return idx;
	        }
	    }
	    return -1;
	},
	onEndGame:  function(data){
		cc.log("onEndGame "+JSON.stringify(data));
	    var thiz = this;
	    thiz.lblNarrativeResult.hideLine();
	    thiz.turnButtons.showAll(false);
	    thiz.turnButtons.showAllAuto(false);
	    thiz.turnButtons.checkAllAuto(false);
	    thiz.isTheoTat = false;
	    thiz.isXemUp = false;
	    //remove all image THEO -TO,.. in player
	    this.clearStatePlayer();
	    //hide dilaog shap if dang open
	    this.dialogWithdrawMoney.show(false);
	    this.dialogRaiseMoney.show(false);
	    this.dialogShapCardShow.show(false);
	    
	    //cc.log('showResult '+ Utils.encode(data) );
	    thiz.showResult(true, data);
	},
	showResult:  function(isShow, dataObj, timeRemain){
		// if(TEST_MODE){
	 //          dataObj = {"ps":[{"cs":[30,18],"uid":PlayerMe.uid,"rh":1,"ph":[45,15,40 ,37, 46]
	 //              ,"dn":"dohimi","mX":0,"rM":10039199,"m":4800,"iw":false}],"cmc":[45,15,40 ,5, 46]
	 //              ,"fP":{"cs":[ 8,37],"uid":this.allSlot[1].uid,"pS":3
	 //                  ,"rh":2,"ph":[45,15,40 , 46, 30],"dn":"todau11","mX":390,"rM":997712,"m":5190,"iw":true,"cb":0}
	 //              ,"pots":[{"id":1,"m":400,"wns":[PlayerMe.uid]}],"cmd":752}
	 //    }
	    cc.log("showResult "+JSON.stringify(dataObj) );
	    if(!timeRemain) timeRemain = -1;
	    var thiz = this;
	    thiz.disablePendindAndReset = false;
	    if(thiz.playerArr) thiz.playerArr.length = 0;
	    thiz.playerArr = dataObj.ps;
	    if(thiz.pots) thiz.pots.length=0;
	    thiz.pots = dataObj.pots;
	    var timeDelay = 0;//delay to, theo, xalang cua player cuoi
	    var cardShow = dataObj.cmc;
	    if(cardShow) thiz.chiabaiNewRound(cardShow); //
	    if(isShow){
	        thiz.playSoundAction("finished");
	        cc.each(thiz.allSlot, function(slot, index){
	            if(slot){
	                thiz.setStatePlayer(slot.uid, state_player.NOTHING);
	            }
	        });
	        if(dataObj.fP){
	            if([2,4,5].indexOf(dataObj.fP.pS) !== -1){
	                //theo ,to ,xalang
	                timeDelay = 1;//1s
	                cc.each(thiz.allSlot, function(slot, index){
	                    if(slot && slot.uid === dataObj.fP.uid){
	                        //to them, theo, xa lang
	                        //updateMoney call sau if([2,4,5]..{} thi moi tinh dc addbet
	                        var addBet = thiz.getMoneyPlayer(dataObj.fP.uid) - dataObj.fP.m;
	                        if(addBet > 0){
	                            //1 s toss + 1 s show thang thua
	                            if(timeRemain == -1 || timeRemain >2 ) thiz.tossChip(slot.uid, addBet, false, true);
	                            slot.reduceMoney(-addBet);
	                        }
	                        if(slot.uid === PlayerMe.uid ) thiz.currentBet = dataObj.fP.cb;
	                    }
	                });
	            }else if(dataObj.fP.pS === 1){//bo luot
	                cc.each(thiz.allSlot, function(slot, index){
	                    if(slot && slot.uid === dataObj.fP.uid){
	                        thiz.setStatePlayerGameTo(slot.uid, dataObj.fP.pS)
	                    }
	                });

	            }
	            thiz.playerArr.push(dataObj.fP);
	        }else{

	        }

	        for(var i =0; i < thiz.playerArr.length; i++){
	            var player = thiz.playerArr[i];
	            thiz.updateMoneyPlayer(thiz.playerArr[i]);
	            if(player.pS === 1){//bo luot
	                cc.each(thiz.allSlot, function(slot, index){
	                    if(slot && slot.uid === player.uid){
	                        thiz.setStatePlayerGameTo(slot.uid,player.pS);
	                    }
	                });
	            }
	        }

	        if(timeRemain > -1 && timeRemain <2 ) timeDelay = 0;//show kq ngay lap tuc, ko anim toss chip nua

	        var timeEnd = thiz.timeEndGame/1000;
	        if(timeRemain >= 0 && timeEnd < timeRemain) timeEnd = timeRemain;

	        var cb = cc.callFunc(function(){
	            thiz.animationResult();
	        });
	        this.runAction(cc.sequence(cc.delayTime(timeDelay),cb ));
	        var cbEnd = cc.callFunc(function(){
	            thiz.endGame();
	        });
	        this.runAction(cc.sequence(cc.delayTime(timeEnd),cbEnd ));
	    }
	},
	animationResult:  function(){
		var thiz = this;
	    var playerArr = thiz.playerArr;
	    var pots = thiz.pots;
	    var isEndGame = true;
	    // cc.log('-------pots ');//+Utils.encode(pots));
	    //"pots":[{"uid":"483ce64e-6ed7-4e6f-bca2-08f27bcca5aa","dn":"fucker","id":1,"m":3100}]
	    //[{"uid":"d9401d95-8975-4338-a415-829ebde1a806","dn":"trumtumlum","id":1,"m":7500},{"uid":"d9401d95-8975-4338-a415-829ebde1a806",
	    // "dn":"trumtumlum","id":2,"m":3975},{"uid":"0423cf52-851e-4999-8f43-bc01bbaa4393","dn":"fb_xichlolo375","id":3,"m":4350}]
	    // if(pots.length> 1)
	    //this.gopChip(pots);
	    var chipArr =[];
	    cc.each(thiz.chipColumns, function(chipColumnPlayer, i){
	        var chipList = chipColumnPlayer.getChips();
	        if(chipList && chipList.length) chipArr = chipArr.concat(chipList);
	        chipColumnPlayer.hideMucCuoc();
	    });

	    if(!chipArr || !chipArr.length){
	        thiz.potsToPlayerWin( pots);
	    }else{
	        thiz.gopChipNewRound(pots, false, isEndGame);
	    }

	    cc.each(thiz.allSlot, function(slot, index){
	        if(slot){
	            slot.stopTimeRemain();
	            for(var i =0; i < playerArr.length; i++){
	                if(playerArr[i].uid === slot.uid ){
	                    var isUp = false;
	                    if(playerArr[i].pS){
	                        if(playerArr[i].pS === 1){
	                            thiz.setStatePlayerLieng(slot.uid, playerArr[i].pS);
	                            isUp = true;
	                        }
	                    }

	                    if(playerArr[i].cs && !isUp){
	                        slot.cardList.showCardEndGame(playerArr[i].cs, slot.isMe);
	                        slot.cardList.flipAndShowAllCard(.2);//myplayer se auto ko flip
	                    }
	                    if(playerArr[i].iw){
	                        if(playerArr[i].ph)thiz.cardOnTable.showOrrangeEffect(playerArr[i].ph);
	                    }


	                    slot.showResultPoker(playerArr[i].m, playerArr[i].mX,   playerArr[i].rh ? playerArr[i].rh : 0, isUp, playerArr[i].iw, playerArr[i].cs ? playerArr[i].cs : [], playerArr[i].ph ? playerArr[i].ph : 0 );
	                    if(slot.uid === PlayerMe.uid){

	                        if(thiz.aid == Constant.ASSET_ID.GOLD) PlayerMe.gold = playerArr[i].rM;//real money
	                        else PlayerMe.chip = playerArr[i].rM;
	                    }

	                    break;
	                }
	            }

	        }
	    });
	},
	endGame: function(preventWidthDraw ){
		if(preventWidthDraw == undefined) preventWidthDraw = false;
	    var thiz = this;

	    if(thiz.isPlaying && thiz.meSitDown) thiz.getSlotByUid(PlayerMe.uid).showRutTienBtn(true);
	    if(!preventWidthDraw && thiz.meSitDown && (2*thiz.betValue) > thiz.getMoneyPlayer(PlayerMe.uid)){
	        var realMoney = 0;
	        if(this.aid == Constant.ASSET_ID.GOLD)
	            realMoney = PlayerMe.gold;
	        else
	            realMoney = PlayerMe.chip;

	        if(thiz.autoRutTien && realMoney >= thiz.currentMoneyBuy)
	            thiz.onWithdrawMoney(thiz.currentMoneyBuy, true ,true);
	        else
	            thiz.onSitdown(true);//show dilaog lay them tien
	    }
	    thiz.gameState=0;
	    thiz.meUpBai = false;
	    if(thiz.meSitDown) thiz.isViewing = false;//dang xem van choi, khi ket thuc van thi doi tu viewing sang chuan bi choi
	    thiz.resetNewGame();
	},
	initPlayer: function () {
		var center  = cc.winSize;
	    var playerMe = new GamePlayer();
	    playerMe.sitId = 0;
	    playerMe.setPosition(cc.p2(center.width / 2 -playerMe.widthBG/2, center.height/2 + 160));

	    var player1 = new GamePlayer();
	    player1.sitId = 1;
	    player1.setPosition(cc.p2(center.width / 2 + 290- player1.widthBG/2, center.height/2 + 160));

	    var player2 = new GamePlayer();
	    player2.sitId = 2;
	    player2.setPosition(cc.p2(center.width / 2 + 490, center.height/2 + 20));

	    var player3 = new GamePlayer();
	    player3.sitId = 3;
	    //player3.position.set(center.width / 2 +250,center.height/2 - 350);
	    player3.setPosition(cc.p2(center.width / 2 +490,center.height/2 - 180));

	    var player4 = new GamePlayer();
	    player4.sitId = 4;
	    player4.setPosition(cc.p2(center.width / 2 +220 - player4.widthBG/2,center.height/2 - 350));

	    var player5 = new GamePlayer();
	    player5.sitId = 5;
	    player5.setPosition(cc.p2(center.width / 2 -220 - player5.widthBG/2,center.height/2 - 350));

	    var player6 = new GamePlayer();
	    player6.sitId = 6;
	    player6.setPosition(cc.p2(center.width / 2 -620,center.height/2 - 180));

	    var player7 = new GamePlayer();
	    player7.sitId = 7;
	    player7.setPosition(cc.p2(center.width / 2 -620,center.height/2 +20));

	    var player8 = new GamePlayer();
	    player8.sitId = 8;
	    player8.setPosition(cc.p2(center.width / 2 - 290 -player8.widthBG/2, center.height/2 + 160));

	    this.playerView = [playerMe, player1, player2, player3, player4, player5, player6, player7, player8];
	    for(var i = 0 ; i < this.playerView.length; i++){
	        this.playerView[i].displayGroup = MyPixi.gamePlayerLayer;
	        this.playerView[i].listener = this;
	        MyPixi.gameContainer.addChild(this.playerView[i]);
	    }
	    if(this.data.Mu ==5){
	        this.playerView[1].visible = false;
	        this.playerView[3].visible = false;
	        this.playerView[6].visible = false;
	        this.playerView[8].visible = false;
	    }
	    this.chipColumns =[];
	    var thiz = this;
	    var defaultPos = cc.p2(-50, 65);
	    var defaultPos2 = cc.p2(165, 65);
	    var leftPos = cc.p2(-60, 65);
	    var rightPos = cc.p2(195, 65);
	    var posArr = [cc.p2(60+this.playerView[0].widthBG, 65), rightPos,leftPos,leftPos, rightPos, leftPos, rightPos, rightPos ,leftPos ];
	    var dxChip = 0 ;
	    var dyChip = 0;
	    var isVertical = false;
	    for(var i = 0 ,max = this.playerView.length; i < max; i++){
	        this.playerView[i].onSitdown = function(){
	            thiz.onSitdown();
	        };
	        var sizeCards = cc.size(160, 90);
	        var align = LiengCardList.ALIGN_LEFT;
	        if(i == 2 || i == 3){
	            sizeCards = cc.size(160, 90);
	            align = LiengCardList.ALIGN_RIGHT;
	        }else if( i == 6 || i == 7){
	            sizeCards = cc.size(160, 90);
	            align = LiengCardList.ALIGN_LEFT;
	        }else if(i == 1 || i == 4 || i == 5 || i == 8){
	            sizeCards = cc.size(160, 90);
	            if(i==5 || i ==8) align = LiengCardList.ALIGN_RIGHT;
	        }
	        else isVertical = false;
	        this.playerView[i].cardList = new PokerCardList(posArr[i], sizeCards, GameLieng.cardOriginScaleBackCard, isVertical, align);
	        //this.playerView[i].cardList.scale.set(0.7, 0.7);
	        this.playerView[i].infoLayer.addChild(this.playerView[i].cardList);// zOrder+1
	        this.playerView[i].cardList.setListener(this.playerView[i]);
	        this.playerView[i].cardList.setSitId(i);
	        this.playerView[i].cardList.onShowLatBai = function(visible){
	            thiz.onShowLatBai(visible);
	        };

	        if(TEST_MODE) this.playerView[i].cardList.showBlurBg(true);

	        if(i ==0 || i ==1 || i ==4 || i ==5 ||i ==8) {
	            dxChip = 0;
	            if(i ==8) dxChip = 0;
	            if(i ==0) dyChip = 100;
	            else if(i ==1 || i ==8) dyChip = 110;
	            else dyChip = -140;
	        }else if(i ==2 || i ==3) {
	            dxChip = -210;
	            if(i ==2) dyChip = 30;
	            else
	                dyChip = 0;
	        }else if(i ==6 || i ==7){
	            dxChip = 190;
	            if(i ==7) dyChip = 30;
	            else   dyChip = 0;
	        }
	        var alignLbl = ChipColumnList.LBL_RIGHT;
	        if(i ==1 || i ==2 || i ==3 || i ==4) {
	            alignLbl = ChipColumnList.LBL_LEFT;
	        }

	        var chipColumnPlayer = new ChipColumnList(cc.size(30, 100),.3, alignLbl);
	        chipColumnPlayer.setPosition(cc.p2(this.playerView[i].x + this.playerView[i].widthBG/2 + dxChip -chipColumnPlayer.widthContainer/2, -chipColumnPlayer.heightContainer/2 + this.playerView[i].y  + this.playerView[i].heightBG/2 - dyChip -50));
	        chipColumnPlayer.displayGroup = MyPixi.chipLayer;
	        MyPixi.gameContainer.addChild(chipColumnPlayer);
	        if(TEST_MODE) chipColumnPlayer.showBlurBg(true);

	        this.chipColumns.push(chipColumnPlayer);

	    }

	    this.arrangePlayerInGame();
	},
	onShowLatBai: function(isShow){
		this.turnButtons.onShowLatBai(isShow);
	},
	onListenerAutoRutTien: function(isCheck){
		this.autoRutTien = isCheck
    	cc.log('autoRutTien '+this.autoRutTien );
	},
	onStandUp: function(){
		var thiz = this;
	    if(thiz.isPlaying && thiz.gameState ===4 || thiz.gameState ===5){
	        MH.showMessage("Ván chơi chưa chưa kết thúc");
	        //thiz.dialogs[8].getComponent('StandUpQuit').showDialog(false);//pending
	        this.dialogStandUpQuit.show(false);
	        return;
	    }//[5,"Simms",101,{}]
	    var sendObj = [
	        command.RoomPluginMessage,
	        Constant.CONSTANT.ZONE_NAME,
	        thiz.roomID,
	        {'cmd':POKER_CMD.CMD_STAND_UP}
	    ];
	    LobbyClient.getInstance().send(sendObj);
	    cc.log('onStandUp '+ JSON.stringify(sendObj) );
	},
	onSitdown: function(isSitDown){
		if(isSitDown === undefined) isSitDown = false;
	    var thiz = this;
	    var money = 0;
	    if(this.aid == Constant.ASSET_ID.GOLD)
	        money = PlayerMe.gold;
	    else
	        money = PlayerMe.chip;
	    if(money < this.mMBI){
	        MH.showMessage("Bạn không đủ tiền để tham gia ván chơi");
	    }else{
	        this.dialogWithdrawMoney.show(true);
	        this.dialogWithdrawMoney.setData(money, this.mMBI, this.MMBI, this.betValue, isSitDown);
	        this.dialogWithdrawMoney.showWithAnimationScale();
	    }
	},
	onWithdrawMoney: function(money, isSit, isAutoRutTiem){
		if(isAutoRutTiem === undefined) isAutoRutTiem = false;
	    var thiz = this;
	    if(thiz.meSitDown && ( thiz.gameState ===4 || thiz.gameState ===5 )  && !isAutoRutTiem ){
	        MH.showMessage("Không được rút tiền khi ván chơi chưa chưa kết thúc");
	        return;
	    }
	    cc.log('send Mua tiền vào bàn');
	    this.currentMoneyBuy = money;
	    var cmd = POKER_CMD.CMD_WITHDRAW_FOR_SIT;
	    if(isSit) cmd = POKER_CMD.CMD_WITHDRAW;
	    var sendObj = [
	        command.RoomPluginMessage,
	        Constant.CONSTANT.ZONE_NAME,
	        thiz.roomID,
	        {'cmd':cmd, 'm':money}
	    ];
	    LobbyClient.getInstance().send(sendObj);
	},
	onUpBai: function(){
		cc.log('send upbai 810');
	    var sendObj = [
	        command.RoomPluginMessage,
	        Constant.CONSTANT.ZONE_NAME,
	        this.roomID,
	        {'cmd':POKER_CMD.CMD_UP_BAI}
	    ];
	    LobbyClient.getInstance().send(sendObj);
	    this.ideGameNumber = 0;
	},
	onUpTheo: function(){
		var thiz = this;
	    thiz.isXemUp = this.xemUpBt.selected;
	    cc.log('isXemUp '+thiz.isXemUp);
	    if(thiz.isXemUp){
	        thiz.isTheoTat = false;
	        //thiz.turnButtons.check(false,1);
	    }
	    this.ideGameNumber = 0;
	},
	onTheoTat: function(){
		var thiz = this;
	    thiz.isTheoTat = thiz.theoTatBt.selected;
	    cc.log('isTheoTat '+thiz.isTheoTat);
	    if(thiz.isTheoTat){
	        thiz.isXemUp = false;
	        //thiz.turnButtons.check(false, 0);
	    }
	    this.ideGameNumber = 0;
	},
	onTheo: function(){
		cc.log('onTheo');
	    var sendObj = [
	        command.RoomPluginMessage,
	        Constant.CONSTANT.ZONE_NAME,
	        this.roomID,
	        {'cmd':POKER_CMD.CMD_THEO}
	    ];
	    LobbyClient.getInstance().send(sendObj);
	    this.ideGameNumber = 0;
	},
	onXem: function(){
		if(!this.turnButtons.isXemShow()){
	        this.onTheo();
	        return;
	    }
	    cc.log('onXem');
	    var sendObj = [
	        command.RoomPluginMessage,
	        Constant.CONSTANT.ZONE_NAME,
	        this.roomID,
	        {'cmd':POKER_CMD.CMD_XEM_BAI}
	    ];
	    LobbyClient.getInstance().send(sendObj);
	    this.ideGameNumber = 0;
	},
	onShowTo: function(){
		var  min = 0;
	    var max = this.getMaxRaise();
	    if(TEST_MODE) max = this.betValue*10.5;
	    var thiz = this;
	    //if(!thiz.dialogRaiseMoney.visible ||  thiz.dialogRaiseMoney.alpha !==1 ){
	    if(!thiz.dialogRaiseMoney.visible  ){
	        thiz.dialogRaiseMoney.showDialog(true, min, max, thiz.betValue);
	        //cc.log('show dilaog raise');
	    }else{
	        //cc.log('hide dilaog raise and to');
	        thiz.dialogRaiseMoney.show(false);
	        thiz.onTo(thiz.dialogRaiseMoney.getMoneyRaise());
	    }
	},
	onTo: function(toValue){
		cc.log('onTo ' + toValue);
	    if(toValue>0){
	        var sendObj = [
	            command.RoomPluginMessage,
	            Constant.CONSTANT.ZONE_NAME,
	            this.roomID,
	            {'cmd':POKER_CMD.CMD_TO, 'b':toValue}
	        ];
	        LobbyClient.getInstance().send(sendObj);
	    }
	},
	onLatBai: function(){
		cc.log('onLatBai');
    	this.dialogShapCardShow.showDialog(true, this.myCards);
	},
	onSendLatBai: function(cs){
		var sendObj = [
	        command.RoomPluginMessage,
	        Constant.CONSTANT.ZONE_NAME,
	        this.roomID,
	        {'cmd':POKER_CMD.CMD_CHOSE_CARD_SHOW, 'cs':cs}
	    ];
	    if(TEST_MODE){
	        //var data = ["aaaa",{"cs":cs,"uid":PlayerMe.uid,"cmd":709}];
	        var data = ["aaaa",{"cs":cs,"uid":PlayerMe.uid,"cmd":POKER_CMD.CMD_SHOW_CARD}];
	        //cc.log('onSendLatBai demo fix cs==> ' );
	        this.onShowCard(data);
	    }else{
	        cc.log('onSendLatBai cs==> '+JSON.stringify(sendObj) );
	        LobbyClient.getInstance().send(sendObj);
	    }
	},
	getMaxRaise: function(){
		// minh` to max = maxtien cua thang co tien cao nhi` trong ban`
	    // neu thang cao nhi` la minh thi co the to maxtien cua minh luon
	    var thiz = this;
	    var length = thiz.data.ps.length;
	    var raiseMax = 0;
	    var maxMoney = 0;//max money cac player (not count myplayer)
	    var myMoney = 0;
	    for (var j = 0; j < length;j++) {
	        var el = thiz.data.ps[j];
	        if(el.uid === PlayerMe.uid) myMoney = el.m;
	        if(maxMoney < el.m && el.uid !== PlayerMe.uid && el.pi === true && el.pS !== 1){
	            // if(maxMoney > el.m && el.m >0){//&& el.pi === true : ko can bi khi add new player viewe ko add el.m
	            maxMoney =el.m;
	        }
	    }
	    // raiseMax = maxMoney;

	    var hs = thiz.maxBet - thiz.currentBet;
	    if(myMoney <= maxMoney){
	        raiseMax = myMoney;
	        raiseMax -= hs;
	    }else if(myMoney > maxMoney){
	        //raise max  = money cua nguoi nhieu tien thu 2 trong phong( minh dang la nhieu nhat)
	        if(myMoney >= (maxMoney+ hs) )
	            raiseMax = maxMoney;
	        else{
	            raiseMax = myMoney- hs;
	        }
	    }
	    // cc.log(`raiseMax ${raiseMax}`);
	    // if(hs > 0) raiseMax -= hs;
	    if(raiseMax<0) raiseMax = 0;
	    return raiseMax;
	},
	arrangePlayerInGame: function (arrangeChauRiaOnly) {
		cc.log("arrangeChauRiaOnly "+arrangeChauRiaOnly);

	    this.processPlayerPosition(this.data.ps, this.data.gS, arrangeChauRiaOnly);
	    this.changeSitToInviteBg();
	},
	checkLeaveRoomIfCan: function(){
		var isIdeKick = false;
	    //cc.log("registerQuit "+this.registerQuit);
	    if(this.registerQuit){
	        this.quitRoom(isIdeKick);
	    }else if(this.ideGameNumber >= IDE_GAME_KICK && !this.isViewing){
	        this.ideGameNumber++ ;
	        isIdeKick = true;
	        this.quitRoom(isIdeKick);
	    }
	},
	checkMeIsPlaying: function () {
		var listPlaying = this.data.ps;
	    if (this.gameState >= GAME_STATE.PLAYING) {
	        for (var i = 0; i < listPlaying.length; i++) {
	            if (listPlaying[i].uid === PlayerMe.uid && listPlaying[i].pi) {
	                return true;
	            }
	        }
	    }
	    return false;
	},
	backButtonClickHandler: function (forceQuit) {
		if(TEST_MODE) {
	        LobbyClient.getInstance().quitRoom();
	        return;
	    }
	    var thiz = this;
	    cc.log('click quit room lieng '+ JSON.stringify(this.data.ps) );
	    cc.log('click quit room lieng '+this.checkMeIsPlaying());
	    if(!forceQuit && this.checkMeIsPlaying()){
	        this.registerQuit = !this.registerQuit;
	        if(this.registerQuit) {
	            this.showSystemNotice("Bạn đăng ký thoát bàn khi ván chơi kết thúc");
	            this.registerQuitHandler = function(){
	                // if(!LoadingDialog.getInstance().isShow()) LoadingDialog.getInstance().show();
	                cc.director.getRunningScene().loadingDialog(true);
	                thiz.quitRoom(false);
	            };
	        }else{
	            this.showSystemNotice("Bạn huỷ thoát bàn khi ván chơi kết thúc");
	            this.registerQuitHandler = null;
	        }
	        return;
	    }else if(this.meSitDown){
	        //var dialog = new MessageStandUpOrQuitDialog();
	        this.dialogStandUpQuit.show(true);
	        this.dialogStandUpQuit.showWithAnimationScale();
	        return;
	    }

	    // if(!LoadingDialog.getInstance().isShow()) LoadingDialog.getInstance().show();
	    cc.director.getRunningScene().loadingDialog(true);

	    LobbyClient.getInstance().quitRoom();
	},
	getSitPosArr: function (totalPlayer) {
		if(totalPlayer ===2) this.sitdownPlayerNext = [4];
	    else if(totalPlayer ===3) this.sitdownPlayerNext = [5, 4];
	    else if(totalPlayer ===4) this.sitdownPlayerNext = [7,5 ,4];
	    else if(totalPlayer ===5) this.sitdownPlayerNext = [7,5 ,4,2];
	    else if(totalPlayer ===6) this.sitdownPlayerNext = [7,5 ,4, 3, 2];
	    else if(totalPlayer ===7) this.sitdownPlayerNext = [7, 6, 5 ,4, 3, 2];
	    else if(totalPlayer ===8) this.sitdownPlayerNext = [8, 7, 6, 5 ,4, 3, 2];
	    else if(totalPlayer >=9) this.sitdownPlayerNext = [8, 7, 6, 5 ,4, 3, 2, 1];
	    return this.sitdownPlayerNext;
	},
	processPlayerPosition: function (players, gameState,arrangeChauRiaOnly) {
		//cc.log("processPlayerPosition ");
	    GameScene.prototype.processPlayerPosition.call(this, players, gameState,arrangeChauRiaOnly);
	    var listPlayer = [];
	    var totalPlayer = 0;
	    listPlayer = players;
	    totalPlayer = players.length;

	    var meSitDown = false;
	    var viewerSitedUid =[-1];
	    this.sitIdMyPlayer =-1;
	    var cloneArr =[];
	    for( i =0; i < listPlayer.length; i++){
	        if(PlayerMe.uid === listPlayer[i].uid){
	            meSitDown = true;
	            cloneArr.push(0);
	            if(listPlayer[i].p) this.getSlotByUid(PlayerMe.uid).showRutTienBtn(true);
	            break;
	        }
	    }

	    if (!listPlayer || !listPlayer.length){
	        for(var i = 0 ; i < GamePoker.MAX_SLOT ; i++){
	            this.playerView[i].setEnable(false);
	            this.playerView[i].reset();
	        }
	    }
	    for(var i = 0 ; i < GamePoker.MAX_SLOT ; i++){
	        if(!this.playerView[i].uid || !this.playerView[i].uid.length){
	            if(!meSitDown){
	                this.playerView[i].showNgoiXuong(true);
	                this.playerView[i].showInfoLayer(false);
	            }
	        }
	    }
	},
	getListSlotwinPots: function(pot){
		var listSlotWin =[];
	    cc.each(this.allSlot, function(slot, index){
	        if(slot){
	            if(pot.wns.indexOf(slot.uid ) > -1 ){
	                listSlotWin.push(slot);
	            }
	        }
	    });
	    return listSlotWin;
	},
	getPotsEndGame: function( numPots ){
		var listPots =[];
	    switch (numPots){
	        case 1:
	            listPots = this.potOnTable.slice(4, 4 + 1);// this.potOnTable[4];
	            break;
	        case 2:
	            listPots = this.potOnTable.slice(4, 4 +2);//[4, 5];
	            break;
	        case 3:
	            listPots = this.potOnTable.slice(3, 3 +3);//this.potOnTable[3, 4, 5];
	            break;
	        case 4:
	            listPots = this.potOnTable.slice(3, 3 +4);//[3, 4, 5, 6];
	            break;
	        case 5:
	            listPots = this.potOnTable.slice(2, 2 +5);//[2, 3, 4, 5, 6];
	            break;
	        case 6:
	            listPots = this.potOnTable.slice(2, 2 +6);//[2, 3, 4, 5, 6, 7];
	            break;
	        case 7:
	            listPots = this.potOnTable.slice(1, 1 +7);//[1, 2, 3, 4, 5, 6, 7];
	            break;
	        case 8:
	            listPots = this.potOnTable.slice(1, 1 +8);//[1, 2, 3, 4, 5, 6, 8];
	            break;
	        default:
	            listPots = this.potOnTable;
	            break;
	    }
	    return listPots;
	},
	gopChip: function(pots){
		var thiz = this;
	    var idx;
	    var totoalMoney =0;
	    var totalNumChip =0;
	    cc.each(thiz.chipColumns, function(chipColumnPlayer, i){
	        var chipList = chipColumnPlayer.getChips();
	        if(chipList && chipList.length) totalNumChip+=chipList.length;
	    });
	    for (idx in pots){
	        totoalMoney+= pots[idx].m;
	    };
	    for (idx in pots){
	        pots[idx].chipNumb = Math.floor((pots[idx].m *totalNumChip)/ totoalMoney);
	    };
	    var chipArr =[];
	    cc.each(thiz.chipColumns, function(chipColumnPlayer, i){
	        var chipList = chipColumnPlayer.getChips();
	        if(chipList && chipList.length) chipArr = chipArr.concat(chipList);
	        chipColumnPlayer.hideMucCuoc();
	    });
	    var start = 0 ;
	    var end = 0;
	    //cc.log('-----------move totalNumChip'+ totalNumChip);
	    var listPotsUse = this.getPotsEndGame(pots.length);
	    var chipByPots = [];
	    for (var i = 0 ; i < pots.length ; i++){
	        end = start + pots[i].chipNumb;
	        if(i == pots.length-1) end = chipArr.length;
	        var chips = chipArr.slice(start, end);
	        //cc.log("GamePoker.gopChip ===> slice "+ start + " : "+end);
	        chipByPots.push(chips);
	        start = end;
	    }
	    for (var i = 0 ; i < pots.length ; i++){
	        var chipColumnPot = listPotsUse[i];
	        thiz.groupPots(chipColumnPot, chipByPots[i], pots[i]);
	        chipColumnPot.updateMyMoneyPot(pots[i].m);
	        chipColumnPot.reOrder();
	    }
	    if(pots[0].wns){
	        //co wns win pot la end game
	        var timeMoveLastPots = .5;
	        var cbMovePots = cc.callFunc(function(){
	            thiz.potsToPlayerWin(pots);
	        });
	        this.runAction(cc.sequence(cc.delayTime(timeMoveLastPots),cbMovePots ));

	    }

	    //ChipMng onReset call sau khi gopChipNewRound
	    for( var i=0; i< GamePoker.MAX_SLOT; i++){
	        this.chipColumns[i].chipList = [];//prevent bug
	        // vi luk nay this.chipColumns[i].chipList pointer to chip add in chipColumnPot
	        this.chipColumns[i].onReset();
	    }
	},
	gopChipNewRound: function(pots, isTossChipBefore, isEndGame){
		cc.log("gopChipNewRound "+JSON.stringify(pots) );
	    if(cc.isUndefined(isEndGame) ) isEndGame = false;
	    this.gopChip(pots);
	},
	groupPots: function(chipColumnPot, chipArr, pot){
		var moveToWinPlayer = true;
	    if(cc.isUndefined(pot.uid)) moveToWinPlayer = false;
	    var posWin = cc.p(0,0);
	    if(moveToWinPlayer){
	        var slot = this.getSlotByUid(pot.uid);
	        var slotPos = slot.convertToWorldSpace(slot.getPosition()); //slot.getGlobalPosition();
	        slotPos.x += slot.widthBG/2;
	        slotPos.y += slot.heightBG/2;
	        posWin = chipColumnPot.convertToNodeSpace(slotPos);
	    }



	    for (var k =0; k <chipArr.length; k++  ){
	        var chipObj = chipArr[k];
	        var pos = chipColumnPot.convertToNodeSpace(chipObj.convertToWorldSpace(chipObj.getPosition()) );
	        chipObj.setPosition(pos.x, pos.y);


	        /*if(moveToWinPlayer)
	            chipObj.addOriginWinPot(posWin);
	        else */
	        chipObj.addOriginWinPot(null);
	        chipColumnPot.addChip(chipObj, 0);
	        //cc.log("group chip "+chipObj.chipIndex);
	    }
	},
	potsToPlayerWin: function( pots){
		var listPotUse = this.getPotsEndGame(pots.length);
	    for (var k =0; k <pots.length; k++  ){
	        var pot = pots[k];
	        var potColumn = listPotUse[k] ;
	        this.potToPlayer(pot, potColumn);
	    }
	},
	potToPlayer: function(pot, potColumn){
		var slotList = this.getListSlotwinPots(pot);
	    var posWinArr = [];
	    for(var i = 0 ; i < slotList.length; i++){
	        var slot = slotList[i];

	        var slotPos = slot.convertToWorldSpace(slot.getPosition()); //slot.getGlobalPosition();
	        slotPos.x += slot.widthBG/2;
	        slotPos.y += slot.heightBG/2;
	        var posWin = potColumn.convertToNodeSpace(slotPos);
	        posWinArr.push(posWin);
	    }

	    var index = 0;
	    var chipList = potColumn.getChips();
	    if(chipList && chipList.length){
	        for(var i = 0 ; i < chipList.length; i++){
	            chipList[i].addOriginWinPot(posWinArr[index]);
	            index++;
	            if(index>= posWinArr.length) index = 0;
	        }

	    }
	    potColumn.updateMyMoneyPot(pot.m);
	    potColumn.reOrder();
	},
	initPotsData: function(pots){
		var listPotsUse = this.getPotsEndGame(pots.length);
	    var chipByPots = [];
	    for (var i = 0 ; i < pots.length ; i++){
	        var idPots = pots[i].id -1;
	        var moneyPots = pots[i].m;
	        var numChip = Math.floor(moneyPots/ this.betValue);
	        if(numChip > 8) numChip = 8;
	        var chipIds = [];
	        for(var j = 0 ; j< numChip; j++){
	            chipIds.push(1);
	        }
	        //cc.log("GamePoker.gopChip ===> slice "+ start + " : "+end);
	        listPotsUse[i].addNewChip(chipIds, 0, false, cc.p(0,0));
	        listPotsUse[i].updateMyMoneyPot(moneyPots);

	    }
	},
	updateMoneyPlayerBlinder: function(smallBlind, bigBlind){
		var length = this.players.length;
	    for (var j = 0; j < length;j++) {
	        var el = this.players[j];
	        if(el.uid === smallBlind.uid){
	            el.m -= smallBlind.cb;
	            //cc.log(`update money ${el.dn} = ${data.m}`);

	        }else if(el.uid === bigBlind.uid){
	            el.m -= bigBlind.cb;
	        }
	    }

	    for (var i in this.allSlot) {
	        var slot = this.allSlot[i];
	        if(slot.uid === smallBlind.uid ) slot.reduceMoney(-smallBlind.cb);
	        else if(slot.uid === bigBlind.uid ) slot.reduceMoney(-bigBlind.cb);
	    };
	}
});
GamePoker.X_CHIA_BAI = 550;
GamePoker.MAX_CARD_PLAYER = 5;
GamePoker.cardOriginScaleOnTable = 1;
GamePoker.MAX_SLOT = 9;