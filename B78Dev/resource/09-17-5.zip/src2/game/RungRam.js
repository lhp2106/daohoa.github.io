var RungRam = cc.Node.extend({
	_betting: 0,
	_lines: [],
	_dataJackpot: [{J:0},{J:0},{J:0}],
	_gameId: Constant.GAME_ID.BIGSLOT.RUNGRAM,
	_moneyType: MoneyType.Gold,
	_isTrial: false,
	_trialJackpot: 50000000,
	_onSpin: false,
	_spinFast: false,
	_slotData: null,
	_autoSpin: false,
	_session: false,
	_spinning: {
    	sid: 0,
    	at: 0
    },
    _labelsHu: [null, null, null, null, null],
    _freespinData: {
    	"100":{b:100, ls:[], ai:1, fs:0, win: 0},
        "1000":{b:1000, ls:[], ai:1, fs:0, win: 0},
        "10000":{b:10000, ls:[], ai:1, fs:0, win: 0}
    },
    _dataChoithu : [
        {"iJ":true,"b":10000,"gid":204,"hMG":false,"sbs":[1,1,1,1,1,0,7,4,10,2,9,9,9,10,9],"fss":0,"mX":51162500,"sid":430,"hFS":true,"cmd":1302,"aid":1,"ex2":false,"wls":[{"iJ":true,"crd":50002500,"lid":2},{"iJ":false,"crd":1000000,"lid":6},{"iJ":false,"crd":40000,"lid":8},{"iJ":false,"crd":40000,"lid":9},{"iJ":false,"crd":40000,"lid":18},{"iJ":false,"crd":40000,"lid":22}]},
        {"iJ":false,"b":10000,"gid":204,"hMG":false,"sbs":[5,7,2,1,1,9,1,1,2,1,1,3,6,8,3],"fss":0,"mX":330000,"sid":432,"hFS":false,"cmd":1302,"aid":1,"ex2":true,"wls":[{"iJ":false,"crd":40000,"lid":4},{"iJ":false,"crd":250000,"lid":11},{"iJ":false,"crd":40000,"lid":13}]},
        {"iJ":false,"b":10000,"gid":204,"hMG":false,"sbs":[3,1,1,7,1,9,9,2,3,3,1,8,5,1,2],"fss":0,"mX":290000,"sid":433,"hFS":false,"cmd":1302,"aid":1,"ex2":true,"wls":[{"iJ":false,"crd":250000,"lid":19},{"iJ":false,"crd":40000,"lid":23}]},
        {"iJ":true,"b":10000,"gid":204,"hMG":false,"sbs":[1,1,2,1,3,6,8,6,10,6,1,3,1,3,1],"fss":0,"mX":51120000,"sid":435,"hFS":false,"cmd":1302,"aid":1,"ex2":false,"wls":[{"iJ":false,"crd":40000,"lid":2},{"iJ":false,"crd":40000,"lid":8},{"iJ":false,"crd":1000000,"lid":18},{"iJ":false,"crd":40000,"lid":19},{"iJ":true,"crd":50000000,"lid":23}]},
        {"iJ":true,"b":10000,"gid":204,"hMG":false,"sbs":[8,7,10,3,9,2,9,4,0,8,1,1,1,1,1],"fss":0,"mX":50080000,"sid":436,"hFS":false,"cmd":1302,"aid":1,"ex2":false,"wls":[{"iJ":true,"crd":50000000,"lid":1},{"iJ":false,"crd":40000,"lid":7},{"iJ":false,"crd":40000,"lid":17}]},
        {"iJ":true,"b":10000,"gid":204,"hMG":false,"sbs":[5,0,1,8,8,5,2,10,4,9,1,1,6,1,1],"fss":0,"mX":50580000,"sid":438,"hFS":false,"cmd":1302,"aid":1,"ex2":false,"wls":[{"iJ":false,"crd":40000,"lid":1},{"iJ":false,"crd":250000,"lid":7},{"iJ":true,"crd":50000000,"lid":17},{"iJ":false,"crd":250000,"lid":19},{"iJ":false,"crd":40000,"lid":23}]},
        {"iJ":true,"b":10000,"gid":204,"hMG":false,"sbs":[8,5,0,3,6,8,1,1,1,2,1,2,2,10,1],"fss":0,"mX":100042500,"sid":439,"hFS":false,"cmd":1302,"aid":1,"ex2":false,"wls":[{"iJ":true,"crd":50002500,"lid":4},{"iJ":true,"crd":50000000,"lid":11},{"iJ":false,"crd":40000,"lid":13}]},
        {"iJ":true,"b":10000,"gid":204,"hMG":false,"sbs":[1,5,1,0,1,5,1,6,1,1,0,1,2,8,6],"fss":0,"mX":101742500,"sid":441,"hFS":false,"cmd":1302,"aid":1,"ex2":false,"wls":[{"iJ":false,"crd":40000,"lid":1},{"iJ":false,"crd":40000,"lid":3},{"iJ":false,"crd":1000000,"lid":4},{"iJ":true,"crd":50002500,"lid":7},{"iJ":false,"crd":40000,"lid":11},{"iJ":false,"crd":40000,"lid":12},{"iJ":false,"crd":40000,"lid":13},{"iJ":true,"crd":50000000,"lid":14},{"iJ":false,"crd":250000,"lid":17},{"iJ":false,"crd":40000,"lid":20},{"iJ":false,"crd":250000,"lid":24}]},
        {"iJ":false,"b":10000,"gid":204,"hMG":true,"sbs":[10,4,10,1,1,5,10,5,1,1,9,6,10,6,1],"fss":0,"mX":1500000,"sid":442,"hFS":false,"MG":{"rate":2,"stg":[{"b":0.3,"id":0},{"b":0.6,"id":1},{"b":0.9,"id":2},{"b":1.2,"id":3}],"items":[3,1,3,-1],"m":1500000},"cmd":1302,"aid":1,"ex2":true,"wls":[]},
        {"iJ":false,"b":10000,"gid":204,"hMG":true,"sbs":[9,8,10,8,1,10,10,5,10,3,10,8,1,10,3],"fss":0,"mX":1500000,"sid":443,"hFS":false,"MG":{"rate":4,"stg":[{"b":0.3,"id":0},{"b":0.6,"id":1},{"b":0.9,"id":2},{"b":1.2,"id":3}],"items":[3,0,-1],"m":1500000},"cmd":1302,"aid":1,"ex2":true,"wls":[]},
        {"iJ":false,"b":10000,"gid":204,"hMG":true,"sbs":[4,5,10,1,10,10,1,4,10,0,7,5,5,10,8],"fss":0,"mX":675000,"sid":444,"hFS":false,"MG":{"rate":3,"stg":[{"b":0.3,"id":0},{"b":0.6,"id":1},{"b":0.9,"id":2},{"b":1.2,"id":3}],"items":[1,0,-1],"m":675000},"cmd":1302,"aid":1,"ex2":true,"wls":[]},
        {"iJ":false,"b":10000,"gid":204,"hMG":false,"sbs":[3,4,1,7,9,8,7,8,3,4,3,0,0,1,6],"fss":0,"mX":360000,"sid":454,"hFS":false,"cmd":1302,"aid":1,"ex2":true,"wls":[{"iJ":false,"crd":160000,"lid":1},{"iJ":false,"crd":20000,"lid":5},{"iJ":false,"crd":20000,"lid":10},{"iJ":false,"crd":160000,"lid":20}]},
        {"iJ":false,"b":10000,"gid":204,"hMG":true,"sbs":[10,6,7,1,10,7,10,1,0,9,0,6,6,6,3],"fss":0,"mX":1050000,"sid":455,"hFS":false,"MG":{"rate":2,"stg":[{"b":0.3,"id":0},{"b":0.6,"id":1},{"b":0.9,"id":2},{"b":1.2,"id":3}],"items":[0,0,1,0,-1],"m":750000},"cmd":1302,"aid":1,"ex2":true,"wls":[{"iJ":false,"crd":250000,"lid":1},{"iJ":false,"crd":50000,"lid":23}]}
    ],
    ctor: function(){
    	this._super();
    	this.setPosition(cc.winSize.width/2, cc.winSize.height/2);

    	this._speaker = new AudioDevice();
    	this._speaker.setData({
    		"background": "res/deadoralive/sound/nen.mp3",
    		"soundSpin": "res/deadoralive/sound/spinLoop.mp3",
	    	"spinStart": "res/deadoralive/sound/spinStart.mp3",
	    	"soundColStop": "res/deadoralive/sound/spinStop.mp3",
	    	"coinUpLoop": "res/deadoralive/sound/coinUpLoop.mp3",
	    	"winNormal": [
	    		"res/deadoralive/sound/winNormal/1.mp3",
	    		"res/deadoralive/sound/winNormal/2.mp3",
	    		"res/deadoralive/sound/winNormal/3.mp3",
	    		"res/deadoralive/sound/winNormal/4.mp3",
	    		"res/deadoralive/sound/winNormal/5.mp3",
	    		"res/deadoralive/sound/winNormal/6.mp3",
	    		"res/deadoralive/sound/winNormal/7.mp3",
	    		"res/deadoralive/sound/winNormal/8.mp3",
	    		"res/deadoralive/sound/winNormal/9.mp3",
	    		"res/deadoralive/sound/winNormal/10.mp3",
	    		"res/deadoralive/sound/winNormal/11.mp3"
	    	],
	    	"winJackpot": "res/deadoralive/sound/winJackpot.mp3",
	    	"buttonClick": "res/deadoralive/sound/buttonClick.mp3",
	    	"openOtherRuong": "res/deadoralive/sound/openOtherRuong.mp3",
	    	"hoverRoom": "res/deadoralive/sound/hoverRoom.mp3"
    	});

		var bg0 = new cc.Sprite("res/rungram/khung2.jpg");
		bg0.y = 12;
		this.addChild(bg0);

		this.columns = [];

        var items = [];
        for( var i=0; i<=10; i++ ){
        	items.push( cc.spriteFrameCache.getSpriteFrame(i+"_rungram.png") );
        }

        for(var i=0; i<5; i++){
        	var col = new Column2({
        		itemH: 158,
        		items: items,
        		index: i,
        		speed: 1000
        	});

        	col.setPosition(i*155-310,-220);
            this.addChild(col);

            this.columns[i] = col;
        }

        this.columns[4].onAfterStop = function(){
        	this._onSpin = false;
        	cc.log("spin done");
		}.bind(this);

		var bg1 = new cc.Sprite("res/rungram/khung1.jpg");
		bg1.y = 309;
		this.addChild(bg1);

		var bg2 = new cc.Sprite("res/rungram/khung3.png");
		bg2.y = -285;
		this.addChild(bg2);

		var linesL = new cc.Sprite("res/rungram/line-left.png");
		linesL.setPosition(-420, 22);
		this.addChild(linesL);

		var linesR = new cc.Sprite("res/rungram/line-right.png");
		linesR.setPosition(420, 22);
		this.addChild(linesR);

		var btnBack = new newui.Button("res/rungram/btn_back.png", function(){
			MH.changePage("home");
		}.bind(this));
		btnBack.setPosition(-584, 315);
		this.addChild(btnBack);

		var btnSetting = new newui.Button("res/rungram/btn_setting.png");
		btnSetting.setPosition(583, 315);
		this.addChild(btnSetting);

		var btnChoiThu = new newui.Button("res/rungram/btn-choithu.png");
		btnChoiThu.setPosition(-584, 196);
		this.addChild(btnChoiThu);

		var btnQuayNhanh = new newui.Button("res/rungram/btn-quaynhanh.png");
		btnQuayNhanh.setPosition(-555, -275);
		this.addChild(btnQuayNhanh);

		var btnTuQuay = new newui.Button("res/rungram/btn-tuquay.png");
		btnTuQuay.setPosition(400, -300);
		this.addChild(btnTuQuay);

		var btnQuay = new newui.Button("res/rungram/btn-quay.png", function(){
			this._sendRequestSpin();
		}.bind(this));
		btnQuay.setPosition(554, -276);
		this.addChild(btnQuay);

		var btnDong = new newui.Button("res/rungram/btn-dong.png");
		btnDong.setPosition(-125, -296);
		this.addChild(btnDong);

		var btnCuocL = new newui.Button("res/rungram/btn-cuocL.png");
		btnCuocL.setPosition(-440, -295);
		this.addChild(btnCuocL);

		var btnCuocR = new newui.Button("res/rungram/btn-cuocR.png");
		btnCuocR.setPosition(-240, -295);
		this.addChild(btnCuocR);
    },
    _sendRequestSpin: function(){
    	if( this._onSpin ) return;
    	this._onSpin = true;
    	this.columns[0].runSpin();
    	this.scheduleOnce(function(){
			this.columns[1].runSpin();
			this.scheduleOnce(function(){
				this.columns[2].runSpin();
				this.scheduleOnce(function(){
					this.columns[3].runSpin();
					this.scheduleOnce(function(){
						this.columns[4].runSpin();
					}.bind(this), 0.2);
				}.bind(this), 0.2);
			}.bind(this), 0.2);
		}.bind(this), 0.2);
    }
});