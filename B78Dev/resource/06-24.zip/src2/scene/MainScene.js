var MainScene = cc.Scene.extend({
    _layerName: "",
    _resCardLoaded: false,
    minigameLayer: null,
    popupLayer: null,
    _openMenuMNG: function(){
        var tagMNG = MH.TAG.MENUMNG;
        var _touched = false;

        this.removeChildByTag(tagMNG);

        var colorLayer = new cc.LayerColor(cc.color(0,0,0,255), cc.winSize.width, cc.winSize.height);
        colorLayer.setOpacity(0);
        colorLayer.setTag(tagMNG);

        this.addChild(colorLayer, 4); // >= btn, < popup

        var bg = new cc.Sprite("res/menu-minigame/bg-minigame.png");
        bg.setPosition(cc.winSize.width/2, cc.winSize.height/2);
        bg.setCascadeOpacityEnabled(true);
        bg.setRotation(180);
        bg.setOpacity(0);
        colorLayer.addChild(bg);

        var arr = [
            {img: "res/menu-minigame/et-icon.png", x: 220, y: 420, gid: "ET"},
            {img: "res/menu-minigame/3la-icon.png" , x: 225, y: 8},
            {img: "res/menu-minigame/larva-icon.png" , x: 430, y: 220},
            {img: "res/menu-minigame/nhiemvu-icon.png" , x: 10, y: 215},
            {img: "res/menu-minigame/minipoker-icon.png" , x: 378, y: 68, gid: "MINIPOKER"},
            {img: "res/menu-minigame/taixiu-icon.png" , x: 67, y: 65, gid: "TAIXIU"},
            {img: "res/menu-minigame/thiendia-icon.png" , x: 375, y: 370},
            {img: "res/menu-minigame/tomcuaca-icon.png" , x: 63, y: 368},
        ];

        for( var i=arr.length-1; i>= 0; i-- ){
            var button = new newui.Button(arr[i].img, function(btn){
                MH.openGame( btn._gid );
                if( _touched ) return;
                _touched = true;
                bg.runAction(cc.rotateTo(0.4, 180));
                colorLayer.runAction(cc.fadeOut(0.3));
                bg.runAction(cc.sequence(cc.delayTime(0.1), cc.fadeOut(0.3), cc.callFunc(function(){
                    colorLayer.removeFromParent(true);
                })));
            }.bind(this));

            button._gid = arr[i].gid;
            button.setPosition(cc.p(arr[i].x, arr[i].y));
            bg.addChild(button);
        }

        bg.runAction(cc.rotateTo(0.3, 0));
        bg.runAction(cc.fadeIn(0.3));

        colorLayer.runAction(cc.fadeTo(0.3, 180));

        cc.eventManager.addListener({
            event: cc.EventListener.TOUCH_ONE_BY_ONE,
            swallowTouches: true,
            onTouchBegan: function(touch, event){
                return true;
            },
            onTouchEnded: function(touch, event){
                if( _touched ) return;
                _touched = true;
                bg.runAction(cc.rotateTo(0.4, 180));
                colorLayer.runAction(cc.fadeOut(0.3));
                bg.runAction(cc.sequence(cc.delayTime(0.1), cc.fadeOut(0.3), cc.callFunc(function(){
                    colorLayer.removeFromParent(true);
                })));
            }.bind(this),
        }, colorLayer);
    },
    _setButtonPosition: function(pos){
        var winSize = cc.winSize, _x = 0, _y = pos.y;
        var btnSize = this.btnMenu.getContentSize();

        if( pos.x > winSize.width/2 ) _x = winSize.width - btnSize.width/2;
        else _x = btnSize.width/2;

        if( _y < btnSize.height/2 ) _y = btnSize.height/2;
        else if( _y > winSize.height-btnSize.height/2 ) _y = winSize.height-btnSize.height/2;

        return cc.p(_x, _y);
    },
    showMessage: function(_s, _t){
        this.removeChildByTag(MH.TAG.NOTIFY);
        var wrap = new cc.Node();
        wrap.setPosition(cc.winSize.width/2, 100);
        wrap.setOpacity(0);
        wrap.setCascadeOpacityEnabled(true);
        wrap.setTag(MH.TAG.NOTIFY);
        this.addChild(wrap, 9998);

        var bg = new cc.Scale9Sprite("res/input_default.png");
        wrap.addChild(bg);

        var lb = new cc.LabelTTF(_s, MH.getFont("Font_Default"), 32);
        lb.y = -5;
        lb.setAnchorPoint(0.5, 0.5);
        wrap.addChild(lb);

        bg.width = lb.width + 60;
        

        var timeOut = 3;
        if( _t ) timeOut = _t;

        wrap.runAction( new cc.FadeIn(0.2) );
        wrap.runAction( new cc.Sequence(new cc.MoveTo(0.2, cc.p( cc.winSize.width/2, 200 )), new cc.DelayTime(timeOut) , new cc.CallFunc(function(){ wrap.removeFromParent(true);})) );
    },
    loadingDialog: function(_text, _timeout, callback){
        if( arguments.length === 1 && arguments[0] === false ){
            this.removeChildByTag( MH.TAG.LOADING );
            return;
        }else if( arguments.length === 1 && arguments[0] === true ){
            var isShow = this.getChildByTag( MH.TAG.LOADING );
            if( isShow ) return;
            else {
                _timeout = 10;
                callback = null;
            }
        }else if( arguments.length === 1 && cc.isString(_text) ){
            _timeout = 10;
            callback = function(){
                this.loadingDialog(false);
                var isLogin = LobbyClient.getInstance().isLoginDone();
                var isClickLogin = LobbyClient.getInstance().isClickLogin();
                var currentScene = this.getPageName(); //home || game || play || signup \\ playslot(tamgioi)

                cc.log("loadingDialog timeout");
                // cc.log(MyPixi.isDestroy +" --- "+ isClickLogin);
                if(currentScene == "home"){
                    cc.log("timeout and reconnect");
                    LobbyClient.getInstance().changeServerAndLoginAgain();
                    /*MH.logOut();
                    MH.createPopup({
                        title:'Mất kết nối',
                        content:[
                            {
                                tag:'p',
                                //text:"Hệ thống thử kết nối lại cho bạn nhưng không thành công",
                                text:"Đăng nhập thất bại",
                            }
                        ]
                    });*/

                }else{
                    LobbyClient.getInstance().reConnect();
                }
            }.bind(this);
        }

        this.removeChildByTag( MH.TAG.LOADING );

        var winSize = cc.winSize;

        var colorLayer = new cc.LayerColor(cc.color(0,0,0,180), winSize.width, winSize.height);
        colorLayer.setTag(MH.TAG.LOADING);

        var iconLoading = new cc.Sprite("res/icon-loading.png");
        iconLoading.setPosition( winSize.width/2, winSize.height/2);
        colorLayer.addChild(iconLoading);

        if( _text && cc.isString(_text) ){
            iconLoading.y += 30;

            var textLabel = new cc.LabelTTF(_text, MH.getFont("Font_Default"), 24);
            textLabel.setPosition( winSize.width/2, winSize.height/2-100+30);
            colorLayer.addChild(textLabel);
        }

        this.addChild(colorLayer, 9999);

        cc.eventManager.addListener({
            event: cc.EventListener.TOUCH_ONE_BY_ONE,
            swallowTouches:true,
            onTouchBegan : function (touch, event) {
                return true;
            }
        }, colorLayer);

        if( !_timeout ) _timeout = 10;

        var iconAction = new cc.Sequence( new cc.RotateBy(_timeout, 360*_timeout), new cc.CallFunc(function(){
            if( callback && cc.isFunction(callback) ) callback.call(null);
        }));

        iconLoading.runAction( iconAction );
    },
    getPageName: function(){
        return this._layerName;
    },
    openGame: function(k, data){
        // check login
        // check game card
        // check login slotserver
        // check bigslot
        // minigame
        if( !LobbyClient.getInstance().isLoginDone() ){
            MH.openPopup("Login");
            return;
        }

        if( Constant.GAME_ID[ k ] ){
            if(Constant.GAME_ID_DONE.indexOf(Constant.GAME_ID[ k ]) !== -1 ){
                MH.changePage('game', {gameId: Constant.GAME_ID[ k ]});
            }else{
                this.showMessage("Game đang bảo trì, vui lòng chơi game khác");
            }
        }else if(0 && !MiniGameClient.getInstance().isLoginDone() ){
            this.showMessage("Lỗi server, vui lòng chơi game khác hoặc đăng nhập lại");
        }else{
            if( Constant.GAME_ID.BIGSLOT[k] ){
                MH.loadRes(m_resources[k], function(target, total, count){
                    LobbyClient.getInstance().postEvent(kCMD.PROGESS_OPEN_GAME, {total: total, count: count, game: k});
                }, function(){
                    this.changePage("slot", k);
                }.bind(this));
            }else if( Constant.GAME_ID.MINIGAME[k] ){
                var _tag = MH.TAG[k];
                if( !_tag ){
                    cc.log("not have tag for "+ k);
                    return;
                }
                var node = this.minigameLayer.getChildByTag( _tag );
                if( node ) return;

                MH.loadRes(m_resources[k], function(target, total, count){
                    LobbyClient.getInstance().postEvent(kCMD.PROGESS_OPEN_GAME, {total: total, count: count, game: k});
                }, function(){
                    // MinigamePlugin.getInstance()._create(k);
                    var game = null;
                    switch(k){
                        case "TAIXIU":
                            game = new TaiXiu();
                            break;
                        case "MINIPOKER":
                            game = new Minipoker();
                            break;
                        case "ET":
                            game = new ET();
                            break;
                    }

                    if( game ){
                        this.minigameLayer.addChild(game);
                        game.gameName = k;
                    }
                }.bind(this));
            }else{
                this.showMessage("Đã có lỗi xảy ra khi cố mở game");
            }
        }
    },
    changePage: function(pname, data){
        // ['loading', 'home', 'game', 'play', 'signup', 'gameslot', 'playslot']
        var newLayer = null;

        switch( pname ){
            case "home":
                newLayer = new LobbyScene();
                break;
            case "game":
            case "play":
                if( this._resCardLoaded ){
                    if( pname === "game" ) newLayer = new ChonBanScene(data);
                    else newLayer = new PlayScene(data);
                }else{
                    var gameId = (pname === "play")? cc.Global.gameId : data.gameId;
                    var gameName = "";
                    cc.each(Constant.GAME_ID, function(v, k){
                        if( v === gameId ){
                            gameName = k;
                            return;
                        }
                    });

                    MH.loadRes(m_resources["CARD"], function(target, total, count){
                        LobbyClient.getInstance().postEvent(kCMD.PROGESS_OPEN_GAME, {total: total, count: count, game: gameName});
                    }, function(){
                        this._resCardLoaded = true;
                        this.changePage(pname, data);
                    }.bind(this));
                }
                break;
            case "slot":
                // data
                if( data === "LONGVUONG" ) newLayer = new LongVuong();
                else if( data === "DEADORALIVE" ) newLayer = new DeadOrAlive();
                else if( data === "RUNGRAM" ) newLayer = new RungRam();
                break;
            default:
                cc.log("page not found "+pname);
                break;
        }

        if( newLayer ){
            var oldLayer = this.getChildByTag(1111);
            if( oldLayer ) this.removeChild( oldLayer, true );

            newLayer.setTag(1111);
            this.addChild(newLayer);
            this._layerName = pname;
        }
    },
    onEnter: function(){
        this._super();

        this.minigameLayer = new cc.Node();
        this.addChild(this.minigameLayer, 3);
        this.popupLayer = new cc.Node();
        this.addChild( this.popupLayer, 5);

        var mngIcon = MH.skeletonAnimation("res/menu-minigame/Icon-MiniGame.json", "res/menu-minigame/Icon-MiniGame.atlas");
        mngIcon.setAnimation(0, 'Idle', true);
        mngIcon.setPosition( cc.p(1200, 570));
        this.addChild(mngIcon, 4);

        this.wrapTimer = new cc.Sprite("res/menu-minigame/minigame-dem-taixiu.png");
        this.wrapTimer.setPosition(29, 37);
        mngIcon.addChild( this.wrapTimer );
        this.wrapTimer.setVisible(false);

        this.changePage("home");

        var btnOldPos = mngIcon.getPosition();
        var sprSize = cc.size(105,87);
        var locationInNode = null;

        cc.eventManager.addListener({
            event: cc.EventListener.TOUCH_ONE_BY_ONE,
            swallowTouches: true,
            onTouchBegan: function(touch, event){
                locationInNode = mngIcon.convertToNodeSpace(touch.getLocation());
                var rect = cc.rect(0, 0, sprSize.width, sprSize.height);
                if (cc.rectContainsPoint(rect, {x: locationInNode.x + sprSize.width/2, y: locationInNode.y + sprSize.height/2 })){
                    // có thể nó muốn kéo đi nên ko open ở đây
                    btnOldPos = mngIcon.getPosition();
                    return true;
                }
                return false;
            },
            onTouchMoved: function(touch, event){
                var tL = touch.getLocation();
                mngIcon.setPosition( tL.x - locationInNode.x, tL.y - locationInNode.y);
            },
            onTouchEnded: function(touch, event){
                var newPos = mngIcon.getPosition();

                if( (newPos.x-btnOldPos.x)*(newPos.x-btnOldPos.x) + (newPos.y-btnOldPos.y)*(newPos.y-btnOldPos.y) < 200 ){
                    this._openMenuMNG();
                }

                if( newPos.x > cc.winSize.width/2 ) newPos.x = cc.winSize.width - sprSize.width/2;
                else newPos.x = sprSize.width/2;

                if( newPos.y < sprSize.height/2 ) newPos.y = sprSize.height/2;
                else if( newPos.y > cc.winSize.height-sprSize.height/2 ) newPos.y = cc.winSize.height-sprSize.height/2;

                mngIcon.runAction( new cc.MoveTo(0.15, newPos ) );
            }.bind(this),
        }, this);

        // auto login
        var _name = cc.sys.localStorage.getItem("username"),
            _pass = cc.sys.localStorage.getItem("password");

        if( _name && _pass ){
            LobbyClient.getInstance().login( _name, _pass, function(){
                // reset view
                this.changePage("home");
                // cc.log("login minigame");
                // MiniGameClient.getInstance().login('megabit', '123qwe');
                // MH.loginDone( PlayerMe );
                // MH.openGame("TLMN");
            }.bind(this), function(){
                // this.showMessage('Đăng nhập lại không thành công');
            }.bind(this));
        }else{
            LobbyClient.getInstance().loadConfig();
        }
    }
});