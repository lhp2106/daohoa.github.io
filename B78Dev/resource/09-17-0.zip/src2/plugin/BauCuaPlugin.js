/**
 * Created by hiepnh on 9/19/17.
 * API DOC HERE => https://docs.google.com/document/d/1Ckg0cLKUEtdmlFIEaXA-z1VLvlnyxBih3Yb99K-qdqE/edit
 *
 * CALL register/unRegister when open/close minigame => onRegisterResponse tra ve data
 */
var BauCuaPlugin = (function() {
    var instance = null;
    var BauCuaPluginClass = cc.Class.extend({
        ctor: function () {
            this.pluginName = "griffinPlugin";
            this.zoneName = MiniGameClient.getInstance().zoneName;

            this.ERROR_ID = {
                4500  : "TIền cược không hợp lệ",
                4501 : "Số dư không đủ",
                4502 : "Hết thời gian đặt cược",
                4503 : "Phiên trước không đặt"
            };

            this.GAME_STATE = {
                BETTING  : 1,//Đang đặt cược
                REWARD :2,////Đang trả thưởng

            };
            this.gameState = -1;

            this.addListener(baucuaCMD.REGISTER.toString(), this.onRegisterResponse, this);

            this.addListener(baucuaCMD.BEGIN_GAME.toString(), this.onBeginGameResponse, this);
            /*
                bắt đầu BauCua
             */
            this.addListener(baucuaCMD.ACCEPT_BET.toString(), this.onAcceptBetResponse, this);
            /*
             bắt đầu nhận lộc
             */
            this.addListener(baucuaCMD.END_GAME.toString(), this.onEndGameResponse, this);
            this.addListener(baucuaCMD.RESULT_GAME.toString(), this.onResultResponse, this);
            /*
             BauCua
             */
            this.addListener(baucuaCMD.BET_AGAIN.toString(), this.onBetAgainResponse, this);
            /*
             nhận lộc
             */
            this.addListener(baucuaCMD.DOUBLE_BET.toString(), this.onDoubleBetResponse, this);
            /*
             ket thuc
             */
            this.addListener(baucuaCMD.GET_TOP.toString(), this.onGetTopResponse, this);

            this.addListener(baucuaCMD.UPDATE_JACKPOT.toString(), this.onUpdateJackPotResponse, this);

        },
        addListener: function(command, _listener, _target){
            MiniGameClient.getInstance().addListener( command , _listener, _target);
        },
        send: function(sendObj){
            MiniGameClient.getInstance().send(sendObj);
        },
        /**
         *
         * @param data
         *      cmd:Int = //mã command,
                 c:Int = //mã lỗi,
                 msg:String = //thông báo lỗi
         */
        checkError: function(data){
            var error = [false, ""];
            if(data && data.c){
                error[0] = true;
                error[1] =this.ERROR_ID[data.c];
            }
            return error;
        },
        register: function(roomId){
            var msg = {
                'cmd': baucuaCMD.REGISTER
            };
            if(roomId){
                msg = {
                    'cmd': baucuaCMD.REGISTER,
                    'rId': roomId
                };
            }
            var sendObj = [
                command.ZonePluginMessage,
                this.zoneName,
                this.pluginName,
                msg
            ];
            cc.log("baucua::  register baucua send "+JSON.stringify(sendObj));
            this.send(sendObj);
        },
        unRegister: function(){
            var sendObj = [
                command.ZonePluginMessage,
                this.zoneName,
                this.pluginName,
                {
                    'cmd': baucuaCMD.UNREGISTER
                }
            ];
            cc.log("baucua::  unRegister baucua send "+JSON.stringify(sendObj));
            this.send(sendObj);
        },
        acceptBetTest: function(roomId){
            var sendObj = [
                command.ZonePluginMessage,
                this.zoneName,
                this.pluginName,
                {
                    'cmd': baucuaCMD.ACCEPT_BET,
                    'rId': roomId,
                    'bts': [
                            {"did":Constant.BAUCUA_ID.BAU, "bM":1000},
                            {"did":Constant.BAUCUA_ID.CUA, "bM":2000},
                            ]
                }
            ];
            cc.log("baucua::  acceptBet baucua send "+JSON.stringify(sendObj));
            this.send(sendObj);
        },
        /**
         * Sau khi dặt cược hết phải send accpetbet thì mới tính dặt cược thành công
         * arrBet = [{
         *              “did”:Int = //mã ô cược lấy trong Constant.BAUCUA_ID
                        “bM”:Int = //số tiền đặt
         *         }]
         */
        acceptBet: function(roomId, arrBet){
            var sendObj = [
                command.ZonePluginMessage,
                this.zoneName,
                this.pluginName,
                {
                    'cmd': baucuaCMD.ACCEPT_BET,
                    'rId': roomId,
                    'bts': arrBet
                }
            ];
            cc.log("baucua::  acceptBet baucua send "+JSON.stringify(sendObj));
            this.send(sendObj);
        },
        /**
         *  x2 cươc của ván trước
         */
        doubleBet: function(roomId){
            var sendObj = [
                command.ZonePluginMessage,
                this.zoneName,
                this.pluginName,
                {
                    'cmd': baucuaCMD.DOUBLE_BET,
                    'rId': roomId
                }
            ];
            cc.log("baucua::  doubleBet send "+JSON.stringify(sendObj));
            this.send(sendObj);
        },
        betAgain: function(roomId){
            var sendObj = [
                command.ZonePluginMessage,
                this.zoneName,
                this.pluginName,
                {
                    'cmd': baucuaCMD.BET_AGAIN,
                    'rId': roomId
                }
            ];
            cc.log("baucua::  betAgain send "+JSON.stringify(sendObj));
            this.send(sendObj);
        },
        getHistory: function(limit, skip){
            var sendObj = [
                command.ZonePluginMessage,
                this.zoneName,
                this.pluginName,
                {
                    'cmd': baucuaCMD.GET_HISTORY,
                    'sk': skip,
                    'lm': limit
                }
            ];
            cc.log("baucua::  getHistory send "+JSON.stringify(sendObj));
            this.send(sendObj);
        },


        getTop: function(){
            var sendObj = [
                command.ZonePluginMessage,
                this.zoneName,
                this.pluginName,
                {
                    'cmd': baucuaCMD.GET_TOP
                }
            ];
            cc.log("baucua::  getTop send "+JSON.stringify(sendObj));
            this.send(sendObj);
        },
        onRegisterResponse: function (cmd, data) {
            cc.log("baucua::  onRegisterResponse "+JSON.stringify(data));
            /*[5,{"bts":[{"bts":[{"uBM":0,"tbt":0,"did":1},{"uBM":0,"tbt":0,"did":2},
                {"uBM":0,"tbt":0,"did":3},{"uBM":0,"tbt":0,"did":4},{"uBM":0,"tbt":0,"did":5},
                {"uBM":0,"tbt":0,"did":6}],"rId":1000}],"tfc":20000,"tFB":60000,"tfD":5000,"rMT":2000,
                "rrI":[10000,100000,1000],"bsI":[1000,5000,10000,50000,100000],
                "hr":[[1,5,2],[4,4,6],[6,2,3],[2,2,4],[3,2,3],[6,1,4],[3,3,3],[3,4,4],[2,3,1],[4,2,2],
                    [5,4,3],[5,1,4],[5,3,3],[6,1,5],[1,1,4],[1,6,3],[2,3,6],[3,5,5],[6,6,4],[1,6,1],
                    [3,6,2],[4,4,3],[6,1,1],[6,5,4],[6,4,5],[3,6,1],[6,3,3],[2,6,6],[4,2,2],[5,5,2],
                    [5,3,5],[2,2,1],[1,4,6],[6,5,2],[4,3,1],[1,2,3],[6,2,5],[6,5,2],[2,2,2],[1,5,1],
                    [3,3,4],[4,5,1],[4,5,2],[6,6,4]]
                ,"cmd":7500,"gs":1,"sId":2724}]*/


            this.gameState = data[1].gs;// so sanh voi this.GAME_STATE.BETTING or this.GAME_STATE.REWARD
            this.roomArr = data[1].rri;//ds cac phong` choi
        },

        onBeginGameResponse: function (cmd, data) {
            cc.log("baucua::  onBeginGameResponse "+JSON.stringify(data));
            /*[5,{"tFB":60000,"tfD":5000,"cmd":7501}]
            {
                tFB:integer = //thời gian đặt cuoc,
                    tfD:integer = //thời gian giới hạn,
                cmd:integer = 7501
            }*/
        },
        onAcceptBetResponse: function (cmd, data) {
            cc.log("baucua::  onAcceptBetResponse "+JSON.stringify(data));
            var err = this.checkError(data);
            if(!err[0]){
                //
            }else{
                //error
                cc.log(err[1]);
            }
        },
        /**
         *  KET QUA xuc xac
         */
        onResultResponse: function (cmd, data) {
            cc.log("baucua::  onResultResponse "+JSON.stringify(data));
            /*[5,{"cmd":7505,"skR":[{"rId":10000,"did":[2,2,3]},
                {"rId":100000,"did":[1,5,4]},{"rId":1000,"did":[4,5,3]}],"sId":2725}]*/

        },
        onEndGameResponse: function (cmd, data) {
            cc.log("baucua::  onEndGameResponse "+JSON.stringify(data));
            /*{
                "cmd":Int = 7504,
                "m":Int =//tiền ng chơi, check exist. nếu thua sẽ ko trả về
                "exM":Int = //tiền thawnsg, check exist. nếu thua sẽ ko trả về
                "sId":Int = // mã phiên
            }*/
        },
        onUpdateBetResponse: function (cmd, data) {
            cc.log("baucua::  onUpdateBetResponse "+JSON.stringify(data));
        },
        onDoubleBetResponse: function (cmd, data) {
            cc.log("baucua::  onDoubleBetResponse "+JSON.stringify(data));
            var err = this.checkError(data);
            if(!err[0]){
                //
            }else{
                //error
                cc.log(err[1]);
            }
        },
        onBetAgainResponse: function (cmd, data) {
            cc.log("baucua::  onBetAgainResponse "+JSON.stringify(data));
            var err = this.checkError(data);
            if(!err[0]){
                //
            }else{
                //error
                cc.log(err[1]);
            }
        },
        onGetTopResponse: function (cmd, data) {
            cc.log("baucua::  onGetTopResponse "+JSON.stringify(data));
        },
        onUpdateJackPotResponse: function (cmd, data) {
            cc.log("baucua::  onUpdateJackPotResponse "+JSON.stringify(data));
        }
    });

    return {
        getInstance: function () {
            if (!instance) instance = new BauCuaPluginClass();
            return instance;
        }
    };
})();