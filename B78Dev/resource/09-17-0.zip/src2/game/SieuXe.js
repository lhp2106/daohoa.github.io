var SieuXe = cc.Node.extend({
	gameId: Constant.GAME_ID.MINIGAME.SIEUXE,
	betting: 1000,
	autoPlay: false,
	moneyType: MoneyType.Gold,
	_onSpin: false,
	_spinFast: false,
	_session: false,
	ctor: function(){
		this._super();

		this.lines = [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19, 20, 21, 22, 23, 24, 25, 26, 27];
		this._slotData = null;
		this._spinning = {
	    	sid: 0,
	    	at: 0
	    };

		this.setPosition(cc.p(cc.winSize.width/2, cc.winSize.height/2+100));
		var bg = new cc.Sprite("res/sieuxe/bgmain.png");
		this.addChild(bg, -2);

		var labelQuy = new newui.LabelBMFont("0", "res/sieuxe/font/font-minigame-export.fnt", cc.TEXT_ALIGNMENT_LEFT);
		labelQuy.setScale(0.75);
		labelQuy.setAnchorPoint(cc.p(0 ,0));
		labelQuy.setPosition(cc.p(-160, 137));
        this.addChild(labelQuy);
        this.labelQuy = labelQuy;

        var locationInNode = null;
        var sprSize = null;
        cc.eventManager.addListener({
            event: cc.EventListener.TOUCH_ONE_BY_ONE,
            swallowTouches: true,
            onTouchBegan: function (touch, event) {
                sprSize = bg.getContentSize();
                locationInNode = bg.convertToNodeSpace(touch.getLocation());
                var rect = cc.rect(0, 0, sprSize.width, sprSize.height);
                if (cc.rectContainsPoint(rect, locationInNode)){
                	return true;
                }
                return false;
            },
            onTouchMoved: function (touch, event) {
                var tL = touch.getLocation();

                var newPos = cc.p( tL.x +sprSize.width/2 - locationInNode.x, tL.y+sprSize.height/2 - locationInNode.y );
                if( newPos.x < -340 ) newPos.x = -340;
                else if( newPos.x > 1555 ) newPos.x = 1555;

                if( newPos.y < -150 ) newPos.y = -150;
                else if( newPos.y > 950 ) newPos.y = 950;

                this.setPosition( newPos );
            }.bind(this),
        }, this);

		var stencil = new cc.DrawNode();
        stencil.drawPoly(
            [cc.p(0, 0),cc.p(375, 0),cc.p(375,339),cc.p(0, 339)],
            cc.color(255, 0, 0, 255),
            0,
            cc.color(255, 255, 255, 0)
        );
        var khung = new cc.ClippingNode(stencil);
        khung.setPosition(cc.p(-260, -234));
        this.addChild(khung, 2);

        var stencil2 = new cc.DrawNode();
        stencil2.drawPoly(
            [cc.p(0, 0),cc.p(234, 0),cc.p(234, 288),cc.p(0, 288)],
            cc.color(255, 0, 0, 255),
            0,
            cc.color(255, 255, 255, 0)
        );
        var khung2 = new cc.ClippingNode(stencil2);
        khung2.setPosition(cc.p(154, -209));
        this.addChild(khung2, 2);

        this.columns = [];
        var items = [];

        // 0 1 2 3 7 8        
        items.push( cc.spriteFrameCache.getSpriteFrame("icon0-sieuxe.png") );
        items.push( cc.spriteFrameCache.getSpriteFrame("icon1-sieuxe.png") );
        items.push( cc.spriteFrameCache.getSpriteFrame("icon2-sieuxe.png") );
        items.push( cc.spriteFrameCache.getSpriteFrame("icon3-sieuxe.png") );
        items.push( cc.spriteFrameCache.getSpriteFrame("icon7-sieuxe.png") );
        items.push( cc.spriteFrameCache.getSpriteFrame("icon8-sieuxe.png") );

        for(var i=0; i<3; i++){
        	var col = new Column({
        		itemH: 113,
        		items: items,
        		speed: 1280,
        		backOut: 30,
        		ids:[0,1,2,3,7,8],
        		index: i
        	});

        	col.setPosition(cc.p(i*125+64,0));

        	col.onBeforeStop = function(target){
        		this.playItemAnimation(target);
        	}.bind(this);

            khung.addChild(col);

            this.columns[i] = col;
            
            this.playItemAnimation(col);
        }

        // 4 5 6 8
        var items2 = [];
        items2.push( cc.spriteFrameCache.getSpriteFrame("icon4-sieuxe.png") );
        items2.push( cc.spriteFrameCache.getSpriteFrame("icon5-sieuxe.png") );
        items2.push( cc.spriteFrameCache.getSpriteFrame("icon6-sieuxe.png") );
        items2.push( cc.spriteFrameCache.getSpriteFrame("icon8-sieuxe.png") );

        for(var i=3; i<5; i++){
        	var col = new Column({
        		itemH: 96,
        		items: items2,
        		speed: 1280,
        		ids:[4,5,6,8],
        		backOut: 60,
        		index: i-3
        	});

        	col.setPosition(cc.p((i-3)*125+48,0));
            khung2.addChild(col);
            this.columns[i] = col;
        }

        this.columns[4].onAfterStop = function(){
        	this.winnerEff();
        }.bind(this);

		this.initButton();
	},
	
	initButton: function(){
		var btnClose = new newui.Button("res/sieuxe/btn_close.png", function(){
			this.close();
		}.bind(this));
		this.addChild(btnClose);
		btnClose.setPosition(cc.p(406, 140));

		var btnVinhDanh = new newui.Button("res/sieuxe/btn_xh.png");
		this.addChild(btnVinhDanh);
		btnVinhDanh.setPosition(cc.p(250, 140));
		
		var btnHelp = new newui.Button("res/sieuxe/btn_help.png", function(){
			this.showHuongDan();
		}.bind(this));
		this.addChild(btnHelp);
		btnHelp.setPosition(cc.p(330, 140));

		var btnInfo = new newui.Button("res/sieuxe/btn_info.png");
		this.addChild(btnInfo);
		btnInfo.setPosition(cc.p(168, 140));

		var btn100 = new newui.Button(["res/sieuxe/cuoc_100.png", "res/sieuxe/cuoc_100_2.png"], function(){
			this.changeBetting(100);
		}.bind(this));
		this.addChild(btn100);
		btn100.setPosition(cc.p(-342, 70));
		this.btn100 = btn100;

		var btn1K = new newui.Button(["res/sieuxe/cuoc_1k.png", "res/sieuxe/cuoc_1k_2.png"], function(){
			this.changeBetting(1000);
		}.bind(this));
		this.addChild(btn1K);
		btn1K.setPosition(cc.p(-342, -40));
		this.btn1K = btn1K;

		var btn10K = new newui.Button(["res/sieuxe/cuoc_10k.png", "res/sieuxe/cuoc_10k_2.png"], function(){
			this.changeBetting(10000);
		}.bind(this));
		this.addChild(btn10K);
		btn10K.setPosition(cc.p(-342, -150));
		this.btn10K = btn10K;

		var btnQuay = new newui.Button("res/sieuxe/quay.png", function(){
			this._sendRequestSpin();
		}.bind(this));
		this.addChild(btnQuay);
		btnQuay.setPosition(cc.p(255, -295));

		var btnTuQuay = new newui.Button(["res/sieuxe/tuquay.png", "res/sieuxe/tuquay2.png"], function(){
			this.changeAutoSpin();
		}.bind(this));
		this.addChild(btnTuQuay);
		btnTuQuay.setPosition(cc.p(30, -300));
		this.btnTuQuay = btnTuQuay;

		var btnSieuToc = new newui.Button(["res/sieuxe/sieutoc.png", "res/sieuxe/sieutoc2.png"], function(){
    		this.changeSpinFast();
    	}.bind(this));
		this.addChild(btnSieuToc);
		btnSieuToc.setPosition(cc.p(-175, -300));
		this.btnSieuToc = btnSieuToc;
	},
	_sendRequestSpin: function(){
		if( this._onSpin ) return;
		this._slotData = null;

		this._spinning.sid = -1;
	    this._spinning.at = (new Date()).getTime();
	    this._onSpin = true;

	    this.removeChildByName("winnerEff", "drawLine");

	    this.columns[0].runSpin();
	    this.columns[1].runSpin();
	    this.columns[2].runSpin();
	    this.columns[3].runSpin();
	    this.columns[4].runSpin();

		this.scheduleOnce(function(){
			if( this._spinning.sid === -1 && new Date().getTime() - this._spinning.at > 50000 ){
	            this.forceStopSpin();
	        }
		}.bind(this), 60);

		var	sendObj = [
			command.ZonePluginMessage,
			Constant.CONSTANT.ZONE_NAME_MINI_GAME,
			miniGamePlugin.PLUGIN_SLOT_GAME,
			{
				'cmd':CMD_SLOT_MACHINE.SPIN,
				'gid':this.gameId,
				'aid':this.moneyType,
				'ls':this.lines,
				'b':this.betting
			}
		];

		MiniGameClient.getInstance().send(sendObj);
	},
	forceStopSpin: function(){
		this.columns[0].stopSpin();
		this.scheduleOnce(function(){
			this.columns[1].stopSpin();
			this.scheduleOnce(function(){
				this.columns[2].stopSpin();
				this.scheduleOnce(function(){
					this.columns[3].stopSpin();
					this.scheduleOnce(function(){
						this.columns[4].stopSpin();
					}.bind(this), 0.3);
				}.bind(this), 0.3);
			}.bind(this), 0.3);
		}.bind(this), 0.3);
	},
	onReceiveSpin: function(data){
		cc.log("SX onReceiveSpin", data);
		if( !data ){ // || this.onSpin
	        this.forceStopSpin();
	        return;
	    }

	    if( data.mgs ){
	        this.notify( data.mgs );
	        this.forceStopSpin();
	        return;
	    }

	    if( !data.hasOwnProperty('sbs') || data.sbs.length != 15 ){
	        this.forceStopSpin();
	        return;
	    }

	    if( this._onSpin && this._spinning.sid === -1 ){
	    	cc.log("data spin okk");
	    	this._slotData = data;
	    	this.setSession( data.sid );
	    	var timeSpin = this._spinFast? 0.5 : 2;

	    	this.scheduleOnce(function(){
	    		this.columns[0].stopSpin();
				this.scheduleOnce(function(){
					this.columns[1].stopSpin();
					this.scheduleOnce(function(){
						this.columns[2].stopSpin();
						this.scheduleOnce(function(){
							this.columns[3].stopSpin();
							this.scheduleOnce(function(){
								this.columns[4].stopSpin();
							}.bind(this), 0.3);
						}.bind(this), 0.3);
					}.bind(this), 0.3);
				}.bind(this), 0.3);
	    	}.bind(this), timeSpin);
	    }
	},
	notify: function(str){
		cc.log("Sieu Xe show Mess", str);
		cc.director.getRunningScene().showMessage(str);
	},
	setSession: function(sid){
		this._session = sid;
	},
	playItemAnimation: function(col){
		var arr = [0, 1, 2, 3];
		var items = col.getChildren();
		for( var i=items.length-1; i>=0; i-- ){
			if( arr.indexOf( items[i].itemId ) != -1 ){
				var anim = MH.skeletonAnimation("res/sieuxe/icon/icon"+items[i].itemId+".json", "res/sieuxe/icon/icon"+items[i].itemId+".atlas");
				anim.setAnimation(0, "Idle", true);
				anim.itemId = items[i].itemId;
				anim.setPosition(items[i].getPosition());
				anim.setTag(items[i].getTag());
				anim.setName("animation");
				col.addChild(anim);
				col.removeChild(items[i], true);
				// bug design
				anim.y -= 57;
			}
		}
	},
	stopItemAnimation: function(item){},
	changeBetting: function(bet){
		if( this._onSpin || this.autoPlay ){
			this.notify("Không được chọn khi đang quay");
			return;
		}
		switch(bet){
			case 100:
				this.btn100.setActive(true);
				this.btn1K.setActive(false);
				this.btn10K.setActive(false);
				this.betting = bet;
				break;
			case 1000:
				this.btn100.setActive(false);
				this.btn1K.setActive(true);
				this.btn10K.setActive(false);
				this.betting = bet;
				break;
			case 10000:
				this.btn100.setActive(false);
				this.btn1K.setActive(false);
				this.btn10K.setActive(true);
				this.betting = bet;
				break;
		}
	},
	changeAutoSpin: function(s){
		if( arguments.length == 0 ) s = !this.autoPlay;
		if( s && !this._onSpin ) this._sendRequestSpin();
		this.autoPlay = s;
		this.btnTuQuay.setActive(s);
	},
	changeSpinFast: function(s){
		if( arguments.length == 0 ) s = !this._spinFast;
		this._spinFast = s;
		this.btnSieuToc.setActive(s);
	},
	showChonDong: function(){},
	showHuongDan: function(){
		var popup = new MHPopupL();
		popup.setTitle("res/sieuxe/help/text-dongdatcuoc.png");
		popup.show();

		// 1010 525
		var scrollView = new ccui.ScrollView();
        scrollView.setDirection(ccui.ScrollView.DIR_VERTICAL);
        scrollView.setBounceEnabled(true);
        scrollView.setContentSize(cc.size(1010, 525));
        scrollView.setInnerContainerSize(cc.size(1010, 1460));
        // scrollView.setPosition(cc.p(132, 163));
        scrollView.y = -25;
        scrollView.setAnchorPoint(cc.p(0.5, 0.5));
        popup.addChild(scrollView);

        var spr = new cc.Sprite("res/sieuxe/help/0.png");
        spr.setAnchorPoint(cc.p(0, 0));
        spr.x = 52;
		scrollView.addChild( spr );
	},
	showVinhDanh: function(){
		var popup = new MHPopupL();
        popup.setTitle("res/popup/title/text-BangVinhDanh.png");
        var table = new newui.TableView(995, 530);
        table.setColumn(0.25, 0.2, 0.15, 0.2, 0.2);
        table.setItemHeight(60);
        table.setHeader("Thời gian", "Tài khoản","Cược", "Thắng", "Loại");
        popup.addContent(table);
        popup.show();

        MyRequest.fetchTopSlotMachine(this.gameId ,function(cmd, obj){
			if( obj && obj.status == 0 && obj.data.items.length ){
				var _len = obj.data.items.length;
				var arr = [];
				for( var i=0; i<_len; i++ ){
					if( obj.data.items[i].assetId == MoneyType.Gold ){
						arr.push([ MH.convertTime(obj.data.items[i].createdTime), obj.data.items[i].displayName, MH.numToText(obj.data.items[i].betting), MH.numToText(obj.data.items[i].money), obj.data.items[i].description]);
					}
				}
				table.setContent(arr);
			}
		}.bind(this));
	},
	drawLine: function(lids, eff, showone){
		this.removeChildByName("drawLine");
		var drawLineWrap = new cc.Node();
		drawLineWrap.setName("drawLine");
		drawLineWrap.setPosition(-62, -58);
		this.addChild(drawLineWrap, 2); // < khung=2
		if( cc.isArray(lids) ){
			if( !eff ){
				for( var i=0; i<lids.length; i++ ){
					var _src = "res/sieuxe/line/line"+(lids[i]+1)+".png";
					drawLineWrap.addChild( new cc.Sprite(_src) );
				}
			}else{
				var i=0;
				var interval = 0.1;
				if( cc.isNumber(eff) ) interval = eff;

				cc.director.getScheduler().schedule(function(){
					if( i<lids.length ){
						if( showone ) drawLineWrap.removeAllChildren(true);
						var _src = "res/sieuxe/line/line"+(lids[i]+1)+".png";
						drawLineWrap.addChild( new cc.Sprite(_src) );
						i++;
					}else{
						if( showone ) drawLineWrap.removeAllChildren(true);
						cc.director.getScheduler().unscheduleAllForTarget(drawLineWrap);
					}
				}, drawLineWrap, interval, false)
			}
		}

	},
	checkHasWin: function(){},
	winnerEff: function(){
		if( !this._slotData ){
			this.changeAutoSpin(false);
			this.scheduleOnce(this.spinDone, 1);
			return;
		}
		var _wls = [],
			_wMoney = 0;
		if( this._slotData.wls && this._slotData.wls.length ){
			_wMoney = this._slotData.mX;
			for( var i=0; i<this._slotData.wls.length; i++ ){
				_wls.push( this._slotData.wls[i].lid );
			}
		}

		if( _wls.length ){
			var label = new newui.LabelBMFont(MH.numToText(_wMoney), "res/sieuxe/font/ET-font1-export.fnt");
			var timeClose = 3;
			// design thieu hiệu ứng. nếu có bỏ vào đây
			var winnerEff = label;

			winnerEff.setName("winnerEff");
			winnerEff.setPosition(-56, 0);
			winnerEff.setAnchorPoint(0.5, 0.5);

			this.addChild(winnerEff, 3); // > khung, lines =2
			label.countTo(_wMoney);

			this.drawLine(_wls);

			this.scheduleOnce(this.spinDone, timeClose);

		}else{
			this.scheduleOnce(this.spinDone, 1);
		}
	},
	spinDone: function(){
		LobbyRequest.getInstance().requestUpdateMoney();
		this._onSpin = false;

		if( this.autoPlay ){
    		this._sendRequestSpin();
    	}else if( this._slotData && this._slotData.wls ){
    		// neu có hieu ưng thắng bigwin/JP ko xóa, cứ để đấy nó play tiếp mới xóa
    		// con lai xóa và highline
    		// vi thiếu hieu ưng nên auto xoa và show lines
    		if( 1 || !this._slotData.bw && !this._slotData.iJ ){
    			this.removeChildByName("winnerEff");
    			var _wls = [];
    			for( var i=0; i<this._slotData.wls.length; i++ ){
					_wls.push( this._slotData.wls[i].lid );
				}
				this.drawLine(_wls, 1, true);
    		}
    	}
	},
	removeChildByName: function(){
		var arr = [];
		for( var i=0; i<arguments.length; i++ ){
			arr.push( arguments[i] );
		}

		var child = this.getChildren();
		for( var i=child.length-1; i>=0; i-- ){
			if( arr.indexOf(child[i].getName()) != -1 ){
				this.removeChild( child[i], true);
			}
		}
	},
	_onObserverResponse: function(){},
	_onReconnectGame: function(){
		MiniGameClient.getInstance().observerByGameID(this.gameId);
	},
	close: function(){
		this.removeFromParent();
	},
	_onTopHuResponse: function(cmd, data){
		if( data && data[1] && data[1].Js && data[1].Js.length ){
	        for( var i = 0; i<data[1].Js.length; i++ ){
	            if( data[1].Js[i].gid === this.gameId && data[1].Js[i].b == this.betting ){
	                this.labelQuy.countTo( data[1].Js[i].J );
	                return;
	            }
	        }
	    }
	},
	_onupdateGame: function(cmd, data){
		if( data[1].gid != this.gameId ) return;
		cc.log("sx _onupdateGame", data);
		switch( parseInt(cmd) ){
			case CMD_SLOT_MACHINE.SPIN :
				this.onReceiveSpin( data[1] );
				break;
			default:
				break;
		}
	},
	onEnter: function(){
		this._super();
		if( !this.autoPlay ) this.changeBetting(1000);
		MiniGameClient.getInstance().addListener( CMD_SLOT_MACHINE.SPIN.toString() , this._onupdateGame, this);
		MiniGameClient.getInstance().addListener( kCMD.OBSERVER_RESPONSE , this._onObserverResponse, this);
		MiniGameClient.getInstance().addListener( CMD_OBSERVER.OBSERVER_SLOT_RECONNECT , this._onReconnectGame, this);
		TopHuClient.getInstance().addListener( kCMD.TOP_HU , this._onTopHuResponse, this);

		// 
		MiniGameClient.getInstance().observerByGameID(this.gameId);
	},
	onExit: function(){
		this._super();
		if( !this.autoPlay ) MiniGameClient.getInstance().removeObserverByGameID(this.gameId);

		MiniGameClient.getInstance().removeListener(this);
		TopHuClient.getInstance().removeListener(this);
	}
})