var TayDuKy = cc.Node.extend({
	_betting: 0,
	_gameId: Constant.GAME_ID.BIGSLOT.TAYDUKY,
	_moneyType: MoneyType.Gold,
	_isTrial: false,
	_trialJackpot: 50000000,
	_onSpin: false,
	_spinFast: false,
	_slotData: null,
	_autoSpin: false,
	_session: false,
	ctor: function(){
		this._super();
		this.setPosition(cc.winSize.width/2, cc.winSize.height/2);
		this.setScale(0.7619047619, 0.7619047619);

		this._lines = [];
		this._dataJackpot = [{J:0},{J:0},{J:0}];
		this._labelsHu = [null, null, null, null, null];
		this._spinning = {
	    	sid: 0,
	    	at: 0
	    };
	    this._freespinData = {
	    	"100":{b:100, ls:[], ai:1, fs:0, win: 0},
	        "1000":{b:1000, ls:[], ai:1, fs:0, win: 0},
	        "10000":{b:10000, ls:[], ai:1, fs:0, win: 0}
	    };

		var wrapLobby = new cc.Node();
    	this.addChild(wrapLobby);
    	this.wrapLobby = wrapLobby;

    	var wrapPlay = new cc.Node();
    	this.addChild(wrapPlay);
    	this.wrapPlay = wrapPlay;

    	// wrapPlay

    	// var bg = new cc.Sprite("res/tayduky/play/bg.jpg");
    	cc.director.getRunningScene().setBackground("res/tayduky/background.jpg");
    	var bg = new cc.Sprite("res/tayduky/play/bg.jpg");
		wrapPlay.addChild(bg);
		bg.setPosition(cc.p(0,15));

		var khung = new cc.Node();
        khung.setPosition(-520, -300);
        wrapPlay.addChild(khung);

    	this.columns = [];

    	var items = [], itemsBlur = [];
        for( var i=0; i<=10; i++ ){
        	items.push( cc.spriteFrameCache.getSpriteFrame(i+"-tayduky.png") );

        	// blur 5 6 7 8 9 spin xấu. ko dùng
        	if( i===5 ) itemsBlur.push( cc.spriteFrameCache.getSpriteFrame(10+"-blur-tayduky.png") );
        	else if( i===6 ) itemsBlur.push( cc.spriteFrameCache.getSpriteFrame(1+"-blur-tayduky.png") );
        	else if( i===7 ) itemsBlur.push( cc.spriteFrameCache.getSpriteFrame(2+"-blur-tayduky.png") );
        	else if( i===8 ) itemsBlur.push( cc.spriteFrameCache.getSpriteFrame(3+"-blur-tayduky.png") );
        	else if( i===9 ) itemsBlur.push( cc.spriteFrameCache.getSpriteFrame(4+"-blur-tayduky.png") );
        	else itemsBlur.push( cc.spriteFrameCache.getSpriteFrame(i+"-blur-tayduky.png") );
        }
        //itemsBlur: itemsBlur,
        for(var i=0; i<5; i++){
        	var col = new Column({
        		itemH: 211,
        		items: items,
        		speed: 2300,
        		backOut: 50,
        		backIn: 30,
        		index: i
        	});

        	col.setPosition(i*250,0);
        	khung.addChild(col);
            this.columns[i] = col;

            if( i>1 ) col.x += i*10;

            col.onBeforeStop = function(target){
        		this.playItemAnimation(target);
        		// this._speaker.playEffect("soundColStop");
        	}.bind(this);

            this.playItemAnimation(col);
        }

        // spin done
        this.columns[4].onAfterStop = function(){
        	// win money [normal.bigwin.jackpot] -> bonus -> freespin
        	// cc.log(this._slotData);
        	this.playStickyWildIfHad();
		}.bind(this);

    	var sprkhung = new cc.Sprite("res/tayduky/play/khung.png");
    	wrapPlay.addChild(sprkhung);

    	//
    	var btnBack = new newui.Button("res/tayduky/play/btn_back.png", function(){
    		if( this._onSpin ){
    			this.notify("Chưa kết thúc phiên")
    		}else this._gotoLobby();
		}.bind(this));
		btnBack.setPosition(-730, 410);
		wrapPlay.addChild(btnBack);

		var lbgold = new newui.LabelBMFont(MH.numToText(PlayerMe.gold), "res/tayduky/font/number.fnt");
		lbgold.setScale(0.6);
		lbgold.setPosition(-410, 414);
		wrapPlay.addChild(lbgold);
		this.lbPlayerGold0 = lbgold;

		var lbhu = new newui.LabelBMFont("0", "res/tayduky/font/number.fnt");
		lbhu.setScale(0.6);
		lbhu.setPosition(30, 414);
		wrapPlay.addChild(lbhu);
		this._labelsHu[4] = lbhu;

		var lbSession = new newui.LabelBMFont("#0", "res/tayduky/font/number.fnt");
		lbSession.setScale(0.6);
		lbSession.setPosition(0, 354);
		wrapPlay.addChild(lbSession);
		this.lbSession = lbSession;

		var btnVinhDanh = new newui.Button("res/tayduky/play/btn_bxh.png", function(){
			this.showVinhDanh();
		}.bind(this));
		btnVinhDanh.setPosition(470,410);
		wrapPlay.addChild(btnVinhDanh);

		var btnSetting = new newui.Button("res/tayduky/play/btn_caidat.png");
		btnSetting.setPosition(625, 410);
		wrapPlay.addChild(btnSetting);

		var btnHelp = new newui.Button("res/tayduky/play/btn_help.png", function(){
			this.showHuongDan();
		}.bind(this));
		btnHelp.setPosition(-183, -423);
		wrapPlay.addChild(btnHelp);

		var btnTuQuay = new newui.Button(["res/tayduky/play/btn_tuquay.png", "res/tayduky/play/btn_dung.png"], function(){
			this.changeAutoSpin();
		}.bind(this));
		btnTuQuay.setPosition(187, -423);
		wrapPlay.addChild(btnTuQuay);
		this.btnTuQuay = btnTuQuay;

		var btnQuay = new newui.Button(["res/tayduky/play/btn_quay_0.png", "res/tayduky/play/btn_quay_1.png"], function(){
			this._sendRequestSpin();
		}.bind(this));
		btnQuay.setPosition(0, -412);
		wrapPlay.addChild(btnQuay);
		this.btnQuay = btnQuay;

		var btnMucCuoc = new newui.Button("res/tayduky/play/p100.png", function(){
			this.changeBetting("UP");
		}.bind(this));// set in change betting
		btnMucCuoc.setPosition(-587,-428);
		wrapPlay.addChild(btnMucCuoc);
		this.btnMucCuoc = btnMucCuoc;

		var btnDong = new newui.Button("res/tayduky/play/btn_dong.png", function(){
			this.showChonDong();
		}.bind(this));
		btnDong.setPosition(-421,-428);
		wrapPlay.addChild(btnDong);

		var lbDong = new newui.LabelBMFont("0", "res/tayduky/font/number.fnt");
		lbDong.setScale(0.5);
		lbDong.setPosition(68, 37);
		btnDong.addChild(lbDong);
		this.lbDong = lbDong;

		var tongThang = new newui.LabelBMFont("0", "res/tayduky/font/number.fnt");
		tongThang.setScale(0.5);
		tongThang.setPosition(399, -426);
		wrapPlay.addChild(tongThang);
		this.lbTongThang = tongThang;

		var tongDat = new newui.LabelBMFont("0", "res/tayduky/font/number.fnt");
		tongDat.setScale(0.5);
		tongDat.setPosition(639, -426);
		wrapPlay.addChild(tongDat);
		this.lbTongDat = tongDat;

		var lbNumFreeSpin = new cc.Sprite("res/tayduky/play/luotquaymp.png");
		lbNumFreeSpin.setPosition(-10, -290);
		lbNumFreeSpin.setVisible(false);
		wrapPlay.addChild(lbNumFreeSpin);
		this.lbNumFreeSpin = lbNumFreeSpin;
		
		var numFreeSpin = new newui.LabelBMFont("0", "res/tayduky/font/number.fnt");
		numFreeSpin.setPosition(405, 7);
		numFreeSpin.setScale(0.6);
		numFreeSpin.setAnchorPoint(0, 0);
		numFreeSpin.setColor(cc.color("#73f589"));
		lbNumFreeSpin.addChild(numFreeSpin);

		var wrapLine = new cc.Node();
		wrapLine.setPosition(-520, 310);
		wrapLine.setVisible(false);
		wrapPlay.addChild(wrapLine);
		this.wrapLine = wrapLine;

		var wrapWin = new cc.Node();
		wrapWin.setVisible(false);
		wrapPlay.addChild(wrapWin);
		this.wrapWin = wrapWin;

		var wrapBonus = new cc.Node();
		wrapBonus.setVisible(false);
		this.addChild(wrapBonus);
		this.wrapBonus = wrapBonus;
	},
	_gotoLobby: function(){
		this._betting = 0;
	    this._isTrial = false;
	    this._onSpin = false;
	    this.changeAutoSpin(false);

		this.wrapPlay.setVisible(false);
		this.wrapLobby.setVisible(true);

		this.wrapLobby.removeAllChildren(true);

		var bg = new cc.Sprite("res/tayduky/lobby/bg.jpg");
		this.wrapLobby.addChild(bg);

		var btnBack = new newui.Button("res/tayduky/lobby/btn_back.png", function(){
			MH.changePage("home");
		});
		btnBack.setPosition(-730, 400);
		this.wrapLobby.addChild(btnBack);

		var btnVinhDanh = new newui.Button("res/tayduky/lobby/btn_bxh.png", function(){
			this.showVinhDanh();
		}.bind(this));
		btnVinhDanh.setPosition(470,400);
		this.wrapLobby.addChild(btnVinhDanh);

		var btnSetting = new newui.Button("res/tayduky/lobby/btn_caidat.png");
		btnSetting.setPosition(625, 400);
		this.wrapLobby.addChild(btnSetting);

		var btnRoom0 = new newui.Button("res/tayduky/lobby/p0.png", function(){
			this.playTrial();
		}.bind(this));
		btnRoom0.setPosition(263,-362);
		this.wrapLobby.addChild(btnRoom0);

		var btnRoom1 = new newui.Button("res/tayduky/lobby/p100.png", function(){
			this.changeBetting(100);
		}.bind(this));
		btnRoom1.setPosition(115,99);
		this.wrapLobby.addChild(btnRoom1);

		var btnRoom2 = new newui.Button("res/tayduky/lobby/p1000.png", function(){
			this.changeBetting(1000);
		}.bind(this));
		btnRoom2.setPosition(114, -35);
		this.wrapLobby.addChild(btnRoom2);

		var btnRoom3 = new newui.Button("res/tayduky/lobby/p10000.png", function(){
			this.changeBetting(1000);
		}.bind(this));
		btnRoom3.setPosition(105,-177);
		this.wrapLobby.addChild(btnRoom3);

		var lbgold = new newui.LabelBMFont(MH.numToText(PlayerMe.gold), "res/tayduky/font/number.fnt");
		lbgold.setScale(0.6);
		lbgold.setPosition(-415, 404);
		this.wrapLobby.addChild(lbgold);
		this.lbPlayerGold1 = lbgold;

		var lbhu = new newui.LabelBMFont("0", "res/tayduky/font/number.fnt");
		lbhu.setScale(0.6);
		lbhu.setPosition(30, 404);
		this.wrapLobby.addChild(lbhu);
		this._labelsHu[3] = lbhu;

		var hu1 = new newui.LabelBMFont("0", "res/tayduky/font/number.fnt");
		hu1.setScale(0.5);
		hu1.setPosition(456, 90);
		this._labelsHu[0] = hu1;
		this.wrapLobby.addChild(hu1);

		var hu2 = new newui.LabelBMFont("0", "res/tayduky/font/number.fnt");
		hu2.setScale(0.5);
		hu2.setPosition(456, -45);
		this.wrapLobby.addChild(hu2);
		this._labelsHu[1] = hu2;

		var hu3 = new newui.LabelBMFont("0", "res/tayduky/font/number.fnt");
		hu3.setScale(0.5);
		hu3.setPosition(456, -192);
		this.wrapLobby.addChild(hu3);
		this._labelsHu[2] = hu3;
	},
	changeBetting: function(bet){
    	if( this._isTrial ){
	        this.notify('Chức năng không hỗ trợ khi chơi thử');
	        return;
	    }

	    if( this._onSpin || this._autoSpin ){
	        this.notify('Chưa kết thúc phiên');
	        return;
	    }

	    if( bet == "UP" ){
	    	if( this._betting == 100 ) this._betting = 1000;
	    	else if( this._betting == 1000 ) this._betting = 10000;
	    	else if( this._betting == 10000 ) this._betting = 100;
	    }else this._betting = bet;

    	this._isTrial = false;
    	this.setSession(0);
    	this.changeAutoSpin( false );

    	this.wrapLobby.setVisible(false);
    	this.wrapPlay.setVisible(true);
		this.wrapLobby.removeAllChildren(true);

    	// tong dat, btn muccuoc
    	this.btnMucCuoc.setTexture("res/tayduky/play/p"+this._betting+".png");
    	this.lbTongDat.setString( MH.numToText( this._betting*this._lines.length ) );
    	this.lbTongThang.setString("0");
    },
	playTrial: function(){
    	if( this._onSpin || this._autoSpin ){
	        this.notify('Chưa kết thúc phiên');
	        return;
	    }

	    this.chooseLines([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24]);
	    this.changeBetting(10000);

    	this._isTrial = true;

        this._trialJackpot = 50000000;
        this.setQuy( this._trialJackpot );
    },
    playBonus: function(){
    	this.wrapPlay.setVisible(false);
    	this.wrapBonus.setVisible(true);
    	this.wrapBonus.removeAllChildren(true);

    	var bg = new cc.Sprite("res/tayduky/popup/bg_popup.jpg");
    	this.wrapBonus.addChild(bg);

    	var title = new cc.Sprite("res/tayduky/popup/title_minigame.png");
    	title.y = 305;
    	this.wrapBonus.addChild(title);

    	var wrap1 = new cc.Node();
    	this.wrapBonus.addChild(wrap1);

    	var wrap2 = new cc.Node();
    	wrap2.setVisible(false);
    	this.wrapBonus.addChild(wrap2);

    	var lb1 = new cc.Sprite("res/tayduky/bonus/lb1.png");
    	lb1.y = 206;
    	wrap1.addChild(lb1);

    	var totalWin = 0;
    	var countClick = 0;
    	var canClick = true;
    	var isFinished = false;

    	var total = new newui.LabelBMFont("0", "res/tayduky/font/number.fnt");
    	total.setPosition(8, -264);
    	total.setScale(0.766);
    	total.setColor(cc.color(255,255,100));
    	wrap1.addChild(total);

    	var finishBonus = function(){
	        if( isFinished ) return;

	        isFinished = true;
	        canClick = false;

	        this.wrapPlay.setVisible(true);
	    	this.wrapBonus.setVisible(false);
	    	this.wrapBonus.removeAllChildren(true);

	    	this.showWin("bonus", this._slotData.MG.m);
	    }.bind(this);

	    var afterClick = function(){
	    	countClick++;
	    	canClick = true;

	    	total.countTo(totalWin, 0.5);

	        if( countClick >= this._slotData.MG.items.length ){
	        	this.scheduleOnce(finishBonus, 1);
	        }

	        // runBnTimmer();
	    }.bind(this);

	    for( var i=0; i<12; i++ ){
    		var item = new newui.Button("res/tayduky/bonus/item/"+(i+1)+".png", function(btn){
    			if( !canClick ) return;
    			// this._speaker.playEffect("buttonClick");

    			if( countClick >= this._slotData.MG.items.length ) return;
        		canClick = false;

        		var _pos = btn.getPosition();

        		if( this._slotData.MG.items[countClick] == -1 ){ // daulau -> mo ruong
        			var daulau = new cc.Sprite("res/tayduky/bonus/item/daulau.png");
        			daulau.setPosition(_pos);
        			wrap1.addChild(daulau);
					wrap1.removeChild(btn);

					wrap2.removeAllChildren(true);
					var lb2 = new cc.Sprite("res/tayduky/bonus/lb2.png");
			    	lb2.y = 175;
			    	wrap2.addChild(lb2);

					this.scheduleOnce(function(){
						wrap1.setVisible(false);
						wrap2.setVisible(true);
					}, 1.5);
					//
					var canOpen = true;
	        		var ruongOther = null;
	        		switch(this._slotData.MG.rate){
			        	case 1:
			        		ruongOther = [2,3];
			        		break;
			        	case 2:
			        		ruongOther = [3,4];
			        		break;
			            case 3:
			                ruongOther = [2,4];
			                break;
			            case 4:
			                ruongOther = [3, 5];
			                break;
			            case 5:
			                ruongOther = [3,4];
			                break;
			            default:
			            	ruongOther = [3,4];
			                break;
			        }

			        for( var i=0; i<3; i++ ){
			        	var ruong = new newui.Button(["res/tayduky/bonus/ruong-lg.png","res/tayduky/bonus/ruong_on.png"], function(btn){
				    		if( !canOpen ) return;
				    		// this._speaker.playEffect("buttonClick");
				    		btn.setActive(true);
				    		var lb = new newui.LabelBMFont("X"+this._slotData.MG.rate, "res/tayduky/font/number.fnt");
				    		lb.setPosition( btn.getPosition() );
				    		lb.setColor(cc.color(255,255,100));
				    		lb.x -= 5;
				    		lb.y += 50;
				    		wrap2.addChild(lb);

				    		var mtag = btn.getTag();
				    		if( ruongOther ){
				    			this.scheduleOnce(function(){
				    				var childs = wrap2.getChildren();
				    				var t = 0;
					    			for( var i=0; i<childs.length; i++ ){
					    				var tag = childs[i].getTag();
					    				if( tag >=0 && tag <=2 && tag !== mtag ){
					    					childs[i].setActive(true);
											childs[i].setCascadeOpacityEnabled(true);
					    					childs[i].setOpacity(150);
					    					var lb = new newui.LabelBMFont("X"+ruongOther[t], "res/tayduky/font/number.fnt");
								    		lb.setPosition( childs[i].getPosition() );
								    		lb.setColor(cc.color(255,255,100));
								    		lb.setOpacity(150);
								    		lb.x -= 5;
								    		lb.y += 50;
								    		wrap2.addChild(lb);
								    		t++;
					    				}
					    			}
				    			}, 1);
				    		}
				    		canOpen = false;
				    		this.scheduleOnce(afterClick, 3);
				    	}.bind(this));
				    	ruong.setTag(i);
				    	ruong.setPosition(-290 + i*300, -30);
				    	wrap2.addChild(ruong);
			        }

        		}else{
        			for( var i=0; i< this._slotData.MG.stg.length; i++ ){
        				var bValue = 0,
		            		valueWin = 0;

		                if( this._slotData.MG.items[countClick] == this._slotData.MG.stg[i].id ){
		                    bValue = this._slotData.MG.stg[i].b2 || this._slotData.MG.stg[i].b||0;
		                    valueWin = this._betting * bValue * this._lines.length;
		                    totalWin += valueWin;

			    			var lb = new newui.LabelBMFont("0", "res/tayduky/font/number.fnt");
					    	lb.setPosition(_pos);
					    	lb.setScale(0.467);
					    	lb.setColor(cc.color(255,255,100));
					    	wrap1.addChild(lb);
					    	lb.countTo(valueWin, 0.5);
		                	afterClick();
		                    break;
		                }
        			}
        		}
        		wrap1.removeChild(btn);
    		}.bind(this));

    		item.setScale(0.8);
    		item.setPosition( -464+(i%6)*185, -135+ Math.floor(i/6)*180 )
    		wrap1.addChild(item);
    	}
    },
    chooseLines: function(arr){
    	if( this._onSpin || this._autoSpin ){
	        this.notify('Chưa kết thúc phiên');
	        return;
	    }
	    if( this._isTrial ){
	        this.notify('Chức năng không hỗ trợ khi chơi thử');
	        return false
	    }
	    this._lines = arr;
	    this.lbDong.setString(arr.length);
	    this.lbTongDat.setString( MH.numToText( this._betting*this._lines.length ) );
    },
    _sendRequestSpin: function(){
    	if( this._onSpin ) return;

    	this._slotData = null;

    	this.showWin(false);
    	this.showLine(false);
    	this._spinning.sid = -1;
	    this._spinning.at = (new Date()).getTime();
	    this._onSpin = true;

    	this.btnQuay.setActive(true);
    	this.lbTongThang.setString("0");
    	// this._speaker.playEffect("spinStart");

		this.columns[0].runSpin();
		this.scheduleOnce(function(){
			this.columns[1].runSpin();
			this.scheduleOnce(function(){
				this.columns[2].runSpin();
				this.scheduleOnce(function(){
					this.columns[3].runSpin();
					this.scheduleOnce(function(){
						this.columns[4].runSpin();
					}.bind(this), 0.2);
				}.bind(this), 0.2);
			}.bind(this), 0.2);
		}.bind(this), 0.2);

		this.scheduleOnce(function(){
			if( this._spinning.sid === -1 && new Date().getTime() - this._spinning.at > 50000 ){
	            this.forceStopSpin();
	        }
		}.bind(this), 60);


		var sendObj = null;
	    if( this._isTrial ){
	        sendObj = [
	            command.ZonePluginMessage,
	            Constant.CONSTANT.ZONE_NAME_MINI_GAME,
	            miniGamePlugin.PLUGIN_SLOT_GAME,
	            {
	                'cmd': CMD_SLOT_MACHINE.SPIN_TRIAL,
	                'gid': this._gameId,
	                'aid': this._moneyType,
	                'ls': this._lines,
	                'b': 10000
	            }
	        ];
	    }else{
	        sendObj = [
	            command.ZonePluginMessage,
	            Constant.CONSTANT.ZONE_NAME_MINI_GAME,
	            miniGamePlugin.PLUGIN_SLOT_GAME,
	            {
	                'cmd': CMD_SLOT_MACHINE.SPIN,
	                'gid': this._gameId,
	                'aid': this._moneyType,
	                'ls': this._lines,
	                'b': this._betting
	            }
	        ];
	    }

	    MiniGameClient.getInstance().send(sendObj);

		// this.onReceiveSpin( this._dataChoithu[ MH.randomInteger(0, this._dataChoithu.length-1 ) ] );
    },
    forceStopSpin: function(){
    	this.columns[0].stopSpin();
		this.scheduleOnce(function(){
			this.columns[1].stopSpin();
			this.scheduleOnce(function(){
				this.columns[2].stopSpin();
				this.scheduleOnce(function(){
					this.columns[3].stopSpin();
					this.scheduleOnce(function(){
						this.columns[4].stopSpin();
					}.bind(this), 0.3);
				}.bind(this), 0.3);
			}.bind(this), 0.3);
		}.bind(this), 0.3);

		this.changeAutoSpin( false );
		this._onSpin = false;
		this.btnQuay.setActive(false);
    },
    playItemAnimation: function(){

    },
    changeAutoSpin: function(type){
    	if( arguments.length === 0 ) type = !this._autoSpin;
		if( type ){
			if( this._isTrial ){
				this.notify('Chức năng không hỗ trợ khi chơi thử');
				return;
			}
			if( !this._onSpin ) this._sendRequestSpin();
		}

		this.btnTuQuay.setActive(type);
		this._autoSpin = type;
    },
    removeChildByName: function(){
		var arr = [];
		for( var i=0; i<arguments.length; i++ ){
			arr.push( arguments[i] );
		}

		var child = this.getChildren();
		for( var i=child.length-1; i>=0; i-- ){
			if( arr.indexOf(child[i].getName()) != -1 ){
				this.removeChild( child[i], true);
			}
		}
	},
    showCaiDat: function(){

    },
    showChonDong: function(){
    	if( this._onSpin || this._autoSpin ){
            this.notify('Chưa kết thúc phiên');
            return;
        }

        if( this._isTrial ){
            this.notify('Chức năng không hỗ trợ khi chơi thử');
            return;
        }

        this.removeChildByName("wrapChonDong");
        var popup = new cc.Node();
        popup.setName("wrapChonDong");
        this.addChild(popup, 99);
    	this.wrapPlay.setVisible(false);

    	var bg = new cc.Sprite("res/tayduky/popup/bg_popup.jpg");
    	popup.addChild(bg);

    	var title = new cc.Sprite("res/tayduky/popup/title_chondong.png");
    	title.y = 305;
    	popup.addChild(title);

    	var btnClose = new newui.Button("res/tayduky/popup/btn-back.png", function(){
    		this.removeChild(popup);
    		this.wrapPlay.setVisible(true);
    	}.bind(this));
    	btnClose.setPosition(0, -412);
    	popup.addChild(btnClose);

    	var btnL = new newui.Button("res/tayduky/popup/btn-left.png");
    	btnL.setPosition(-183, -423);
    	var btnR = new newui.Button("res/tayduky/popup/btn-right.png");
    	btnR.setPosition(187, -423);
    	popup.addChild(btnL);
    	popup.addChild(btnR);

    	for( var i=1; i<=25; i++ ){
			var btn = new newui.Button("res/tayduky/popup/chon_dong/chon/"+i+".png", function(btn){
				var act = btn.getActive(),
					lid = btn.getTag()-100-1;
				// btn.setActive(!act);
				if( act ){//remove
					var _ii = this._lines.indexOf(lid);
					if( _ii !== -1 ) this._lines.splice(_ii, 1);
				}else{//add
					if( this._lines.indexOf(lid) === -1 ) this._lines.push( lid );
				}

				this.chooseLines(this._lines);
				this.showChonDong();
			}.bind(this));
	    	btn.setPosition(-390+(i-1)%5*191 , 180-95*Math.floor((i-1)/5));
	    	popup.addChild(btn);
	    	btn.setTag(100+i);

	    	if( this._lines.indexOf(i-1) == -1 ) btn.setColor(cc.color(100, 100, 100));
	    	else btn.setActive(true);
    	}

    	var btnChan = new newui.Button("res/tayduky/popup/btn_dongchan.png", function(){
    		this.chooseLines([1,3,5,7,9,11,13,15,17,19,21,23]);
    		this.showChonDong();
    	}.bind(this));
    	btnChan.setPosition(-624, -418);
    	popup.addChild(btnChan);
    	var btnLe = new newui.Button("res/tayduky/popup/btn_dongle.png", function(){
    		this.chooseLines([0,2,4,6,8,10,12,14,16,18,20,22,24]);
    		this.showChonDong();
    	}.bind(this));
    	btnLe.setPosition(-394, -418);
    	popup.addChild(btnLe);
    	var btnAll = new newui.Button("res/tayduky/popup/btn_tatca.png", function(){
    		this.chooseLines([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24]);
    		this.showChonDong();
    	}.bind(this));
    	btnAll.setPosition(394, -418);
    	popup.addChild(btnAll);
    	var btnNone = new newui.Button("res/tayduky/popup/btn_bochon.png", function(){
    		this.chooseLines([0]);
    		this.showChonDong();
    	}.bind(this));
    	btnNone.setPosition(630, -418);
    	popup.addChild(btnNone);
    },
    showHuongDan: function(_index){
    	if( !_index ) _index = 1;
    	this.removeChildByName("wrapHuongDan");
        var popup = new cc.Node();
        popup.setName("wrapHuongDan");
        this.addChild(popup, 99);
    	this.wrapPlay.setVisible(false);

    	var bg = new cc.Sprite("res/tayduky/popup/bg_popup.jpg");
    	popup.addChild(bg);

    	var title = new cc.Sprite("res/tayduky/popup/title_bangthuong.png");
    	title.y = 305;
    	popup.addChild(title);

    	var btnClose = new newui.Button("res/tayduky/popup/btn-back.png", function(){
    		this.removeChild(popup);
    		this.wrapPlay.setVisible(true);
    	}.bind(this));
    	btnClose.setPosition(0, -412);
    	popup.addChild(btnClose);

    	var spr = new cc.Sprite("res/tayduky/popup/help/hd"+_index+".png");
    	spr.y = 20;
    	popup.addChild(spr);

    	var btnL = new newui.Button("res/tayduky/popup/btn-left.png", function(){
    		_index -= 1;
    		if( _index<=0 ) _index = 4;
    		this.showHuongDan(_index);
    	}.bind(this));
    	btnL.setPosition(-183, -423);
    	var btnR = new newui.Button("res/tayduky/popup/btn-right.png", function(){
    		_index += 1;
    		if( _index > 4 ) _index = 1;
    		this.showHuongDan(_index);
    	}.bind(this));
    	btnR.setPosition(187, -423);
    	popup.addChild(btnL);
    	popup.addChild(btnR);
    },
    showVinhDanh: function(_index){
    	if( !_index ) _index = 1;
    	this.removeChildByName("wrapVinhDanh");
        var popup = new cc.Node();
        popup.setName("wrapVinhDanh");
        this.addChild(popup, 99);

    	this.wrapPlay.setVisible(false);
    	this.wrapLobby.setVisible(false);

    	var bg = new cc.Sprite("res/tayduky/popup/bg_popup.jpg");
    	popup.addChild(bg);

    	var title = new cc.Sprite("res/tayduky/popup/title_bangvinhdanh.png");
    	title.y = 305;
    	popup.addChild(title);

    	var btnClose = new newui.Button("res/tayduky/popup/btn-back.png", function(){
    		this.removeChildByName("wrapVinhDanh");
    		if( this._betting == 0 ) this.wrapLobby.setVisible(true)
    		else this.wrapPlay.setVisible(true);
    	}.bind(this));
    	btnClose.setPosition(0, -412);
    	popup.addChild(btnClose);

    	var btnL = new newui.Button("res/tayduky/popup/btn-left.png", function(){
    		
    	}.bind(this));
    	btnL.setPosition(-183, -423);
    	var btnR = new newui.Button("res/tayduky/popup/btn-right.png", function(){
    		
    	}.bind(this));
    	btnR.setPosition(187, -423);
    	popup.addChild(btnL);
    	popup.addChild(btnR);

    	var table = new newui.TableView(1255, 545);
        table.setColumn(0.25, 0.2, 0.15, 0.2, 0.2);
        table.setItemHeight(60);
        table.setHeader("Thời gian", "Tài khoản","Phòng", "Thắng", "Mô Tả");
        popup.addChild(table);

        table.y -= 14;

        MyRequest.fetchTopSlotMachine(this._gameId ,function(cmd, obj){
			if( obj && obj.status == 0 && obj.data.items.length ){
				var _len = obj.data.items.length;
				var arr = [];
				for( var i=0; i<_len; i++ ){
					if( obj.data.items[i].assetId == MoneyType.Gold ){
						arr.push([ MH.convertTime(obj.data.items[i].createdTime), obj.data.items[i].displayName, MH.numToText(obj.data.items[i].betting), MH.numToText(obj.data.items[i].money), obj.data.items[i].description]);
					}
				}
				table.setContent(arr);
			}
		}.bind(this));
    },
    playStickyWildIfHad: function(){
    	var hasWild = false;
		var colsWild = [];
		

		for( var i=0; i< this._slotData.sbs.length; i++ ){
			if( this._slotData.sbs[i] == 0 ){
				hasWild = true;
				if( colsWild.indexOf(i%5) == -1 ) colsWild.push(i%5); // col index = i%5
			}
		}

		if( hasWild ){
			// this.createSound("stickyWild");
			for( var i=0; i<colsWild.length; i++ ){
				if( i==0 ) this.showColStickyWild(colsWild[i], function(){
				this.checkHasWin();
			}.bind(this));
				else this.showColStickyWild(colsWild[i]);
			}
		}else{
			this.checkHasWin();
		}
    },
    showColStickyWild: function(colId, cb){
    	if( !this.stickyWildFrames ){
    		this.stickyWildFrames = [];
			for( var ii = 0; ii<55; ii++ ){
				var t = ii;
				if( t < 10 ) t = '00' + t;
				else t = '0'+t;
				this.stickyWildFrames.push(cc.spriteFrameCache.getSpriteFrame("tayduky-spinification_"+ t +".png"))
			}
    	}

    	var col = this.columns[colId];

		var icon = new cc.Sprite("#stickyWild-tayduky.png");
		col.getParent().addChild(icon);
		icon.setPosition(col.x, 320);

		var sprite = new cc.Sprite("res/none.png");
		sprite.setPosition( col.x, 320 );
		sprite.setScale(1.7);
		col.getParent().addChild(sprite);

    	var animation1 = new cc.Animation(this.stickyWildFrames, 0.05, 1);
		var action = cc.animate(animation1);

		var sequence = cc.sequence(action, cc.callFunc(function(){
			//
			var child = col.getChildren();
			for( var i=child.length-1; i>=0; i-- ){
				col.setItem( child[i], 0); // wild id = 0
			}

			sprite.removeFromParent();
			icon.removeFromParent();
			if( cc.isFunction(cb) ) cb();
		}.bind(this), this));
		//run animate
		sprite.runAction(sequence);
    },
    checkHasWin: function(){
    	cc.log("check win");
    	if( !this._slotData ) return;
    	
	    var _type = "normal", _money = this._slotData.mX;

	    if (this._slotData.iJ){
	        _type = "jackpot";
	    }else if( this._slotData.bw ){
	        _type = "bigwin";
	    }else if( this._slotData.mX ){
	        _type = "normal";
	    }

	    // has bonus 
	    if( this._slotData.hMG ){
	        _money = 0;
	        for( var i=0; i<this._slotData.wls.length; i++ ){
	            _money += this._slotData.wls[i].crd;
	        }
	    }

	    var winlines = [];
	    if( this._slotData.wls && this._slotData.wls.length ){
	        for( var i=0; i< this._slotData.wls.length; i++ ){
	            winlines.push( this._slotData.wls[i].lid );
	        }
	    }

	    this.showLine(winlines);

	    if( _money ) this.showWin(_type, _money);
	    else this.checkHasBonus();
    },
    checkHasBonus: function(){
    	if( !this._slotData ) return;
    	if( this._slotData.hMG ) this.showWin("bonus");
    	else this.checkHasFreeSpin();
    },
    checkHasFreeSpin: function(){
    	if( !this._slotData ) return;

    	this._freespinData[ this._slotData.b.toString() ].fs = this._slotData.fss;
    	// set label
    	if( this._slotData.fss ){
    		this.lbNumFreeSpin.getChildren()[0].setString( this._slotData.fss );
    		this.lbNumFreeSpin.setVisible(true);
    	}else{
    		this.lbNumFreeSpin.setVisible(false);
    	}

    	if( this._slotData.hFS ) this.showWin("freespin");
    	else this.spinDone();
    },
    fastCheckWin: function(){

    },
    showWin: function(type, n){
    	this.wrapWin.removeAllChildren(true);
    	// this.unschedule(this.showWin);
    	if( type === false ){
    		this.wrapWin.setVisible(false);
    		return;
    	}
    	
    	this.wrapWin.setVisible(true);
    	var delayClose = 3;
    	if( type === 'bigwin' ) delayClose = 5;
    	else if( type === 'jackpot' ) delayClose = 6;
    	else if( type === 'normal' ) delayClose = 2;

    	if( n && n> 90 ) {
    		this.scheduleOnce(function(){
	    		this.lbTongThang.setString( MH.numToText(n) );
	    	}.bind(this), 1);
    	}

    	switch( type ){
    		case "normal":
    			var lbNormal = new newui.LabelBMFont("0", "res/tayduky/font/number.fnt");
				lbNormal.setColor(cc.color(255,255,100));
				lbNormal.setPosition(0, -200);
				this.wrapWin.addChild(lbNormal);
				lbNormal.countTo(n);
				// this._speaker.playEffect("winNormal");
    			break;
    		case "bigwin":
    			var fxLight = new cc.Sprite("res/tayduky/fx/light_3.png");
				fxLight.y = 70;
				this.wrapWin.addChild(fxLight);
				var fxDark = new cc.Sprite("res/tayduky/fx/bg.png");
				this.wrapWin.addChild(fxDark);
				var fxCoin = new cc.Sprite("res/tayduky/fx/coin.png");
				fxCoin.y = 50;
				this.wrapWin.addChild(fxCoin);
				fxCoin.runAction(cc.sequence(
		                cc.scaleTo(1, 1.5),
		                cc.scaleTo(1, 1)
		            ).repeatForever()
		        );

				var fxText = new cc.Sprite("res/tayduky/fx/text_thanglon.png");
				fxText.y = 55;
				this.wrapWin.addChild(fxText);
				var lb = new newui.LabelBMFont("0", "res/tayduky/font/number.fnt");
				lb.setColor(cc.color(255,255,100));
				lb.y = -45;
				this.wrapWin.addChild(lb);
				lb.countTo(n);
				// this._speaker.playEffect("winNormal");
    			break;
    		case "freespin":
    			var fxDark = new cc.Sprite("res/tayduky/fx/bg-sm.png");
				this.wrapWin.addChild(fxDark);
				var fxText = new cc.Sprite("res/tayduky/fx/text_lqmp.png");
				this.wrapWin.addChild(fxText);
				// this._speaker.playEffect("winNormal");
    			break;
    		case "bonus":
    			if( n ){ // thắng tiền từ chơi bonus
    				var lbNormal = new newui.LabelBMFont("0", "res/tayduky/font/number.fnt");
					lbNormal.setColor(cc.color(255,255,100));
					lbNormal.setPosition(0, -200);
					this.wrapWin.addChild(lbNormal);
					lbNormal.countTo(n);
					// this._speaker.playEffect("winNormal");
    			}else{ // trúng bonus
    				var fxDark = new cc.Sprite("res/tayduky/fx/bg-sm.png");
					this.wrapWin.addChild(fxDark);
					var fxText = new cc.Sprite("res/tayduky/fx/text_bonusgame.png");
					this.wrapWin.addChild(fxText);
					// this._speaker.playEffect("winNormal");
    			}
    			break;
    		case "jackpot":
    			var fxLight = new cc.Sprite("res/tayduky/fx/light_3.png");
				fxLight.y = 70;
				this.wrapWin.addChild(fxLight);

				var fxDark = new cc.Sprite("res/tayduky/fx/bg.png");
				this.wrapWin.addChild(fxDark);

				var fxCoin = new cc.Sprite("res/tayduky/fx/coin.png");
				fxCoin.y = 50;
				this.wrapWin.addChild(fxCoin);
				fxCoin.runAction(cc.sequence(
		                cc.scaleTo(1, 1.5),
		                cc.scaleTo(1, 1)
		            ).repeatForever()
		        );

				var fxText = new cc.Sprite("res/tayduky/fx/text_nohu.png");
				fxText.y = 90;
				this.wrapWin.addChild(fxText);
				var lb = new newui.LabelBMFont("0", "res/tayduky/font/number.fnt");
				lb.setColor(cc.color(255,255,100));
				lb.y = -50;
				this.wrapWin.addChild(lb);
				lb.countTo(n);
				// this._speaker.playEffect("winJackpot", false, "showWin");
    			break;
    		default:
    			this.wrapWin.setVisible(false);
    			break;
    	}

    	this.scheduleOnce(function(){
    		this.showLine(false);
    		this.showWin(false);
    		// this._speaker.stopByTag("showWin");
    		if( ["normal", "bigwin", "jackpot"].indexOf(type) !== -1 ){
    			this.checkHasBonus();
    		}else if( type === "bonus" ){
    			if( n ) this.checkHasFreeSpin();
    			else this.playBonus();
    		}else{// freespin phien khac
    			this.spinDone();
    		}
    	}.bind(this), delayClose);
    },
    spinDone: function(){
    	LobbyRequest.getInstance().requestUpdateMoney();
    	this._onSpin = false;
    	// check freeSpin
    	if( this._betting && this._freespinData[ this._betting.toString() ].fs ){
    		this._sendRequestSpin();
    		return
    	}

    	// check autospin
    	if( this._autoSpin ){
    		this._sendRequestSpin();
    		return;
    	}

    	// highlight
    	this.btnQuay.setActive(false);
    },
    showLine: function(data){
    	if( data === false || (cc.isArray(data) && data.length === 0) ){
    		this.wrapLine.setVisible(false);
    		this.wrapLine.removeAllChildren(true);
    		return;
    	}

    	this.wrapLine.setVisible(true);
    	if( cc.isArray(data) ){
    		this.wrapLine.removeAllChildren(true);
    		for( var i=0; i<data.length; i++ ){
    			var l = new cc.Sprite("res/tayduky/play/line/"+(data[i]+1)+".png" );
    			l.setAnchorPoint(0, 1);
    			this.wrapLine.addChild( l );
    		}
    	}else{
    		var l = new cc.Sprite("res/tayduky/play/line/"+(data+1)+".png" );
    		l.setAnchorPoint(0, 1);
    		this.wrapLine.addChild( l );
    	}
    },
    setQuy: function(data){
    	if( cc.isNumber(data) ){
			this._labelsHu[4].countTo(data, 2);
			this._dataJackpot[2].J = data;
		}else{
			if( this._betting === 0 ){ // lobby slot
				this._labelsHu[0].countTo(data[0].J, 2);
				this._labelsHu[1].countTo(data[1].J, 2);
				this._labelsHu[2].countTo(data[2].J, 2);
				this._labelsHu[3].countTo(data[2].J, 2); // default room 10k
	        }else{
	        	if( this._betting === 100 ){
	        		this._labelsHu[4].countTo(data[0].J, 2);
	            }else if( this._betting === 1000 ){
	            	this._labelsHu[4].countTo(data[1].J, 2);
	            }else{
	            	this._labelsHu[4].countTo(data[2].J, 2);
	            }
	        }
	        this._dataJackpot = data;
		}
    },
    notify: function(str, t){
		cc.director.getRunningScene().showMessage(str);
	},
	setSession: function(sid){
		this.lbSession.setString("#"+sid);
		if( this._onSpin ) this._spinning.sid = sid;
	},
	onReceiveSpin: function(data){
		this._slotData = data;

		if( !data ){ // || this.onSpin
	        this.forceStopSpin();
	        return;
	    }

	    if( data.mgs ){
	        this.notify( data.mgs );
	        this.forceStopSpin();
	        return;
	    }

	    if( !data.hasOwnProperty('sbs') || data.sbs.length != 15 ){
	        this.forceStopSpin();
	        return;
	    }

	    if( this._onSpin && this._spinning.sid === -1 ){
	    	this._slotData = data;
	    	if( this._isTrial ){
	            this._trialJackpot += 25*10000/100;
	            this.setQuy( this._trialJackpot );
	        }
	        this.setSession( data.sid );
	        var timeSpin = this._spinFast? 0.5 : 2;

	        this.scheduleOnce(function(){
				this.columns[0].stopSpin([this._slotData.sbs[0],this._slotData.sbs[5], this._slotData.sbs[10]]);
				this.scheduleOnce(function(){
					this.columns[1].stopSpin([this._slotData.sbs[1],this._slotData.sbs[6],this._slotData.sbs[11]]);
					this.scheduleOnce(function(){
						this.columns[2].stopSpin([this._slotData.sbs[2],this._slotData.sbs[7],this._slotData.sbs[12]]);
						this.scheduleOnce(function(){
							this.columns[3].stopSpin([this._slotData.sbs[3],this._slotData.sbs[8],this._slotData.sbs[13]]);
							this.scheduleOnce(function(){
								this.columns[4].stopSpin([this._slotData.sbs[4],this._slotData.sbs[9],this._slotData.sbs[14]]);
							}.bind(this), 1);
						}.bind(this), 0.3);
					}.bind(this), 0.3);
				}.bind(this), 0.3);
			}.bind(this), timeSpin);
	    }
	},
	_onupdateGame: function(cmd, data){
		if( data[1].gid != this._gameId ) return;
	    switch ( parseInt( cmd ) ){
	        case CMD_SLOT_MACHINE.SPIN :
	        case CMD_SLOT_MACHINE.SPIN_TRIAL :
	            this.onReceiveSpin( data[1] );
	            break;
	        default:
	            break;
	    }
	},
	_onObserverResponse: function(){

	},
	_onReconnectGame: function(){
		MiniGameClient.getInstance().observerByGameID(this._gameId);
	},
	_onTopHuResponse: function(cmd, data){
		if( this._isTrial ) return;
		var dataJackpot = [{J:0},{J:0},{J:0}];
    
	    if( data && data[1] && data[1].Js && data[1].Js.length ){
	        for( var i = 0; i<data[1].Js.length; i++ ){
	            if( data[1].Js[i].gid === this._gameId ){
	                if( data[1].Js[i].b === 100 ) dataJackpot[0].J = data[1].Js[i].J;
	                else if( data[1].Js[i].b === 1000 ) dataJackpot[1].J = data[1].Js[i].J;
	                else if( data[1].Js[i].b === 10000 ) dataJackpot[2].J = data[1].Js[i].J;
	            }
	        }
	    }
	    this.setQuy( dataJackpot );
	},
	_updateMoney: function(){
		if( this._betting ) this.lbPlayerGold0.countTo(PlayerMe.gold);
		else this.lbPlayerGold1.countTo( PlayerMe.gold );
	},
	onEnter: function(){
		this._super();
		this._gotoLobby();
		this.chooseLines([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24]);


	    MiniGameClient.getInstance().addListener( CMD_SLOT_MACHINE.SPIN.toString() , this._onupdateGame, this);
	    MiniGameClient.getInstance().addListener( CMD_SLOT_MACHINE.SPIN_TRIAL.toString() , this._onupdateGame, this);

	    MiniGameClient.getInstance().addListener( kCMD.OBSERVER_RESPONSE , this._onObserverResponse, this);
	    MiniGameClient.getInstance().addListener( CMD_OBSERVER.OBSERVER_SLOT_RECONNECT , this._onReconnectGame, this);

	    TopHuClient.getInstance().addListener( kCMD.TOP_HU , this._onTopHuResponse, this);

	    MiniGameClient.getInstance().observerByGameID(this._gameId);

	    LobbyClient.getInstance().addListener(kCMD.UPDATE_MONEY.toString(), this._updateMoney , this);
	},
	onExit: function(){
		this._super();
		MiniGameClient.getInstance().removeObserverByGameID(this._gameId);
		MiniGameClient.getInstance().removeListener(this);
		TopHuClient.getInstance().removeListener(this);
		LobbyClient.getInstance().removeListener(this);
	}
});