var DiceDiceDice = cc.Node.extend({
	_betting: 0,
	_gameId: Constant.GAME_ID.BIGSLOT.DICEDICEDICE,
	_moneyType: MoneyType.Gold,
	_isTrial: false,
	_trialJackpot: 50000000,
	_onSpin: false,
	_spinFast: false,
	_slotData: null,
	_autoSpin: false,
	_session: false,
    ctor: function(){
    	this._super();
    	this.setPosition(cc.winSize.width/2, cc.winSize.height/2);
    	this.setScale(0.66666667);

    	this._lines = [];
		this._dataJackpot = [{J:0},{J:0},{J:0}];
		this._spinning = {
	    	sid: 0,
	    	at: 0
	    };
	    this._labelsHu = [null, null, null, null, null];
	    this._freespinData = {
	    	"100":{b:100, ls:[], ai:1, fs:0, win: 0},
	        "1000":{b:1000, ls:[], ai:1, fs:0, win: 0},
	        "10000":{b:10000, ls:[], ai:1, fs:0, win: 0}
	    };

    	// this._speaker = new AudioDevice();

    	var wrapLobby = new cc.Node();
    	this.addChild(wrapLobby);
    	this.wrapLobby = wrapLobby;

    	var wrapPlay = new cc.Node();
    	this.addChild(wrapPlay);
    	this.wrapPlay = wrapPlay;

    	cc.director.getRunningScene().setBackground("res/dicedicedice/background.jpg");
    	// wrapPlay
    	var bg = new cc.Sprite("res/dicedicedice/play/background.jpg");
		wrapPlay.addChild(bg);

		var stencil = new cc.DrawNode();
        stencil.drawPoly( // 980 468
            [cc.p(0, 0),cc.p(980, 0),cc.p(980,468),cc.p(0, 468)],
            cc.color(255, 0, 0, 255),
            0,
            cc.color(255, 255, 255, 0)
        );
        var khung = new cc.ClippingNode(stencil);
        khung.setPosition(-476, -294);
        wrapPlay.addChild(khung);

        this.columns = [];

        var items = [];
        for( var i=0; i<=6; i++ ){
        	items.push( cc.spriteFrameCache.getSpriteFrame(i+"_dicedicedice.png") );
        }

        for(var i=0; i<5; i++){
        	var col = new Column({
        		itemH: 156,
        		items: items,
        		speed: 2300,
        		backOut: 50,
        		backIn: 30,
        		index: i
        	});

        	col.setPosition(i*197+84,0);
        	khung.addChild(col);
            this.columns[i] = col;
        }

        this.columns[4].onAfterStop = function(){
        	this.checkHasWin();
		}.bind(this);

		var btnBack = new newui.Button("res/dicedicedice/lobby/btn_back.png", function(){
			this._gotoLobby();
		}.bind(this));
		btnBack.setPosition(-810, 430);
		wrapPlay.addChild(btnBack);

		var lbgold = new newui.LabelBMFont( MH.numToText(PlayerMe.gold) , "res/dicedicedice/font/number.fnt");
		lbgold.setScale(0.5);
		lbgold.setPosition(-255, 259);
		lbgold.setAnchorPoint(0, 0);
		wrapPlay.addChild(lbgold);
		this.lbPlayerGold0 = lbgold;

		var lbhu = new newui.LabelBMFont("0", "res/dicedicedice/font/number.fnt");
		lbhu.setScale(0.5);
		lbhu.setPosition(115, 259);
		lbhu.setAnchorPoint(0, 0);
		wrapPlay.addChild(lbhu);
		this._labelsHu[4] = lbhu;

		var lbSession = new newui.LabelBMFont("#0", "res/dicedicedice/font/number.fnt");
		lbSession.setScale(0.433);
		lbSession.setPosition(0, 210);
		lbSession.setColor(cc.color("#e3dbbe"));
		lbSession.setAnchorPoint(0.5, 0);
		wrapPlay.addChild(lbSession);
		this.lbSession = lbSession;

		var btnVinhDanh = new newui.Button("res/dicedicedice/lobby/btn_bxh.png", function(){
			this.showVinhDanh();
		}.bind(this));
		btnVinhDanh.setPosition(680, 430);
		wrapPlay.addChild(btnVinhDanh);

		var btnSetting = new newui.Button("res/dicedicedice/lobby/btn_caidat.png", function(){
			this.showCaiDat();
		}.bind(this));
		btnSetting.setPosition(860, 430);
		wrapPlay.addChild(btnSetting);

		var btnHelp = new newui.Button("res/dicedicedice/lobby/btn_help.png", function(){
			this.showHuongDan();
		}.bind(this));
		btnHelp.setPosition(-850, -435);
		wrapPlay.addChild(btnHelp);

		var btnTuQuay = new newui.Button(["res/dicedicedice/play/btn_tuquay.png", "res/dicedicedice/play/btn_dung.png"], function(){
			this.changeAutoSpin();
		}.bind(this));
		btnTuQuay.setPosition(145, -418);
		wrapPlay.addChild(btnTuQuay);
		this.btnTuQuay = btnTuQuay;

		var btnQuay = new newui.Button("res/dicedicedice/play/btn_quay.png", function(){
			this._sendRequestSpin();
		}.bind(this));
		btnQuay.setPosition(424, -418);
		wrapPlay.addChild(btnQuay);
		this.btnQuay = btnQuay;

		var btnMucCuoc = new newui.Button("res/dicedicedice/play/p100.png", function(){
			this.changeBetting("UP");
		}.bind(this));// set in change betting
		btnMucCuoc.setPosition(-419, -418);
		wrapPlay.addChild(btnMucCuoc);
		this.btnMucCuoc = btnMucCuoc;

		var btnDong = new newui.Button("res/dicedicedice/play/btn_dong.png", function(){
			this.showChonDong();
		}.bind(this));
		btnDong.setPosition(-137, -413);
		wrapPlay.addChild(btnDong);

		var lbDong = new newui.LabelBMFont("0", "res/dicedicedice/font/number.fnt");
		lbDong.setScale(0.5);
		lbDong.setPosition(142, 60);
		lbDong.setColor(cc.color("#7a756a"));
		lbDong.setAnchorPoint(0,0);
		btnDong.addChild(lbDong);
		this.lbDong = lbDong;

		var tongThang = new newui.LabelBMFont("0", "res/dicedicedice/font/number.fnt");
		tongThang.setScale(0.5);
		tongThang.setPosition(892, 58);
		// tongThang.setColor(cc.color("#debc29"));
		tongThang.setAnchorPoint(1, 0);
		wrapPlay.addChild(tongThang);
		this.lbTongThang = tongThang;

		var tongDat = new newui.LabelBMFont("0", "res/dicedicedice/font/number.fnt");
		tongDat.setScale(0.5);
		tongDat.setPosition(892, -59);
		tongDat.setAnchorPoint(1, 0);
		wrapPlay.addChild(tongDat);
		this.lbTongDat = tongDat;

		var lbNumFreeSpin = new cc.Sprite("res/dicedicedice/play/luotquaymp.png");
		lbNumFreeSpin.setPosition(-10, -280);
		lbNumFreeSpin.setVisible(false);
		wrapPlay.addChild(lbNumFreeSpin);
		this.lbNumFreeSpin = lbNumFreeSpin;

		var numFreeSpin = new newui.LabelBMFont("2", "res/dicedicedice/font/number.fnt");
		numFreeSpin.setPosition(455, 9);
		numFreeSpin.setScale(0.6);
		numFreeSpin.setAnchorPoint(0, 0);
		numFreeSpin.setColor(cc.color("#73f589"));
		lbNumFreeSpin.addChild(numFreeSpin);

		var wrapLine = new cc.Node();
		wrapLine.setPosition(-415, 156);
		wrapLine.setVisible(false);
		wrapPlay.addChild(wrapLine);
		this.wrapLine = wrapLine;

		var wrapWin = new cc.Node();
		wrapWin.setVisible(false);
		wrapPlay.addChild(wrapWin);
		this.wrapWin = wrapWin;

		var wrapBonus = new cc.Node();
		wrapBonus.setVisible(false);
		this.addChild(wrapBonus);
		this.wrapBonus = wrapBonus;
    },
    _gotoLobby: function(){
    	this._betting = 0;
	    this._isTrial = false;
	    this._onSpin = false;

	    // this.changeSpeedMode(false);
	    this.changeAutoSpin(false);

    	this.wrapPlay.setVisible(false);
    	this.wrapLobby.setVisible(true);

		this.wrapLobby.removeAllChildren(true);

		var bg = new cc.Sprite("res/dicedicedice/lobby/background.jpg");
		this.wrapLobby.addChild(bg);

		var btnBack = new newui.Button("res/dicedicedice/lobby/btn_back.png", function(){
			MH.changePage("home");
		});
		btnBack.setPosition(-810, 430);
		this.wrapLobby.addChild(btnBack);

		var btnVinhDanh = new newui.Button("res/dicedicedice/lobby/btn_bxh.png", function(){
			this.showVinhDanh();
		}.bind(this));
		btnVinhDanh.setPosition(680, 430);
		this.wrapLobby.addChild(btnVinhDanh);

		var btnSetting = new newui.Button("res/dicedicedice/lobby/btn_caidat.png", function(){
			this.showCaiDat();
		}.bind(this));
		btnSetting.setPosition(860, 430);
		this.wrapLobby.addChild(btnSetting);

		var btnRoom0 = new newui.Button("res/dicedicedice/lobby/p0.png", function(){
			this.playTrial();
		}.bind(this));
		btnRoom0.setPosition(21, 145);
		this.wrapLobby.addChild(btnRoom0);

		var btnRoom1 = new newui.Button("res/dicedicedice/lobby/p100.png", function(){
			this.changeBetting(100);
		}.bind(this));
		btnRoom1.setPosition(17, -29);
		this.wrapLobby.addChild(btnRoom1);
		var hu1 = new newui.LabelBMFont("0", "res/dicedicedice/font/number.fnt");
		hu1.setScale(0.4);
		hu1.setAnchorPoint(0.5, 0);
		hu1.setPosition(817, 42);
		hu1.setColor(cc.color("#fafba2"));
		btnRoom1.addChild(hu1);
		this._labelsHu[0] = hu1;

		var btnRoom2 = new newui.Button("res/dicedicedice/lobby/p1000.png", function(){
			this.changeBetting(1000);
		}.bind(this));
		btnRoom2.setPosition(18, -185);
		this.wrapLobby.addChild(btnRoom2);
		var hu2 = new newui.LabelBMFont("0", "res/dicedicedice/font/number.fnt");
		hu2.setScale(0.4);
		hu2.setAnchorPoint(0.5, 0);
		hu2.setPosition(817, 47);
		hu2.setColor(cc.color("#fafba2"));
		btnRoom2.addChild(hu2);
		this._labelsHu[1] = hu2;

		var btnRoom3 = new newui.Button("res/dicedicedice/lobby/p10000.png", function(){
			this.changeBetting(10000);
		}.bind(this));
		btnRoom3.setPosition(21, -375);
		this.wrapLobby.addChild(btnRoom3);
		var hu3 = new newui.LabelBMFont("0", "res/dicedicedice/font/number.fnt");
		hu3.setScale(0.4);
		hu3.setAnchorPoint(0.5, 0);
		hu3.setPosition(817, 66);
		hu3.setColor(cc.color("#fafba2"));
		btnRoom3.addChild(hu3);
		this._labelsHu[2] = hu3;

		var lbgold = new newui.LabelBMFont(MH.numToText(PlayerMe.gold), "res/dicedicedice/font/number.fnt");
		lbgold.setScale(0.5);
		lbgold.setPosition(-440, 424);
		lbgold.setAnchorPoint(0, 0);
		this.wrapLobby.addChild(lbgold);
		this.lbPlayerGold1 = lbgold;

		var lbhu = new newui.LabelBMFont("0", "res/dicedicedice/font/number.fnt");
		lbhu.setScale(0.466);
		lbhu.setPosition(330, 424);
		lbhu.setAnchorPoint(0, 0);
		this.wrapLobby.addChild(lbhu);
		this._labelsHu[3] = lbhu;
    },
    changeBetting: function(bet){
    	if( this._isTrial ){
	        this.notify('Chức năng không hỗ trợ khi chơi thử');
	        return;
	    }

	    if( this._onSpin || this._autoSpin ){
	        this.notify('Chưa kết thúc phiên');
	        return;
	    }

	    if( bet == "UP" ){
	    	if( this._betting == 100 ) this._betting = 1000;
	    	else if( this._betting == 1000 ) this._betting = 10000;
	    	else if( this._betting == 10000 ) this._betting = 100;
	    }else this._betting = bet;

    	this._isTrial = false;
    	this.setSession(0);
    	this.changeAutoSpin( false );

    	this.wrapLobby.setVisible(false);
    	this.wrapLobby.removeAllChildren(true);
    	this.wrapPlay.setVisible(true);

    	// tong dat, btn muccuoc
    	this.lbTongDat.setString( MH.numToText( this._betting*this._lines.length ) );
    	this.lbTongThang.setString("0");
    	this.btnMucCuoc.setTexture("res/dicedicedice/play/p"+this._betting+".png");


    	//
    	this.showLine([0,1,2,3,4,5,6,7,8,9]);
    },
    playTrial: function(){
    	if( this._onSpin || this._autoSpin ){
	        this.notify('Chưa kết thúc phiên');
	        return;
	    }

	    this.chooseLines([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19]);
	    this.changeBetting(10000);
	    
    	this._isTrial = true;

        this._trialJackpot = 50000000;
        this.setQuy( this._trialJackpot );
    },
    playBonus: function(){
    	// this.wrapPlay.setVisible(false);
    	this.wrapBonus.setVisible(true);
    	this.wrapBonus.removeAllChildren(true);

    	var cover = new cc.Sprite("res/dicedicedice/popup/cover.png");
    	this.wrapBonus.addChild(cover);
    	cc.eventManager.addListener({
            event: cc.EventListener.TOUCH_ONE_BY_ONE,
            swallowTouches:true,
            onTouchBegan : function (touch, event) {
                return true;
            }.bind(this),
        }, cover);

    	var wrap1 = new cc.Node();
    	this.wrapBonus.addChild(wrap1);

    	var wrap2 = new cc.Node();
    	wrap2.setVisible(false);
    	this.wrapBonus.addChild(wrap2);

    	var bg = new cc.Sprite("res/dicedicedice/popup/bg_popup.png");
    	wrap1.addChild(bg);

    	var title = new cc.Sprite("res/dicedicedice/popup/title_minigame.png");
    	title.y = 435;
    	wrap1.addChild(title);

    	var lb1 = new cc.Sprite("res/dicedicedice/bonus/lb1.png");
    	lb1.y = 210;
    	lb1.setPosition(-20, 290);
    	wrap1.addChild(lb1);

    	var totalWin = 0;
    	var rate = this._slotData.MG.rate;
    	var countClick = 0;
    	var canClick = true;
    	var isFinished = false;

    	var lbTotal = new newui.LabelBMFont("0", "res/dicedicedice/font/number.fnt");
    	lbTotal.setPosition(-292, 300);
    	lbTotal.setScale(0.5);
    	lbTotal.setColor(cc.color(255,255,100));
    	lbTotal.setAnchorPoint(0, 0.5);
    	wrap1.addChild(lbTotal);

    	var lbHeso = new newui.LabelBMFont("X"+this._slotData.MG.rate, "res/dicedicedice/font/number.fnt");
    	lbHeso.setPosition(32, 300);
    	lbHeso.setScale(0.5);
    	lbHeso.setColor(cc.color(255,255,100));
    	lbHeso.setAnchorPoint(0, 0.5);
    	wrap1.addChild(lbHeso);

    	var lbConlai = new newui.LabelBMFont("10", "res/dicedicedice/font/number.fnt");
    	lbConlai.setPosition(562, 300);
    	lbConlai.setScale(0.5);
    	lbConlai.setColor(cc.color(255,255,100));
    	lbConlai.setAnchorPoint(0, 0.5);
    	wrap1.addChild(lbConlai);

    	var finishBonus = function(){
	        if( isFinished ) return;

	        isFinished = true;
	        canClick = false;

	        this.wrapPlay.setVisible(true);
	    	this.wrapBonus.setVisible(false);
	    	this.wrapBonus.removeAllChildren(true);

	    	this.showWin("bonus", this._slotData.MG.m);
	    }.bind(this);

    	var afterClick = function(){
	    	countClick++;
	    	canClick = true;

	    	lbTotal.countTo(totalWin, 0.5);
	    	lbHeso.setString("X"+rate);
	    	lbConlai.setString( this._slotData.MG.items.length - countClick );

	        if( countClick >= this._slotData.MG.items.length ){
	        	this.scheduleOnce(finishBonus, 1);
	        }
	        // runBnTimmer();
	    }.bind(this);

    	for( var i=0; i<32; i++ ){
    		var item = new newui.Button("res/dicedicedice/bonus/item.png", function(btn){
    			if( !canClick ) return false;
    			if( countClick >= this._slotData.MG.items.length ) return;
    			canClick = false;

    			var _pos = btn.getPosition();

    			if( this._slotData.MG.items[countClick] == -1 ){
    				rate += 1;

    				var spr = new cc.Sprite("res/dicedicedice/bonus/key.png");
    				spr.setPosition( _pos );
    				wrap1.addChild(spr);
    				wrap1.removeChild(btn);
		            afterClick();
		        }else{
		        	for( var i=0; i< this._slotData.MG.stg.length; i++ ){
		        		var bValue = 0,
            				valueWin = 0;
            			if( this._slotData.MG.items[countClick] == this._slotData.MG.stg[i].id ){
            				bValue = this._slotData.MG.stg[i].b2 || this._slotData.MG.stg[i].b||0;
		                    valueWin = this._betting * bValue * rate;
		                    totalWin += valueWin;

		                    cc.log("value win", valueWin);

		                    if( this._slotData.MG.items[countClick] ){ // items[i] != 0 => mở rương
		                    	cc.log("mở rương", bValue);
		                    	var spr = new cc.Sprite("res/dicedicedice/bonus/ruong.png");
			    				spr.setPosition( _pos );
			    				wrap1.addChild(spr);
			    				wrap1.removeChild(btn);

			    				this.scheduleOnce(function(){
			    					// Mo Ruong
			    					wrap1.setVisible(false);
						    		wrap2.setVisible(true);
						    		wrap2.removeAllChildren();

						    		var spr = new cc.Sprite("res/dicedicedice/bonus/bg-moruong.png");
						    		wrap2.addChild(spr);

						    		var canOpen = true;
						        	var ruongOther = [];

						        	if( bValue == 10 ) ruongOther = [10, 15, 20, 15];
						        	else if( bValue == 15 ) ruongOther = [20, 10, 15, 10];
						        	else if( bValue == 20 ) ruongOther = [10, 15, 15, 10];

						    		for( var i=0; i<5; i++ ){
						    			var ruong = new newui.Button(["res/dicedicedice/bonus/ruong-lg.png", "res/dicedicedice/bonus/ruong_on.png"], function(iruong){
						    				if( !canOpen ) return;
						    				canOpen = false;
						    				iruong.setActive(true);
						    				var xn = new newui.LabelBMFont( MH.numToText(valueWin) , "res/dicedicedice/font/number.fnt");
									    	xn.setPosition(iruong.x, iruong.y+20);
									    	xn.setColor(cc.color(255,255,100));
									    	xn.setAnchorPoint(0.5, 0);
									    	xn.setScale(0.5, 0.5);
									    	wrap2.addChild(xn);

									    	var _thistag = iruong.getTag() - 1223;
									    	//
									    	if( ruongOther.length > 0 ){
									    		
									    		this.scheduleOnce(function(){
									    			var t = 0;
									    			for( var i=0; i<5; i++ ){
									    				if( i != _thistag ){
									    					var oruong = wrap2.getChildByTag(1223+i);
									    					if( oruong ){
									    						oruong.setActive(true);
									    						oruong.setOpacity(150);
									    						var xn = new newui.LabelBMFont(MH.numToText(this._betting * ruongOther[t] * rate), "res/dicedicedice/font/number.fnt");
														    	xn.setPosition(oruong.x, oruong.y+20);
														    	xn.setColor(cc.color(255,255,100));
														    	xn.setAnchorPoint(0.5, 0);
														    	xn.setScale(0.5, 0.5);
														    	xn.setOpacity(150);
														    	wrap2.addChild(xn);
														    	t++;
									    					}
									    				}
									    			}
									    		}.bind(this), 1);

									    		this.scheduleOnce(function(){
									    			wrap1.setVisible(true);
									    			wrap2.setVisible(false);
									    			wrap2.removeAllChildren();
									    			afterClick();
									    		}, 3);
									    	}
						    			}.bind(this));
						    			ruong.setPosition( -550+250*i , -70);
						    			ruong.setTag(1223+i);
						    			wrap2.addChild(ruong);
						    		}
			    				}.bind(this), 1.5);
		                    }else{
		                    	var spr = new cc.Sprite("res/dicedicedice/bonus/item_on.png");
			    				spr.setPosition( _pos );
			    				
			    				var xn = new newui.LabelBMFont( 0 , "res/dicedicedice/font/number.fnt");
						    	xn.setPosition(btn.x, btn.y);
						    	xn.setColor(cc.color(255,255,100));
						    	xn.setAnchorPoint(0.5, 0.5);
						    	xn.setScale(0.5, 0.5);

						    	wrap1.addChild(spr);
						    	wrap1.addChild(xn);

						    	wrap1.removeChild(btn);

						    	xn.countTo(valueWin);

							    // MH.realtimeCount(0, valueWin, $this.children("span"), 1000);

			                	afterClick();
		                    }

		                    break;
            			}
		        	}
		        }



    		}.bind(this));
    		//-534, y: -338
    		item.setPosition( -534+(i%8)*155, -338+ Math.floor(i/8)*170 )
    		wrap1.addChild(item);
    	}
    },
    chooseLines: function(arr){
    	if( this._onSpin || this._autoSpin ){
	        this.notify('Chưa kết thúc phiên');
	        return;
	    }
	    if( this._isTrial ){
	        this.notify('Chức năng không hỗ trợ khi chơi thử');
	        return false
	    }
	    this._lines = arr;
	    this.lbDong.setString(arr.length);
	    this.lbTongDat.setString( MH.numToText( this._betting*this._lines.length ) );
    },
    _sendRequestSpin: function(){
    	if( this._onSpin ) return;

    	this._slotData = null;

    	this.showWin(false);
    	this.showLine(false);
    	this._spinning.sid = -1;
	    this._spinning.at = (new Date()).getTime();
	    this._onSpin = true;

    	this.btnQuay.setActive(true);
    	this.lbTongThang.setString("0");
    	// this._speaker.playEffect("spinStart");

		this.columns[0].runSpin();
		this.scheduleOnce(function(){
			this.columns[1].runSpin();
			this.scheduleOnce(function(){
				this.columns[2].runSpin();
				this.scheduleOnce(function(){
					this.columns[3].runSpin();
					this.scheduleOnce(function(){
						this.columns[4].runSpin();
					}.bind(this), 0.2);
				}.bind(this), 0.2);
			}.bind(this), 0.2);
		}.bind(this), 0.2);

		this.scheduleOnce(function(){
			if( this._spinning.sid === -1 && new Date().getTime() - this._spinning.at > 50000 ){
	            this.forceStopSpin();
	        }
		}.bind(this), 60);

		var sendObj = null;
	    if( this._isTrial ){
	        sendObj = [
	            command.ZonePluginMessage,
	            Constant.CONSTANT.ZONE_NAME_MINI_GAME,
	            miniGamePlugin.PLUGIN_SLOT_GAME,
	            {
	                'cmd': CMD_SLOT_MACHINE.SPIN_TRIAL,
	                'gid': this._gameId,
	                'aid': this._moneyType,
	                'ls': this._lines,
	                'b': 10000
	            }
	        ];
	    }else{
	        sendObj = [
	            command.ZonePluginMessage,
	            Constant.CONSTANT.ZONE_NAME_MINI_GAME,
	            miniGamePlugin.PLUGIN_SLOT_GAME,
	            {
	                'cmd': CMD_SLOT_MACHINE.SPIN,
	                'gid': this._gameId,
	                'aid': this._moneyType,
	                'ls': this._lines,
	                'b': this._betting
	            }
	        ];
	    }

	    MiniGameClient.getInstance().send(sendObj);
    },
    forceStopSpin: function(){
		this.columns[0].stopSpin();
		this.scheduleOnce(function(){
			this.columns[1].stopSpin();
			this.scheduleOnce(function(){
				this.columns[2].stopSpin();
				this.scheduleOnce(function(){
					this.columns[3].stopSpin();
					this.scheduleOnce(function(){
						this.columns[4].stopSpin();
					}.bind(this), 0.3);
				}.bind(this), 0.3);
			}.bind(this), 0.3);
		}.bind(this), 0.3);

		this.changeAutoSpin( false );
		this._onSpin = false;
		this.btnQuay.setActive(false);
	},
	playItemAnimation: function(col){},
	changeAutoSpin: function(type){
		if( arguments.length === 0 ) type = !this._autoSpin;
		if( type ){
			if( this._isTrial ){
				this.notify('Chức năng không hỗ trợ khi chơi thử');
				return;
			}
			if( !this._onSpin ) this._sendRequestSpin();
		}

		this.btnTuQuay.setActive(type);
		this._autoSpin = type;
	},
	removeChildByName: function(){
		var arr = [];
		for( var i=0; i<arguments.length; i++ ){
			arr.push( arguments[i] );
		}

		var child = this.getChildren();
		for( var i=child.length-1; i>=0; i-- ){
			if( arr.indexOf(child[i].getName()) != -1 ){
				this.removeChild( child[i], true);
			}
		}
	},
	showCaiDat: function(){},
	showChonDong: function(){
		if( this._onSpin || this._autoSpin ){
            this.notify('Chưa kết thúc phiên');
            return;
        }

        if( this._isTrial ){
            this.notify('Chức năng không hỗ trợ khi chơi thử');
            return;
        }

        this.removeChildByName("wrapChonDong");
        var popup = new cc.Node();
        popup.setName("wrapChonDong");
    	this.addChild(popup, 99);

    	var cover = new cc.Sprite("res/dicedicedice/popup/cover.png");
    	popup.addChild(cover);
    	cc.eventManager.addListener({
            event: cc.EventListener.TOUCH_ONE_BY_ONE,
            swallowTouches:true,
            onTouchBegan : function (touch, event) {
                return true;
            }.bind(this),
        }, cover);

    	var bg = new cc.Sprite("res/dicedicedice/popup/bg_popup.png");
    	popup.addChild(bg);
    	var btnClose = new newui.Button("res/dicedicedice/popup/btn_close.png", function(){
    		this.removeChildByName("wrapChonDong");
    	}.bind(this));
    	btnClose.setPosition(650, 315);
    	popup.addChild(btnClose, 5);

    	var title = new cc.Sprite("res/dicedicedice/popup/title_chondong.png");
    	title.y = 435;
    	popup.addChild(title);

    	for( var i=1; i<=20; i++ ){
			var btn = new newui.Button("res/dicedicedice/popup/chon_dong/chon/"+i+".png", function(btn){
				var act = btn.getActive(),
					lid = btn.getTag()-100-1;
				// btn.setActive(!act);
				if( act ){//remove
					var _ii = this._lines.indexOf(lid);
					if( _ii !== -1 ) this._lines.splice(_ii, 1);
				}else{//add
					if( this._lines.indexOf(lid) === -1 ) this._lines.push( lid );
				}

				this.chooseLines(this._lines);
				this.showChonDong();
			}.bind(this));
	    	btn.setPosition(-380+(i-1)%5*230 , 170-140*Math.floor((i-1)/5));
	    	btn.setAnchorPoint(1, 0);
	    	popup.addChild(btn);
	    	btn.setTag(100+i);
	    	if( this._lines.indexOf(i-1) == -1 ){
	    		btn.setColor(cc.color(100, 100, 100));
    			btn.setActive(false);
	    	}else{
	    		btn.setColor(cc.color(255,255,255));
    			btn.setActive(true);
	    	}
    	}

    	var btnChan = new newui.Button("res/dicedicedice/popup/btn_dongchan.png", function(){
    		this.chooseLines([1,3,5,7,9,11,13,15,17,19]);
    		this.showChonDong();
    	}.bind(this));
    	btnChan.setPosition(-415, -346);
    	popup.addChild(btnChan);
    	var btnLe = new newui.Button("res/dicedicedice/popup/btn_dongle.png", function(){
    		this.chooseLines([0,2,4,6,8,10,12,14,16,18]);
    		this.showChonDong();
    	}.bind(this));
    	btnLe.setPosition(-139, -346);
    	popup.addChild(btnLe);
    	var btnAll = new newui.Button("res/dicedicedice/popup/btn_tatca.png", function(){
    		this.chooseLines([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19]);
    		this.showChonDong();
    	}.bind(this));
    	btnAll.setPosition(139, -346);
    	popup.addChild(btnAll);
    	var btnNone = new newui.Button("res/dicedicedice/popup/btn_bochon.png", function(){
    		this.chooseLines([0]);
    		this.showChonDong();
    	}.bind(this));
    	btnNone.setPosition(415, -346);
    	popup.addChild(btnNone);
    },
    showHuongDan: function(){
    	this.removeChildByName("wrapHuongDan");
        var popup = new cc.Node();
        popup.setName("wrapHuongDan");
        this.addChild(popup, 99);

        var cover = new cc.Sprite("res/dicedicedice/popup/cover.png");
    	popup.addChild(cover);

    	var bg = new cc.Sprite("res/dicedicedice/popup/bg_popup.png");
    	popup.addChild(bg);

    	var title = new cc.Sprite("res/dicedicedice/popup/title_bangthuong.png");
    	title.y = 435;
    	popup.addChild(title);

    	var btnClose = new newui.Button("res/dicedicedice/popup/btn_close.png", function(){
    		this.removeChildByName("wrapHuongDan");
    		// this.wrapPlay.setVisible(true);
    	}.bind(this));
    	btnClose.setPosition(650, 315);
    	popup.addChild(btnClose, 5);

    	var spr = new cc.Sprite("res/dicedicedice/popup/bangthuong_p.png");
    	spr.y = -20;
    	popup.addChild(spr);

    	cc.eventManager.addListener({
            event: cc.EventListener.TOUCH_ONE_BY_ONE,
            swallowTouches:true,
            onTouchBegan : function (touch, event) {
                return true;
            }.bind(this),
        }, cover);
    },
    showVinhDanh: function(_index){
    	if( !_index ) _index = 1;
    	this.removeChildByName("wrapVinhDanh");
        var popup = new cc.Node();
        popup.setName("wrapVinhDanh");
        this.addChild(popup, 99);

    	// this.wrapPlay.setVisible(false);
    	// this.wrapLobby.setVisible(false);

    	var cover = new cc.Sprite("res/dicedicedice/popup/cover.png");
    	popup.addChild(cover);

    	var bg = new cc.Sprite("res/dicedicedice/popup/bg_popup.png");
    	popup.addChild(bg);

    	var title = new cc.Sprite("res/dicedicedice/popup/title_bangvinhdanh.png");
    	title.y = 435;
    	popup.addChild(title);

    	var btnClose = new newui.Button("res/dicedicedice/popup/btn_close.png", function(){
    		this.removeChildByName("wrapVinhDanh");
    		// if( this._betting == 0 ) this.wrapLobby.setVisible(true)
    		// else this.wrapPlay.setVisible(true);
    	}.bind(this));
    	btnClose.setPosition(650, 315);
    	popup.addChild(btnClose, 5);

    	// var btnL = new newui.Button("res/dicedicedice/popup/btn-left.png", function(){
    	// }.bind(this));
    	// btnL.setPosition(-573, 37);
    	// var btnR = new newui.Button("res/dicedicedice/popup/btn-right.png", function(){
    	// }.bind(this));
    	// btnR.setPosition(573, 37);
    	// popup.addChild(btnL);
    	// popup.addChild(btnR);

    	var table = new newui.TableView(1250, 660);
        table.setColumn(0.25, 0.2, 0.15, 0.2, 0.2);
        table.setItemHeight(60);
        table.setHeader("Thời gian", "Tài khoản","Phòng", "Thắng", "Mô Tả");
        popup.addChild(table);

        MyRequest.fetchTopSlotMachine(this._gameId ,function(cmd, obj){
			if( obj && obj.status == 0 && obj.data.items.length ){
				var _len = obj.data.items.length;
				var arr = [];
				for( var i=0; i<_len; i++ ){
					if( obj.data.items[i].assetId == MoneyType.Gold ){
						arr.push([ MH.convertTime(obj.data.items[i].createdTime), obj.data.items[i].displayName, MH.numToText(obj.data.items[i].betting), MH.numToText(obj.data.items[i].money), obj.data.items[i].description]);
					}
				}
				table.setContent(arr);
			}
		}.bind(this));

		cc.eventManager.addListener({
            event: cc.EventListener.TOUCH_ONE_BY_ONE,
            swallowTouches:true,
            onTouchBegan : function (touch, event) {
                return true;
            }.bind(this),
        }, cover);
    },
    checkHasWin: function(){
    	if( !this._slotData ) return;
    	
	    var _type = "normal", _money = this._slotData.mX;

	    if (this._slotData.iJ){
	        _type = "jackpot";
	    }else if( this._slotData.bw ){
	        _type = "bigwin";
	    }else if( this._slotData.mX ){
	        _type = "normal";
	    }

	    // has bonus 
	    if( this._slotData.hMG ){
	        _money = 0;
	        for( var i=0; i<this._slotData.wls.length; i++ ){
	            _money += this._slotData.wls[i].crd;
	        }
	    }

	    var winlines = [];
	    if( this._slotData.wls && this._slotData.wls.length ){
	        for( var i=0; i< this._slotData.wls.length; i++ ){
	            winlines.push( this._slotData.wls[i].lid );
	        }
	    }

	    this.showLine(winlines);

	    if( _money ) this.showWin(_type, _money);
	    else this.checkHasBonus();
    },
    checkHasBonus: function(){
    	if( !this._slotData ) return;
    	if( this._slotData.hMG ) this.showWin("bonus");
    	else this.checkHasFreeSpin();
    },
    checkHasFreeSpin: function(){
    	if( !this._slotData ) return;

    	this._freespinData[ this._slotData.b.toString() ].fs = this._slotData.fss;
    	// set label
    	if( this._slotData.fss ){
    		this.lbNumFreeSpin.getChildren()[0].setString( this._slotData.fss );
    		this.lbNumFreeSpin.setVisible(true);
    	}else{
    		this.lbNumFreeSpin.setVisible(false);
    	}

    	if( this._slotData.hFS ) this.showWin("freespin");
    	else this.spinDone();
    },
    fastCheckWin: function(){

    },
    showWin: function(type, n){
    	// win money [normal.bigwin.jackpot] -> bonus -> freespin

    	this.wrapWin.removeAllChildren(true);
    	// this.unschedule(this.showWin);
    	if( type === false ){
    		this.wrapWin.setVisible(false);
    		return;
    	}
    	
    	this.wrapWin.setVisible(true);
    	var delayClose = 3;
    	if( type === 'bigwin' ) delayClose = 5;
    	else if( type === 'jackpot' ) delayClose = 6;
    	else if( type === 'normal' ) delayClose = 2;

    	if( n && n> 90 ) {
    		this.scheduleOnce(function(){
	    		this.lbTongThang.setString( MH.numToText(n) );
	    	}.bind(this), 1);
    	}

    	switch( type ){
    		case "normal":
    			var lbNormal = new newui.LabelBMFont("0", "res/dicedicedice/font/number.fnt");
				lbNormal.setColor(cc.color(255,255,100));
				lbNormal.setPosition(0, -200);
				this.wrapWin.addChild(lbNormal);
				lbNormal.countTo(n);
				// this._speaker.playEffect("winNormal");
    			break;
    		case "bigwin":
    			var fxLight = new cc.Sprite("res/dicedicedice/fx/light_3.png");
				fxLight.y = 70;
				this.wrapWin.addChild(fxLight);
				var fxDark = new cc.Sprite("res/dicedicedice/fx/bg-lg.png");
				this.wrapWin.addChild(fxDark);
				var fxCoin = new cc.Sprite("res/dicedicedice/fx/coin.png");
				fxCoin.y = 50;
				this.wrapWin.addChild(fxCoin);
				var fxText = new cc.Sprite("res/dicedicedice/fx/text_thanglon.png");
				fxText.y = 55;
				this.wrapWin.addChild(fxText);
				var lb = new newui.LabelBMFont("0", "res/dicedicedice/font/number.fnt");
				lb.setColor(cc.color(255,255,100));
				lb.y = -45;
				this.wrapWin.addChild(lb);
				lb.countTo(n);
				// this._speaker.playEffect("winNormal");
    			break;
    		case "freespin":
    			var fxDark = new cc.Sprite("res/dicedicedice/fx/bg.png");
				this.wrapWin.addChild(fxDark);
				var fxText = new cc.Sprite("res/dicedicedice/fx/text_lqmp.png");
				fxText.y = 10;
				this.wrapWin.addChild(fxText);
				// this._speaker.playEffect("winNormal");
    			break;
    		case "bonus":
    			if( n ){
    				var lbNormal = new newui.LabelBMFont("0", "res/dicedicedice/font/number.fnt");
					lbNormal.setColor(cc.color(255,255,100));
					lbNormal.setPosition(0, -200);
					this.wrapWin.addChild(lbNormal);
					lbNormal.countTo(n);
					// this._speaker.playEffect("winNormal");
    			}else{
    				var fxDark = new cc.Sprite("res/dicedicedice/fx/bg.png");
					this.wrapWin.addChild(fxDark);
					var fxText = new cc.Sprite("res/dicedicedice/fx/text_bonusgame.png");
					fxText.y = 10;
					this.wrapWin.addChild(fxText);
					// this._speaker.playEffect("winNormal");
    			}
    			break;
    		case "jackpot":
    			var fxLight = new cc.Sprite("res/dicedicedice/fx/light_3.png");
				fxLight.y = 70;
				this.wrapWin.addChild(fxLight);
				var fxDark = new cc.Sprite("res/dicedicedice/fx/bg-lg.png");
				this.wrapWin.addChild(fxDark);
				var fxCoin = new cc.Sprite("res/dicedicedice/fx/coin.png");
				fxCoin.y = 50;
				this.wrapWin.addChild(fxCoin);
				var fxText = new cc.Sprite("res/dicedicedice/fx/text_nohu.png");
				fxText.y = 90;
				this.wrapWin.addChild(fxText);
				var lb = new newui.LabelBMFont("0", "res/dicedicedice/font/number.fnt");
				lb.setColor(cc.color(255,255,100));
				lb.y = -60;
				this.wrapWin.addChild(lb);
				lb.countTo(n);
				// this._speaker.playEffect("winJackpot", false, "showWin");
    			break;
    		default:
    			this.wrapWin.setVisible(false);
    			break;
    	}

    	this.scheduleOnce(function(){
    		this.showLine(false);
    		this.showWin(false);
    		// this._speaker.stopByTag("showWin");
    		if( ["normal", "bigwin", "jackpot"].indexOf(type) !== -1 ){
    			this.checkHasBonus();
    		}else if( type === "bonus" ){
    			if( n ) this.checkHasFreeSpin();
    			else this.playBonus();
    		}else{// freespin phien khac
    			this.spinDone();
    		}
    	}.bind(this), delayClose);
    },
    spinDone: function(){
    	LobbyRequest.getInstance().requestUpdateMoney();
    	this._onSpin = false;
    	// check freeSpin
    	if( this._betting && this._freespinData[ this._betting.toString() ].fs ){
    		this._sendRequestSpin();
    		return
    	}

    	// check autospin
    	if( this._autoSpin ){
    		this._sendRequestSpin();
    		return;
    	}

    	// highlight
    	this.btnQuay.setActive(false);
    },
    showLine: function(data){
    	if( data === false || (cc.isArray(data) && data.length === 0) ){
    		this.wrapLine.setVisible(false);
    		this.wrapLine.removeAllChildren(true);
    		return;
    	}

    	this.wrapLine.setVisible(true);
    	if( cc.isArray(data) ){
    		this.wrapLine.removeAllChildren(true);
    		for( var i=0; i<data.length; i++ ){
    			var l = new cc.Sprite("res/dicedicedice/play/line/"+(data[i]+1)+".png" );
    			l.setAnchorPoint(0, 1);
    			this.wrapLine.addChild( l );
    		}
    	}else{
    		var l = new cc.Sprite("res/dicedicedice/play/line/"+(data+1)+".png" );
    		l.setAnchorPoint(0, 1);
    		this.wrapLine.addChild( l );
    	}
    },
	setQuy: function(data){
		if( cc.isNumber(data) ){
			this._labelsHu[4].countTo(data, 2);
			this._dataJackpot[2].J = data;
		}else{
			if( this._betting === 0 ){ // lobby slot
				this._labelsHu[0].countTo(data[0].J, 2);
				this._labelsHu[1].countTo(data[1].J, 2);
				this._labelsHu[2].countTo(data[2].J, 2);
				this._labelsHu[3].countTo(data[2].J, 2); // default room 10k
	        }else{
	        	if( this._betting === 100 ){
	        		this._labelsHu[4].countTo(data[0].J, 2);
	            }else if( this._betting === 1000 ){
	            	this._labelsHu[4].countTo(data[1].J, 2);
	            }else{
	            	this._labelsHu[4].countTo(data[2].J, 2);
	            }
	        }
	        this._dataJackpot = data;
		}
	},
	notify: function(str, t){
		cc.director.getRunningScene().showMessage(str);
	},
	setSession: function(sid){
		this.lbSession.setString("#"+sid);
		if( this._onSpin ) this._spinning.sid = sid;
	},

	onReceiveSpin: function(data){
		this._slotData = null;

	    if( !data ){ // || this.onSpin
	        this.forceStopSpin();
	        return;
	    }

	    if( data.mgs ){
	        this.notify( data.mgs );
	        this.forceStopSpin();
	        return;
	    }

	    if( !data.hasOwnProperty('sbs') || data.sbs.length != 15 ){
	        this.forceStopSpin();
	        return;
	    }

	    // something here
	    //

	    if( this._onSpin && this._spinning.sid === -1 ){
	        this._slotData = data;
	        if( this._isTrial ){
	            this._trialJackpot += 25*10000/100;
	            this.setQuy( this._trialJackpot );
	        }

	        this.setSession( data.sid );

	        //
	        var timeSpin = this._spinFast? 0.5 : 2;
			this.scheduleOnce(function(){
				this.columns[0].stopSpin([this._slotData.sbs[0],this._slotData.sbs[5], this._slotData.sbs[10]]);
				this.scheduleOnce(function(){
					this.columns[1].stopSpin([this._slotData.sbs[1],this._slotData.sbs[6],this._slotData.sbs[11]]);
					this.scheduleOnce(function(){
						this.columns[2].stopSpin([this._slotData.sbs[2],this._slotData.sbs[7],this._slotData.sbs[12]]);
						this.scheduleOnce(function(){
							this.columns[3].stopSpin([this._slotData.sbs[3],this._slotData.sbs[8],this._slotData.sbs[13]]);
							this.scheduleOnce(function(){
								this.columns[4].stopSpin([this._slotData.sbs[4],this._slotData.sbs[9],this._slotData.sbs[14]]);
							}.bind(this), 1);
						}.bind(this), 0.3);
					}.bind(this), 0.3);
				}.bind(this), 0.3);
			}.bind(this), timeSpin);
	    }
	},
	_onupdateGame: function(cmd, data){
		if( data[1].gid != this._gameId ) return;
	    switch ( parseInt( cmd ) ){
	        case CMD_SLOT_MACHINE.SPIN :
	        case CMD_SLOT_MACHINE.SPIN_TRIAL :
	            this.onReceiveSpin( data[1] );
	            break;
	        default:
	            break;
	    }
	},
	_onObserverResponse: function(cmd, data){

	},
	_onReconnectGame: function(){
		MiniGameClient.getInstance().observerByGameID(this._gameId);
	},
	_onTopHuResponse: function(cmd, data){
		if( this._isTrial ) return;
		var dataJackpot = [{J:0},{J:0},{J:0}];
    
	    if( data && data[1] && data[1].Js && data[1].Js.length ){
	        for( var i = 0; i<data[1].Js.length; i++ ){
	            if( data[1].Js[i].gid === this._gameId ){
	                if( data[1].Js[i].b === 100 ) dataJackpot[0].J = data[1].Js[i].J;
	                else if( data[1].Js[i].b === 1000 ) dataJackpot[1].J = data[1].Js[i].J;
	                else if( data[1].Js[i].b === 10000 ) dataJackpot[2].J = data[1].Js[i].J;
	            }
	        }
	    }
	    this.setQuy( dataJackpot );
	},
	_updateMoney: function(){
		if( this._betting ) this.lbPlayerGold0.countTo(PlayerMe.gold);
		else this.lbPlayerGold1.countTo( PlayerMe.gold );
	},
    onEnter: function(){
		this._super();
		this._gotoLobby();

		this.chooseLines([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19]);

		// this._speaker.playEffect("background", true, "background");

		MiniGameClient.getInstance().addListener( CMD_SLOT_MACHINE.SPIN.toString() , this._onupdateGame, this);
	    MiniGameClient.getInstance().addListener( CMD_SLOT_MACHINE.SPIN_TRIAL.toString() , this._onupdateGame, this);
	    MiniGameClient.getInstance().addListener( CMD_SLOT_MACHINE.JACKPOT.toString() , this._onupdateGame, this);
	    MiniGameClient.getInstance().addListener( kCMD.OBSERVER_RESPONSE , this._onObserverResponse, this);
	    MiniGameClient.getInstance().addListener( CMD_OBSERVER.OBSERVER_SLOT_RECONNECT , this._onReconnectGame, this);
	    TopHuClient.getInstance().addListener( kCMD.TOP_HU , this._onTopHuResponse, this);

	    MiniGameClient.getInstance().observerByGameID(this._gameId);

		LobbyClient.getInstance().addListener(kCMD.UPDATE_MONEY.toString(), this._updateMoney , this);
	},
	onExit: function(){
		this._super();
		cc.log("onExit DeadOrAlive");
		MiniGameClient.getInstance().removeObserverByGameID(this._gameId);

		MiniGameClient.getInstance().removeListener(this);
		TopHuClient.getInstance().removeListener(this);
		LobbyClient.getInstance().removeListener(this);
		// this._speaker.destroy();
	}
});