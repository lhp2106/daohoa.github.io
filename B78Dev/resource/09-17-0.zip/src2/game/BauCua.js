//  1  2  3   4   5    6
// ga ca tom cua bau huou
var BauCua = cc.Node.extend({
	ctor: function(){
		this._super();

		this.his = [];
		this.sId = 0;
		this.rId = 0;

		this.enableBet = true;

		this.timeXX = 1800; // thoi gian hiệu ứng tung xx
		this.timeBet = 60000; // thoi gian dat cuoc
		this.timeEndBet = 5000;
		this.timeTurn = 20000; // thoi gian tra thuong

		this.stepBet = {
			step:[],
			btns:[],
			act:0
		};

		// chọn nhưng chưa bấm đồng ý
		this.betting = {
			sId:0,
			bts:[0,0,0,0,0,0],
			rId:0
		};
		// đã cược
		this.betSuccess = {
			sId:0,
			bts:[0,0,0,0,0,0],
			rId:0
		};

		this.cuaDatWrap = []; // [icon, lb1, lb2], 

		this.btnRooms = {}; //{"1000": btn1K, "10000": btn10K, "100000": btn100K}


		this.setPosition(cc.p(cc.winSize.width/2, cc.winSize.height/2));
		// var demo = new cc.Sprite("res/baucua/bkg2.png");
		// this.addChild(demo, -2);
		var bg = new cc.Sprite("res/baucua/bkg.png");
		this.addChild(bg, -2);

		this.initButton();
	},
	initButton: function(){
		var btnClose = new newui.Button("res/baucua/btn_close.png", function(){
			this.close();
		}.bind(this));
		btnClose.setPosition(cc.p(225, 230));
		this.addChild(btnClose, 5);

		var btnVinhDanh = new newui.Button("res/baucua/btn_vinhdanh.png");
		btnVinhDanh.setPosition(cc.p(-310, 275));
    	this.addChild(btnVinhDanh);

    	var btnHelp = new newui.Button("res/baucua/btn_help.png");
    	btnHelp.setPosition(cc.p(-473, 205));
    	this.addChild(btnHelp);

    	var btnLichSu = new newui.Button("res/baucua/btn_info.png");
    	this.addChild(btnLichSu);
    	btnLichSu.setPosition(cc.p(-407, 266));

    	var btnDoiCau = new newui.Button("res/baucua/doicau.png", function(){
    		this.drawHis(true);
    	}.bind(this));
    	this.addChild(btnDoiCau);
    	btnDoiCau.setPosition(cc.p(-314, -124));

    	var btn1K = new newui.Button(["res/baucua/1k_off.png", "res/baucua/1k_on.png"], function(){
			if( this.hasBet() ){
				this.notify('Bạn đang đặt ở phòng '+MH.numToText( this.rId ) );
			}else{
				BauCuaPlugin.getInstance().register( 1000 );
			}
    	}.bind(this));
    	btn1K.setPosition(cc.p(-482, 92));
    	this.addChild(btn1K);

    	var btn10K = new newui.Button(["res/baucua/10k_off.png", "res/baucua/10k_on.png"], function(){
			if( this.hasBet() ){
				this.notify('Bạn đang đặt ở phòng '+MH.numToText( this.rId ) );
			}else{
				BauCuaPlugin.getInstance().register( 10000 );
			}
    	}.bind(this));
    	btn10K.setPosition(cc.p(-482, 2));
    	this.addChild(btn10K);

    	var btn100K = new newui.Button(["res/baucua/100k_off.png", "res/baucua/100k_on.png"], function(){
			if( this.hasBet() ){
				this.notify('Bạn đang đặt ở phòng '+MH.numToText( this.rId ) );
			}else{
				BauCuaPlugin.getInstance().register( 100000 );
			}
    	}.bind(this));
    	btn100K.setPosition(cc.p(-476, -84));
    	this.addChild(btn100K);

    	this.btnRooms = {
    		"1000": btn1K,
    		"10000": btn10K,
    		"100000": btn100K
    	};

    	var btnDatLai = new newui.Button("res/baucua/btn_dat-lai.png", function(){
    		if( !this.enableBet ){
				this.notify('Hết thời gian đặt cược');
			}else if( this.hasBet() ){
				this.notify('Đã đặt cược không thể đặt lại');
			}else{
				BauCuaPlugin.getInstance().betAgain( this.rId );
			}
    	}.bind(this));
    	this.addChild(btnDatLai);
    	btnDatLai.setPosition(cc.p(-380, -268));

    	var btnGapThep = new newui.Button("res/baucua/btn_gap-thep.png", function(){
    		if( !this.enableBet ){
				this.notify('Hết thời gian đặt cược');
			}else if( this.hasBet() ){
				this.notify('Đã đặt cược không thể gấp thếp');
			}else{
				BauCuaPlugin.getInstance().doubleBet( this.rId );
			}
    	}.bind(this));
    	this.addChild(btnGapThep);
    	btnGapThep.setPosition(cc.p(-210, -268));

    	var btnXoa = new newui.Button("res/baucua/btn_xoa.png", function(){
    		// reset betting
			this.betting.bts = [0,0,0,0,0,0];
			this.betting.rId = this.rId;
			this.betting.sId = this.sId;
			// reset ban cuoc y-
			var arrBet = [];
			for( var i=0; i<this.betSuccess.bts.length; i++ ){
				arrBet.push({uBM: this.betSuccess.bts[i], did: i+1 });
			}
			this.buildBanCuoc( arrBet );
    	}.bind(this));
    	btnXoa.setPosition(cc.p(-38, -268));
    	this.addChild(btnXoa);

    	var btnDongY = new newui.Button("res/baucua/btn_xac-nhan.png", function(){
    		if( this.enableBet ){
				var arrBet = []; // [{did: id, bM: sotien}];
				for( var i=0; i<this.betting.bts.length; i++ ){
					if( this.betting.bts[i] ){
						arrBet.push({did:(i+1),bM:this.betting.bts[i]});
					}
				}

				if( arrBet.length ) BauCuaPlugin.getInstance().acceptBet(this.rId, arrBet );
				else{
					this.notify('Chưa chọn cửa');
				}
			}else{
				this.notify('Hết thời gian đặt cược');
			}
    	}.bind(this));
    	btnDongY.setPosition(cc.p(134, -268));
    	this.addChild(btnDongY);

    	for(var i=0; i<5; i++){
    		var btnCuoc = new newui.Button("res/baucua/cuoc"+(i+1)+".png", function(btn){
    			//
    			var _index = this.stepBet.btns.indexOf(btn);
    			if( _index > -1 ){
    				this.stepBet.act = _index;
    				cc.each(this.stepBet.btns, function(button){
    					button.setActive(false);
    				});
    				btn.setActive(true);
    			}
    		}.bind(this));
    		btnCuoc.setPosition(cc.p(-170+i*85, -120));
    		btnCuoc.setTitleText("00");
    		btnCuoc.setTitleFontSize(20);
    		if( i==4 ) btnCuoc.setTitleColor(cc.color("#000000"));
    		this.addChild(btnCuoc);

    		this.stepBet.btns.push(btnCuoc);
    	}

    	for(var i=0; i<6; i++){
    		var btnCuaDat = new newui.Button("res/baucua/cua-"+i+".png", function(btn){
    			if( !this.enableBet ){
					this.notify('Hết giờ đặt cược');
					return;
				}
				var _id = btn.getTag()-123;
				var _step = this.stepBet.step[ this.stepBet.act ];

				// get old
				var _old = 0, _cr = 0, _new = 0;
				if( this.rId == this.betSuccess.rId && this.sId == this.betSuccess.sId ){
					_cr = this.betSuccess.bts[_id-1] || 0;
				}

				if( this.rId == this.betting.rId && this.sId == this.betting.sId ){
					_old = this.betting.bts[ _id-1 ] || 0;
				}else{
					this.betting.rId = this.rId;
					this.betting.sId = this.sId;
					this.betting.bts = [0,0,0,0,0,0];
				}

				_new = _old + _step;
				this.betting.bts[_id-1] = _new;

				this.notify('Ấn đồng ý để hoàn tất', 5);

				this.cuaDatWrap[_id-1][2].setString(MH.numToText(_new+_cr, 1))
				// if(SHOW_LOG) console.log('id: '+_id);
    		}.bind(this));

    		btnCuaDat.setTag(123+i+1);
    		btnCuaDat.x = -116+130*(i%3);
    		btnCuaDat.y = 158 - Math.floor(i/3)*166;
    		this.addChild(btnCuaDat);

    		var lb1 = new cc.LabelTTF("0", MH.getFont("Font_Default"), 24, cc.size(280, 50), cc.TEXT_ALIGNMENT_CENTER);
    		this.addChild(lb1);
    		lb1.x = btnCuaDat.x
    		lb1.y = btnCuaDat.y+54;

    		var lb2 = new cc.LabelTTF("0", MH.getFont("Font_Default"), 24, cc.size(280, 50), cc.TEXT_ALIGNMENT_CENTER);
    		this.addChild(lb2);
    		lb2.x = btnCuaDat.x
    		lb2.y = btnCuaDat.y-59;

    		this.cuaDatWrap.push([btnCuaDat, lb1, lb2]);
    	}
	},
	notify: function(_txt, _t){
		this.removeChildByName("wrapNotify");

		var wrapNotify = new cc.Node();
		wrapNotify.setCascadeOpacityEnabled(true);
        wrapNotify.setPosition(-124, -194);
		wrapNotify.opacity = 0;

		this.addChild(wrapNotify, 99);


		var bg = new cc.Scale9Sprite("res/baucua/notify-bg.png");//cc.rect(0, 0, 269, 50)
        wrapNotify.addChild(bg);

        var lb = new cc.LabelTTF(_txt, MH.getFont("Font_Default"), 26);
        lb.y = -5;
        wrapNotify.addChild(lb);

        bg.width = lb.width + 60;

        var timeOut = _t? _t:3;
        if(timeOut > 1000) timeOut = Math.floor(timeOut/1000);

        wrapNotify.runAction(cc.sequence(cc.fadeIn(0.1), cc.delayTime(timeOut), cc.callFunc(function(){
        	wrapNotify.removeFromParent();
        }, this)));
	},
	tungXucXac: function(a, b, c){
		this.removeChildByName("wrapKQ", "clockB", "clockS");

		var wrapKQ = new cc.Node();
		wrapKQ.setPosition(cc.p(-304, 102));
		wrapKQ.setName("wrapKQ");
		this.addChild(wrapKQ);

		var sprite = new cc.Sprite("#BauCua_01.png");
		wrapKQ.addChild(sprite);

		var spriteFrames = [];
		for( var i=1; i<=35; i++ ){
			var _t = i;
			if( i<10 ) _t = "0"+i;
			var frame = cc.spriteFrameCache.getSpriteFrame("BauCua_"+ _t +".png");
			spriteFrames.push(frame);
		}
		var animation1 = new cc.Animation(spriteFrames, 0.05, 1);
		var action = cc.animate(animation1);
		var sequence = cc.sequence(action, cc.callFunc(function(){
			wrapKQ.removeAllChildren();
			wrapKQ.addChild(new cc.Sprite("#"+a+"_1-dice-dice_bc.png"));
			wrapKQ.addChild(new cc.Sprite("#"+b+"_2-dice-dice_bc.png"));
			wrapKQ.addChild(new cc.Sprite("#"+c+"_3-dice-dice_bc.png"));

			LobbyRequest.getInstance().requestUpdateMoney();
			this.drawHis();
		}.bind(this), this));
		//run animate
		sprite.runAction(sequence);
	},
	setSession: function(sid){
		this.removeChildByName("wrapSession");
		this.sId = sid;

		var lbSession = new cc.LabelTTF("#"+sid, MH.getFont("Font_Default"), 22, cc.size(280, 50), cc.TEXT_ALIGNMENT_CENTER);
		lbSession.setPosition(-310, 210);
		lbSession.setName("wrapSession");
		this.addChild(lbSession);
	},
	runClockB: function(_t){
		if(_t > 300) _t = Math.floor(_t/1000);
		// this.removeChildByName("wrapKq", "kqNum", "lightTai", "lightXiu", "clockB", "xoayTron");
		this.removeChildByName("clockB", "wrapKQ", "clockS");

		var clockB = new cc.Node();
		clockB.setPosition(-312,90);
		clockB.setName("clockB");
		this.addChild(clockB);

		var num1 = new cc.LabelBMFont("0", "res/taixiu/font/font-taixiu-export.fnt", 400, cc.TEXT_ALIGNMENT_CENTER);
		num1.setScale(0.6)
		num1.setAnchorPoint(1, 0.5);
		clockB.addChild(num1);

		var num2 = new cc.LabelBMFont("0", "res/taixiu/font/font-taixiu-export.fnt", 400, cc.TEXT_ALIGNMENT_CENTER);
		num2.setAnchorPoint(0, 0.5);
		num2.setScale(0.6);
		clockB.addChild(num2);

		if( _t > 5 ){
			num1.setColor(cc.color(255,255,255));
			num2.setColor(cc.color(255,255,255));
		}else{
			num1.setColor(cc.color(255,0, 0));
			num2.setColor(cc.color(255,0, 0));
		}

		num1.setString(Math.floor(_t/10));
		num2.setString(_t%10);

		cc.director.getScheduler().schedule(function(){
			_t -=1;
			if( _t >= 0 ){
				num1.setString(Math.floor(_t/10));
				num2.setString(_t%10);

				if( _t === 5 ){
					num1.setColor(cc.color(255,0, 0));
					num2.setColor(cc.color(255,0, 0));
				}

				//
				num2.y = 80;		
				num2.opacity = 0;
				num2.runAction(cc.fadeIn(0.1));
				num2.runAction(cc.moveBy(0.2, cc.p(0, -80)).easing(cc.easeBackOut()));
				//
				if( Math.floor(_t/10) !== Math.floor((_t+1)/10) ){
					num1.y = 80;		
					num1.opacity = 0;
					num1.runAction(cc.fadeIn(0.1));
					num1.runAction(cc.moveBy(0.2, cc.p(0, -80)).easing(cc.easeBackOut()));
				}
			}else{
				cc.director.getScheduler().unscheduleAllForTarget(clockB);
			}

			cc.log("clockb running");
		}.bind(this), clockB, 1, false);
		// callback, target, interval, repeat, delay, paused, key
	},
	runClockS: function(_t){
		if(_t > 300) _t = Math.floor(_t/1000);

		this.removeChildByName("clockS");

		var clockS = new cc.LabelTTF("", MH.getFont("Font_Default"), 22, cc.size(280, 50), cc.TEXT_ALIGNMENT_CENTER);
		clockS.setPosition(-310, -75);
		clockS.setFontFillColor(cc.color("#ff0000"));
		clockS.setName("clockS");
		this.addChild(clockS);

		var _minute = Math.floor(_t/60),
			_second = _t%60;
		
		if( _minute < 10 ) _minute = "0"+_minute;
		if( _second < 10 ) _second = "0"+_second;
		clockS.setString(_minute+":"+_second);

		cc.director.getScheduler().schedule(function(){
			_t -= 1;
			if( _t > 0 ){
				var _minute = Math.floor(_t/60),
					_second = _t%60;
				
				if( _minute < 10 ) _minute = "0"+_minute;
				if( _second < 10 ) _second = "0"+_second;
				clockS.setString(_minute+":"+_second);
			}else{
				cc.director.getScheduler().unscheduleAllForTarget(clockS);
			}
		}, clockS, 1, false);
	},
	removeChildByName: function(){
		var arr = [];
		for( var i=0; i<arguments.length; i++ ){
			arr.push( arguments[i] );
		}

		var child = this.getChildren();
		for( var i=child.length-1; i>=0; i-- ){
			if( arr.indexOf(child[i].getName()) != -1 ){
				this.removeChild( child[i], true);
			}
		}
	},
	close: function(){
		this.removeFromParent();
	},
	buildBanCuoc: function(arr){
		console.log("BC buildBanCuoc", arr, this.cuaDatWrap);
		for( var j=0; j<arr.length; j++ ){
			if( (arr[j].did-1) < this.cuaDatWrap.length ){
				if( !cc.isUndefined(arr[j].tbt) ) this.cuaDatWrap[arr[j].did-1][1].setString(MH.numToText(arr[j].tbt, 1));
				if( !cc.isUndefined(arr[j].uBM) ) this.cuaDatWrap[arr[j].did-1][2].setString(MH.numToText(arr[j].uBM, 1));
			}
		}
	},
	changeRoom: function(num){
		this.rId = num;

		cc.each(this.btnRooms, function(btn, key){
			if( key == num+"" ) btn.setActive(true);
			else btn.setActive(false);
		});

		// reset betting
		this.betting.bts = [0,0,0,0,0,0];
		this.betting.rId = this.rId;
		this.betting.sId = this.sId;
	},
	drawHis: function(_type){
		console.log("call drawHis");
	},
	disableBet: function(){
		this.enableBet = false;

		this.betting.bts = [0,0,0,0,0,0];
		this.betting.rId = this.rId;
		this.betting.sId = this.sId;

		var arrBet = [];
		for( var i=0; i<this.betSuccess.bts.length; i++ ){
			arrBet.push({uBM: this.betSuccess.bts[i], did: i+1 });
		}
		this.buildBanCuoc( arrBet );
	},
	hasBet: function(){
		var _hasBet = false;
		if( this.betSuccess.sId == this.sId && this.betSuccess.rId == this.rId ){
			for( var i=0; i<this.betSuccess.bts.length; i++ ){
				if( this.betSuccess.bts[i] != 0 ){
					_hasBet = true;
					break;
				}
			}
		}
		return _hasBet;
	},
	resetBet: function(){
		this.betting.sId = this.sId;
		this.betting.bts = [0,0,0,0,0,0];
		this.betting.rId = this.rId;
		// reset betSuccess
		this.betSuccess.sId = this.sId;
		this.betSuccess.bts = [0,0,0,0,0,0];
		this.betSuccess.rId = this.rId;

		for( var i=0; i<this.cuaDatWrap.length; i++ ){
			this.cuaDatWrap[i][1].setString("0");
			this.cuaDatWrap[i][2].setString("0");
		}
	},
	winner: function(m){
		cc.log("BC winner ", m);
	},
	_onReconnect: function(cmd, data){
		BauCuaPlugin.getInstance().register( this.rId );
	},
	_onupdateGame: function(cmd, data){
		if( !data || !data[1] ) return;
		switch( parseInt(cmd) ){
			case baucuaCMD.REGISTER:
				// console.log('baucuaCMD.REGISTER', data );

				if( data[1].hr && data[1].hr.length ) this.his = data[1].hr;
				if( data[1].sId ) this.setSession( data[1].sId );
				if( data[1].rMT ){
					if( data[1].gs == 1 ){ // dang dat
						this.runClockB( data[1].rMT );
					}else{
						this.runClockS( data[1].rMT );
					}
				}
				if( data[1].tFB ) this.timeBet = data[1].tFB;
				if( data[1].tfc ) this.timeTurn = data[1].tfc;
				if( data[1].tfD ) this.timeEndBet = data[1].tfD;

				if( data[1].rrI ){
					var cuocArr = data[1].rrI;
					cuocArr.sort(function(a, b){
						return a-b;
					});

					// console.log("BC roommmm", data[1].rrI );

					// thiz.elementWrap.find('.datcuoc-group .btn-datcuoc').each(function( index ){
					// 	if( cuocArr[ index ] ){
					// 		$(this).data('num', cuocArr[ index ]);
					// 	}
					// });
				}

				if( data[1].bsI ){
					var betArr = data[1].bsI;
					betArr.sort(function(a, b){
						return a-b;
					});

					this.stepBet.step = betArr;

					for( var i=0; i<betArr.length; i++ ){
						if( i<this.stepBet.btns.length ){
							this.stepBet.btns[i].setTitleText(MH.numToText(betArr[i], 1));

							if( this.stepBet.act == i ){
								// active button
							}else{

							}
						}
					}
				}

				if( data[1].bts && data[1].bts && data[1].bts[0] ){
					// reset bet
					this.betting.bts[0,0,0,0,0,0]; 
					// get betSuccess
					this.betSuccess.rId = data[1].bts[0].rId;
					this.betSuccess.sId = this.sId;
					for( var i=0; i<data[1].bts[0].bts.length; i++ ){
						if( !data[1].bts[0].bts[i].uBM ) data[1].bts[0].bts[i].uBM = 0;

						this.betSuccess.bts[ data[1].bts[0].bts[i].did-1 ] = data[1].bts[0].bts[i].uBM || 0;
					}

					if( data[1].bts[0].bts ) this.buildBanCuoc( data[1].bts[0].bts );

					if( data[1].bts[0].rId ) this.changeRoom( data[1].bts[0].rId );
				}

				this.drawHis();

				if( data[1].gs == 1 ){ // dang dat cuoc
					this.enableBet = true;
					// thiz.diaXucXac.attr('class', 'dice');
					this.removeChildByName("wrapKQ");
				}else{
					// thiz.enableBet = false;
					this.disableBet();
				}

				// Xoa hieu ưng cua trung
				// thiz.elementWrap.find('.cuadat .item').removeClass('match');

				break;
			case baucuaCMD.BEGIN_GAME:
				// [5,{"tFB":60000,"tfD":5000,"cmd":7501,"sId":892}]
				// remove dice, run clock, set session
				this.removeChildByName("wrapKQ");

				this.runClockB( this.timeBet );
				if( data[1].sId ) this.setSession( data[1].sId );
				this.resetBet();
				this.enableBet = true;
				// thiz.elementWrap.find('.cuadat .item').removeClass('match');
				break;
			case baucuaCMD.ACCEPT_BET:
				// [5,{"bts":[{"bts":[{"uBM":1000,"tbt":1000,"did":1},{"uBM":1000,"tbt":1000,"did":2},{"tbt":0,"did":3},{"tbt":0,"did":4},{"tbt":0,"did":5},{"tbt":0,"did":6}],"rId":1000}],"cmd":7503}]
				if( data[1].bts && data[1].bts[0] && data[1].bts[0].bts ){
					this.buildBanCuoc( data[1].bts[0].bts );
					for( var i=0; i<data[1].bts[0].bts.length; i++ ){
						this.betSuccess.bts[ data[1].bts[0].bts[i].did-1 ] = data[1].bts[0].bts[i].uBM || 0;
					}
					this.betSuccess.rId = this.rId;
					this.betSuccess.sId = this.sId;

					this.notify('Đặt cược thành công');
				}
				
				var err = BauCuaPlugin.getInstance().checkError( data[1] );
				if( err[0] ){
					this.notify(err[1], 3000);

					var arrBet = [];
					for( var i=0; i<this.betSuccess.bts.length; i++ ){
						arrBet.push({uBM: this.betSuccess.bts[i], did: i+1 });
					}
					this.buildBanCuoc( arrBet );
				}

				// reset betting
				this.betting.bts = [0,0,0,0,0,0];
				break;
			case baucuaCMD.END_GAME:
				cc.log("baucuaCMD.END_GAME");
				// [5,{"cmd":7504,"exM":1980,"m":999952359,"sId":1940}]
				if( data[1].exM ){
					this.scheduleOnce(function(){
						this.winner( data[1].exM );
					}.bind(this), (this.timeXX+500)/1000)
				}
				this.buildBanCuoc( this.betSuccess.bts );
				break;
			case baucuaCMD.RESULT_GAME:
				// {"cmd":7505,"skR":[{"rId":10000,"did":[6,1,4]},{"rId":100000,"did":[4,2,4]},{"rId":1000,"did":[6,6,4]}],"sId":847}
				// cc.log('baucuaCMD.RESULT_GAME');
				for( var i=0; i<data[1].skR.length; i++ ){
					if( data[1].skR[i].rId == this.rId ){
						this.tungXucXac( data[1].skR[i].did[0], data[1].skR[i].did[1], data[1].skR[i].did[2] );
						this.scheduleOnce(function(){
							this.runClockS(this.timeTurn-5000);
						}.bind(this), 5);
						break;
					}
				}
				break;
			case baucuaCMD.BET_AGAIN:
				var err = BauCuaPlugin.getInstance().checkError( data[1] );
				if( err[0] ){
					this.notify(err[1]);
				}else if( data[1].bts ){
					for( var i=0; i<data[1].bts.length; i++ ){
						if( cc.isUndefined(data[1].bts[i].uBM) ) data[1].bts[i].uBM = data[1].bts[i].bM;
					}

					this.buildBanCuoc( data[1].bts );

					for( var i=0; i<data[1].bts.length; i++ ){
						this.betting.bts[ data[1].bts[i].did-1 ] = data[1].bts[i].uBM || 0;
					}
					this.betting.rId = this.rId;
					this.betting.sId = this.sId;

					this.notify('Ấn đồng ý để hoàn tất');
				}
				break;
			case baucuaCMD.DOUBLE_BET:
				var err = BauCuaPlugin.getInstance().checkError( data[1] );
				if( err[0] ){
					this.notify(err[1]);
				}else if( data[1].bts ){
					for( var i=0; i<data[1].bts.length; i++ ){
						if( cc.isUndefined(data[1].bts[i].uBM) ) data[1].bts[i].uBM = data[1].bts[i].bM;
					}

					this.buildBanCuoc( data[1].bts );

					for( var i=0; i<data[1].bts.length; i++ ){
						this.betting.bts[ data[1].bts[i].did-1 ] = data[1].bts[i].uBM || 0;
					}
					this.betting.rId = this.rId;
					this.betting.sId = this.sId;

					this.notify('Ấn đồng ý để hoàn tất');
				}
				break;
			case baucuaCMD.GET_TOP:
				break;
			case baucuaCMD.GET_HISTORY:
				break;
			case baucuaCMD.UPDATE_JACKPOT:
				if( data[1].bts && data[1].bts.length ){
					for( var i=0; i<data[1].bts.length; i++ ){
						if( data[1].bts[i].rId == this.rId ){
							this.buildBanCuoc( data[1].bts[i].if );
							break;
						}
					}
				}
				break;
		}
	},
	onEnter: function(){
		this._super();

		MiniGameClient.getInstance().addListener(baucuaCMD.REGISTER.toString(), this._onupdateGame, this);
		MiniGameClient.getInstance().addListener(baucuaCMD.BEGIN_GAME.toString(), this._onupdateGame, this);
	    MiniGameClient.getInstance().addListener(baucuaCMD.ACCEPT_BET.toString(), this._onupdateGame, this);
	    MiniGameClient.getInstance().addListener(baucuaCMD.END_GAME.toString(), this._onupdateGame, this);
	    MiniGameClient.getInstance().addListener(baucuaCMD.RESULT_GAME.toString(), this._onupdateGame, this);
	    MiniGameClient.getInstance().addListener(baucuaCMD.BET_AGAIN.toString(), this._onupdateGame, this);
	    MiniGameClient.getInstance().addListener(baucuaCMD.DOUBLE_BET.toString(), this._onupdateGame, this);
	    MiniGameClient.getInstance().addListener(baucuaCMD.GET_TOP.toString(), this._onupdateGame, this);
	    MiniGameClient.getInstance().addListener(baucuaCMD.GET_HISTORY.toString(), this._onupdateGame, this);
	    MiniGameClient.getInstance().addListener(baucuaCMD.UPDATE_JACKPOT.toString(), this._onupdateGame, this);
	    MiniGameClient.getInstance().addListener( CMD_OBSERVER.OBSERVER_SLOT_RECONNECT , this._onReconnect, this);

	    BauCuaPlugin.getInstance().register();
	},
	onExit: function(){
		this._super();
		MiniGameClient.getInstance().removeListener(this);
		BauCuaPlugin.getInstance().unRegister();
	}
});