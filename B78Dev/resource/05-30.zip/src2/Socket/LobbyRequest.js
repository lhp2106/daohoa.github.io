//var LobbyRequest = LobbyRequest || {};

var LobbyRequest = (function() {

    var instance = null;

    var LobbyRequestClass = cc.Class.extend({
        requestUpdateMoney : function () {
            cc.getClient().onUpdateMoney();
        },

        getListTable : function (gameID, typeRoom, callback, target) {
            //LobbyRequest.getInstance().show("Đang tải danh sách phòng... ",this);
            var msgObj = {
                cmd:    kCMD.LIST_ROOM,
                gid:    gameID, //
                aid:    typeRoom,
            };
            var sendObj = [
                6,
                Constant.CONSTANT.ZONE_NAME,
                'channelPlugin',
                msgObj
            ];
            //console.log("getListTable "+ JSON.stringify(sendObj) );
            if(!target) target = this;
            cc.getClient().addListener(kCMD.LIST_ROOM, callback, target);
            cc.getClient().send(sendObj);
        },

        getCapcha : function (sessionId, callback) {
            var request = {
                command: "getCaptcha",
                sessionId: sessionId
            };

            cc.getClient().addListener("getCaptcha", callback, this);

            cc.getClient().httpRequest(HostConfig.services.id, request);
        },
        /**
         *
         * @param roomInfo
         * @param callbackWhenJoinDone(isJoinDone, errorMsg(str) is Fail to join)
         */
        joinRoom : function (roomInfo, callbackWhenJoinDone) {
            //LobbyRequest.getInstance().show("Đang vào phòng...");
            cc.getClient().handlerJoinRoomSuccess = callbackWhenJoinDone;//clear html lobby, show canvas game
            cc.getClient().onJoinRoom(roomInfo);
            cc.director.getRunningScene().loadingDialog("Đang vào phòng..", 10, function(){ cc.getClient().reConnect(); })
        },
        /**
         *
         * @param idAvatar: ID AVATAR thay doi
         * callback(cmd, data) => cmd la string command(ko can quan tam), data co dang
         */
        updateAvatar : function (idAvatar, callback) {
            /*var callback  = function(cmd, data){
             var status = data["status"];
             if (status == 0) {//success
             //refresh avatar tren menubar
             //update PlayerMe.avatar  = link avatar moi
             PlayerMe.avatar = url;
             }
             }*/
            //if(!target) target = this;

            var request = {
                command: "updateAvatar",
                id: idAvatar
            };

            cc.getClient().removeListener(this);
            cc.getClient().addListener("updateAvatar", callback, this);
            cc.getClient().httpRequest(HostConfig.services.id, request);
        },

        createTable : function(callback){
            var sendObj = [
                command.ZonePluginMessage,
                Constant.CONSTANT.ZONE_NAME,
                'channelPlugin',
                {
                    'cmd':311,
                    'gid':cc.Global.gameId,
                    'aid':cc.Global.moneyType
                }
            ];
            cc.getClient().addListener(kCMD.CREATE_TABLE, callback, this);
            cc.getClient().send(sendObj);
        },

        okCreateRoomBtnHandler : function (moneyBet, maxUser) {
            var data={};
            data.b=moneyBet;//this.currentValue;
            data.Mu = maxUser;//this.maxUser;

            var sendObj = [
                command.ZonePluginMessage,
                Constant.CONSTANT.ZONE_NAME,
                'channelPlugin',
                { 'cmd':308,
                    'gid':cc.Global.gameId,
                    'aid':cc.Global.moneyType,
                    'b'  : data.b,
                    'Mu' :data.Mu
                }
            ];
            cc.log("create room "+JSON.stringify(sendObj));
            cc.director.getRunningScene().loadingDialog(true);

            cc.getClient().send(sendObj);
        },

        getForgotPass : function (displayName, callback) {
            var request = {
                command: "fetchForgotPasswordSyntax",
                displayName: displayName,
                telcoId: 1
            };
            cc.getClient().addListener("fetchForgotPasswordSyntax", callback, this);
            cc.getClient().httpRequest(HostConfig.services.paygate, request);
        }
    });

    return {
        getInstance: function () {
            if (!instance) instance = new LobbyRequestClass();
            return instance;
        }
    };
})();