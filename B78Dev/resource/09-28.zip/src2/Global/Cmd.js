<0(k;.AA0>2k]kl
kkkkTJPIZvkb,
kkkkTJPJHFvkc,
kkkkRJIZEJJ[vd,
kkkkT&0<&E..Ave,
kkkkE..AK8+4->[&1104&vf,
kkkkU.>&K8+4->[&1104&vg,
kkkkK->4[&1104&vh,
kkkkK->4E&1/.>1&vg,
m_
<0(k7W[Nk]k7W[Nk||kl
kkkkkkkkTJPIZkvk"b",
kkkkkkkkTJPJHFkvk"c",
kkkkkkkkRJIZEJJ[v"d",
kkkkkkkkT&0<&E..Av"e",
kkkkkkkkE..AK8+4->[&1104&v"f",
kkkkkkkkYEJLMFWLMFFIXIvk"ba",
kkkkkkkkHMDEyIZOJvk"baa",
kkkkkkkkWQLFkkkkvk"bac",
kkkkkkkkYEJLMFWLMFvk"bae",
kkkkkkkkHMDEyRJIZyJHFkk		vk"caa",
kkkkkkkkEJJ[yIZOJkkkkkk		vk"cac",
kkkkkkkkEJJ[y[LMFDEyWQLZPDkkkkkvk"cad",
kkkkkkkkNDLTyWLENkkkkkkkkkkkkkkvk"cfa",
kkkkkkkkWQLZPDyFHEZkkkkkkkkkkkkvk"cfb",
kkkkkkkkFJIyFELZPkkkkkkkkkkkkkkvk"cfc",
kkkkkkkkNLZQyYLIkkkkkkkkkkkkkkkvk"cfd",
kkkkkkkkEDRDWFyFHEZkkkkkkkkkkkkvk"cfe",
kkkkkkkkDEEJEkkkkkkkkkkkkkkkkkkvk"b",
kkkkkkkkSIWSyKTLGDEkkkkkkkkkkkkvk"d",
kkkkkkkkKTLGDEyEDLNGkkkkkkkkkkkvk"f",
kkkkkkkkTIMFyEJJ[kkkkkkkkkkkkkkkv"daa",
kkkkkkkkTIMFyIZXIFDkkkkk		vk"dad",
kkkkkkkkMDZNyIZXIFDkkkkk		vk"dae",
kkkkkkkkEDWDIXDyIZXIFDkkkkk	vk"daf",
kkkkkkkkJYMDEXDEyIZXIFDkkkkkkkkvk"dag",
kkkkkkkkOLMFyKTLGkkkkkkkkkkkkkkvk"dah",
kkkkkkkkRJIZyEJJ[kkkkkk		vk"dai",
kkkkkkkkHKNLFDy[JZDGkkkkkk		vk"dba",k
kkkkkkkkWEDLFDyFLYTDkkkkkk		vk"dbb",
kkkkkkkkEDPIMFDEyNJZDkkkkkk		vk"EDPIMFDEyNJZD",
kkkkkkkkEDPIMFDEyOYyNJZDkkkkkk		vk"EDPIMFDEyOYyNJZD",
kkkkkkkkNDMFEJGyPL[Dkkkkvk"NDMFEJGyPL[D",
kkkkkkkkKQJ[yDLEZyWLENkkkkvk"KQJ[yDLEZyWLEN",
kkkkkkkkEDWJZZDWFyIZPL[Dkkkkvk"EDWJZZDWFyIZPL[D",
kkkkkkkkWJZOIPyMHWWDMMkvk"WJZOIPyMHWWDMM",
kkkkkkkkOYyTIYMyMHWWDMMvk"OYyTIYMyMHWWDMM",
kkkkkkkkJYMDEXDEyEDMKJZMDkvk"JYMDEXDEyEDMKJZMD",
kkkkkkkkFJKyQHkkkkk		vk"baaaa",
kkkkkkkkWQLZPDyTIZDMyMTJFkkkkk		vk"WQLZPDyTIZDMyMTJF",
kkkkkkkkHKNLFDyRHMFyCIZkkkkk		vk"HKNLFDyRHMFyCIZ",
kkkkkkkkTJPJHFyMTJFy[IZIPL[Dkkkkk		vk"TJPJHFyMTJFy[IZIPL[D",
kkkkkkkkKEJPDMMyJKDZyPL[Dkvk"KEJPDMMyJKDZyPL[D"
m_
<0(k3(-&>2W[Nk]k3(-&>2W[Nk||kl
kkkkkkkkkkkkIMyOEIDZNkvkdfa,
kkkkkkkkkkkkEDBHDMFyOEIDZNkvkdfb,
kkkkkkkkkkkkOEIDZNyEDBHDMFyLNNvdfc,
kkkkkkkkkkkkOEIDZNyEDBHDMFyLWWDKFvdfd,
kkkkkkkkkkkkOEIDZNyED[JXDvkdff
kkkkm_
<0(k;50)W[Nk]k;50)W[Nk||kl
kkkkkkkkkkkkTIMFyWQLZZDTkvkdga,
kkkkkkkkkkkkMDZNy[DMMLPDkvkdgb
kkkkm_
<0(k/50)8.;W[Nk]k/50)8.;W[Nk||kl
kkkkkkkkJYMDEXDEkvkbeaa,
kkkkkkkkED[JXDyJYMDEXDEkvkbeab,
kkkkkkkkYDPIZyPIXDLCLGkvkbeac,
kkkkkkkkYDPIZyPDFyPIXDLCLGkvkbeah,
kkkkkkkk[JZDGyELZPDkvkbeaf,
kkkkkkkkNJyPIXDLCLGkvkbead,
kkkkkkkkPDFyPIXDLCLGkvkbeae,
kkkkkkkkDZNyPIXDLCLGkvkbeai,
kkkkm_
<0(k;0.)50/W[Nk]k;0.)50/W[Nk||kl
kkkkkkkkPDFyIZOJkvkbfaa,
kkkkkkkkMFLEFyPL[Dkvkbfab,
kkkkkkkkMKIZkvkbfac,
kkkkkkkkMFJKyMKIZkvkbfad,
kkkkkkkkHKNLFDyRLWSKJFkvkbfae
kkkkm_
<0(k!5&&8W[Nk]k!5&&8W[Nk||kl
kkkkkkkkEDPIMFDEkvkhaaa,
kkkkkkkkHZEDPIMFDEkvkhaag,
kkkkkkkkPDFyQIMFJEGkvkhaae,
kkkkkkkkPDFyFJKkvkhaaf,
kkkkkkkkMKIZkvkhaab,
kkkkkkkkHKNLFDyRLWSKJFvkhaac
kkkkm_
<0(k=0+;+0W[Nk]k=0+;+0W[Nk||kl
kkkkkkkkEDPIMFDEkvkhfaa,
kkkkkkkkHZEDPIMFDEkvkhfba,
kkkkkkkkYDPIZyPL[Dkvkhfab,
kkkkkkkkHKNLFDyRLWSKJFvkhfac,
kkkkkkkkLWWDKFyYDFkvkhfad,
kkkkkkkkDZNyPL[Dkvkhfae,
kkkkkkkkEDMHTFyPL[Dkvkhfaf,
kkkkkkkkYDFyLPLIZkvkhfag,
kkkkkkkkNJHYTDyYDFkvkhfah,
kkkkkkkkPDFyQIMFJEGkvkhfai,
kkkkkkkkPDFyFJKkvkhfaj
kkkkm_
<0(kJ)/W[Nk]kJ)/W[Nk||kl
kkkkkkkkEDPIMFDEkvk'4&)J)/W.2&',
kkkkkkkkHZEDPIMFDEkvkhfba,
kkkkkkkkXDEIOGkvk'<&(-3*W.2&'
kkkkm_
<0(k:.1.W[Nk]k:.1.W[Nk||kl
kkkkLWWDKFyYDFkvkbhaa,
kkkkPDFyQIMFJEGkvkbhab,
kkkkEDMHTFyPL[Dkvkbhac,
kkkkEDPIMFDEkvkbhad
m_