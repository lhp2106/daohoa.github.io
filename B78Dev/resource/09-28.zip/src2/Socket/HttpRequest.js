
<0(kQ))/E& +&1)k]kQ))/E& +&1)k||klm_
Q))/E& +&1)}EDMyMHWWDMMk]ka_
Q))/E& +&1)}EDMyDEEJEk]kb_
Q))/E& +&1)}EDMyLYJHFk]kc_
Q))/E& +&1)}(& +&1)PDF[&)5.2k]k3+>;)-.>kp+(8,k5&02&(,k/0(0A,k;088=0;7qkl
kkkk<0(k3+88H(8k]k+(8_
kkkk-3pw3+88H(8}&>21C-)5p"?"qql
kkkkkkkk3+88H(8kr]k"?"_
kkkkm
kkkk-3p/0(0Aql
kkkkkkkk<0(k3-(1)K0(0Ak]k)(+&_
kkkkkkkk3.(kp<0(k7&*k->k/0(0Aqkl
kkkkkkkkkkkk-3p3-(1)K0(0Aql
kkkkkkkkkkkkkkkk3-(1)K0(0Ak]k3081&_
kkkkkkkkkkkkm
kkkkkkkkkkkk&81&l
kkkkkkkkkkkkkkkk3+88H(8kr]k"x"_
kkkkkkkkkkkkm
kkkkkkkkkkkk-3pw/0(0A}501J!>K(./&()*p7&*qqk;.>)->+&_
kkkkkkkkkkkk3+88H(8kr]k7&*krk"]"krk/0(0An7&*o}).M)(->4pq_
kkkkkkkkm
kkkkm
kkkk<0(k(& +&1)k]k;;}8.02&(}4&)V[TQ))/E& +&1)pq_
kkkk(& +&1)}./&>p"PDF",k3+88H(8q_
kkkk(& +&1)}1&)E& +&1)Q&02&(p"W.>)&>)sF*/&","0//8-;0)-.>u:s!!!s3.(As+(8&>;.2&2"q_
kkkk-3p5&02&(ql
kkkkkkkk3.(kp<0(k7&*k->k5&02&(qkl
kkkkkkkkkkkk-3pw5&02&(}501J!>K(./&()*p7&*qqk;.>)->+&_
kkkkkkkkkkkk(& +&1)}1&)E& +&1)Q&02&(p7&*,k5&02&(n7&*o}).M)(->4pqq_
kkkkkkkkm
kkkkm
kkkk(& +&1)}.>(&02*1)0)&;50>4&k]k3+>;)-.>kpqkl
kkkkkkkk-3kp(& +&1)}(&02*M)0)&k]]]keq
kkkkkkkkkkkkp(& +&1)}1)0)+1k]]]kcaa||(& +&1)}1)0)+1k]]]kaqk?k;088=0;7pQ))/E& +&1)}EDMyMHWWDMM,kRMJZ}/0(1&p(& +&1)}(&1/.>1&F&:)qqkvk;088=0;7pQ))/E& +&1)}EDMyDEEJE,k>+88q_
kkkkm_
kkkk(& +&1)}1&>2pq_
m_
Q))/E& +&1)}(& +&1)KJMF[&)5.2k]k3+>;)-.>kp+(8,k5&02&(,k/0(0A,k;088=0;7qkl
kkkk<0(k3+88H(8k]k+(8_
kkkk<0(k(& +&1)k]k;;}8.02&(}4&)V[TQ))/E& +&1)pq_
kkkk(& +&1)}./&>p"KJMF",k3+88H(8q_
kkkk(& +&1)}1&)E& +&1)Q&02&(p"W.>)&>)sF*/&","0//8-;0)-.>u61.>"q_
kkkk-3p5&02&(ql
kkkkkkkk3.(kp<0(k7&*k->k5&02&(qkl
kkkkkkkkkkkk-3pw5&02&(}501J!>K(./&()*p7&*qqk;.>)->+&_
kkkkkkkkkkkk(& +&1)}1&)E& +&1)Q&02&(p7&*,k5&02&(n7&*o}).M)(->4pqq_
kkkkkkkkm
kkkkm
kkkk(& +&1)}.>(&02*1)0)&;50>4&k]k3+>;)-.>kpql
kkkkkkkk-3kp(& +&1)}(&02*M)0)&k]]keql
kkkkkkkkkkkkp(& +&1)}1)0)+1k]]]kcaa||(& +&1)}1)0)+1k]]]kaqk?k;088=0;7pQ))/E& +&1)}EDMyMHWWDMM,kRMJZ}/0(1&p(& +&1)}(&1/.>1&F&:)qqkvk;088=0;7pQ))/E& +&1)}EDMyDEEJE,k>+88q_
kkkkkkkkm
kkkkm_
kkkk(& +&1)})-A&.+)k]kfaaa_
kkkk(& +&1)}1&>2pkRMJZ}1)(->4-3*p/0(0Aqkq_
m_
Q))/E& +&1)}(& +&1)PDF[&)5.2yOYk]k3+>;)-.>kp+(8,k5&02&(,k/0(0A,k;088=0;7qkl
kkkk<0(k3+88H(8k]k+(8_
kkkk-3p/0(0Aql
kkkkkkkk<0(k3-(1)K0(0Ak]k)(+&_
kkkkkkkk3.(kp<0(k7&*k->k/0(0Aqkl
kkkkkkkkkkkk-3p3-(1)K0(0Aql
kkkkkkkkkkkkkkkk3-(1)K0(0Ak]k3081&_
kkkkkkkkkkkkm
kkkkkkkkkkkk&81&l
kkkkkkkkkkkkkkkk3+88H(8kr]k"x"_
kkkkkkkkkkkkm
kkkkkkkkkkkk-3pw/0(0A}501J!>K(./&()*p7&*qqk;.>)->+&_
kkkkkkkkkkkk3+88H(8kr]k7&*krk"]"krk/0(0An7&*o}).M)(->4pq_
kkkkkkkkm
kkkkm
kkkk<0(k(& +&1)k]k;;}8.02&(}4&)V[TQ))/E& +&1)pq_
kkkk(& +&1)}./&>p"PDF",k3+88H(8q_
kkkk(& +&1)}1&)E& +&1)Q&02&(p"W.>)&>)sF*/&","0//8-;0)-.>u:s!!!s3.(As+(8&>;.2&2"q_
kkkk-3p5&02&(ql
kkkkkkkk3.(kp<0(k7&*k->k5&02&(qkl
kkkkkkkkkkkk-3pw5&02&(}501J!>K(./&()*p7&*qqk;.>)->+&_
kkkkkkkkkkkk(& +&1)}1&)E& +&1)Q&02&(p7&*,k5&02&(n7&*o}).M)(->4pqq_
kkkkkkkkm
kkkkm
kkkk(& +&1)}.>(&02*1)0)&;50>4&k]k3+>;)-.>kpql
kkkkkkkk-3kp(& +&1)}(&02*M)0)&k]]keql
kkkkkkkkkkkk;088=0;7pQ))/E& +&1)}EDMyMHWWDMM,kRMJZ}/0(1&p(& +&1)}(&1/.>1&F&:)qq_
kkkkkkkkm&81&l
kkkkkkkkkkkk;088=0;7pQ))/E& +&1)}EDMyDEEJE,k>+88q_
kkkkkkkkm
kkkkm_
kkkk(& +&1)}1&>2pq_
m_
