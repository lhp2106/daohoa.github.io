<0(kN-;&N-;&N-;&k]k;;}Z.2&}&:)&>2pl
	y=&))->4vka,
	y40A&I2vkW.>1)0>)}PL[DyIN}YIPMTJF}NIWDNIWDNIWD,
	yA.>&*F*/&vk[.>&*F*/&}P.82,
	y-1F(-08vk3081&,
	y)(-08R0;7/.)vkfaaaaaaa,
	y.>M/->vk3081&,
	y1/->O01)vk3081&,
	y18.)N0)0vk>+88,
	y0+).M/->vk3081&,
	y1&11-.>vk3081&,
kkkk;).(vk3+>;)-.>pql
kkkk	)5-1}y1+/&(pq_
kkkk	)5-1}1&)K.1-)-.>p;;}!->M-9&}!-2)5uc,k;;}!->M-9&}5&-45)ucq_
kkkk	)5-1}1&)M;08&pa}ggggggghq_
kkkk	)5-1}y8->&1k]kno_
		)5-1}y20)0R0;7/.)k]knlRvam,lRvam,lRvamo_
		)5-1}y1/->>->4k]kl
	kkkk	1-2vka,
	kkkk	0)vka
	kkkkm_
	kkkk)5-1}y80=&81Q+k]kn>+88,k>+88,k>+88,k>+88,k>+88o_
	kkkk)5-1}y3(&&1/->N0)0k]kl
	kkkk	"baa"vl=vbaa,k81vno,k0-vb,k31va,k!->vkam,
	kkkkkkkk"baaa"vl=vbaaa,k81vno,k0-vb,k31va,k!->vkam,
	kkkkkkkk"baaaa"vl=vbaaaa,k81vno,k0-vb,k31va,k!->vkam
	kkkkm_
kkkk	)5-1}y1/&07&(k]k>&!kL+2-.N&<-;&pq_
kkkk	)5-1}y1/&07&(}1&)N0)0pl
kkkk		"1.+>2M/->"vk"(&1u2-;&2-;&2-;&u1.+>2u1/->T../}A/d",
	kkkkkkkk"1.+>2W.8M)./"vk"(&1u2-;&2-;&2-;&u1.+>2u1/->M)./}A/d",
	kkkkkkkk".>&T->&F->4"vk"(&1u2-;&2-;&2-;&u1.+>2u.>&T->&F->4}A/d",
	kkkkkkkk";.->H/T../"vk"(&1u2-;&2-;&2-;&u1.+>2u;.->H/T../}A/d",
	kkkkkkkk"=-4C->"vk"(&1u2-;&2-;&2-;&u1.+>2u=-4C->}A/d",
	kkkkkkkk"!->O(&&M/->"v"(&1u2-;&2-;&2-;&u1.+>2u!->O(&&M/->}A/d",
	kkkkkkkk"!->R0;7/.)"vk"(&1u2-;&2-;&2-;&u1.+>2u!->R0;7/.)}A/d",
	kkkkkkkk"!->Y.>+1"vk"(&1u2-;&2-;&2-;&u1.+>2u!->Y.>+1}A/d",
	kkkkkkkk"=+)).>W8-;7"vk"(&1u2-;&2-;&2-;&u1.+>2u=+)).>W8-;7}A/d",
	kkkkkkkk"./&>J)5&(E+.>4"vk"(&1u2-;&2-;&2-;&u1.+>2u./&>J)5&(E+.>4}A/d",
	kkkkkkkk"5.<&(E..A"vk"(&1u2-;&2-;&2-;&u1.+>2u5.<&(E..A}A/d"
kkkk	mq_
kkkk	<0(k!(0/T.==*k]k>&!k;;}Z.2&pq_
kkkk	)5-1}022W5-82p!(0/T.==*q_
kkkk	)5-1}!(0/T.==*k]k!(0/T.==*_
kkkk	<0(k!(0/K80*k]k>&!k;;}Z.2&pq_
kkkk	)5-1}022W5-82p!(0/K80*q_
kkkk	)5-1}!(0/K80*k]k!(0/K80*_
kkkk	;;}2-(&;).(}4&)E+>>->4M;&>&pq}1&)Y0;74(.+>2p"(&1u2-;&2-;&2-;&u=0;74(.+>2}6/4"q_
kkkk	<0(k=4k]k>&!k;;}M/(-)&p"(&1u2-;&2-;&2-;&u/80*u=0;74(.+>2}6/4"q_
		!(0/K80*}022W5-82p=4q_
		<0(k1)&>;-8k]k>&!k;;}N(0!Z.2&pq_
kkkkkkkk1)&>;-8}2(0!K.8*pk
kkkkkkkkkkkkn;;}/pa,kaq,;;}/pjia,kaq,;;}/pjia,egiq,;;}/pa,kegiqo,
kkkkkkkkkkkk;;};.8.(pcff,ka,ka,kcffq,
kkkkkkkkkkkka,
kkkkkkkkkkkk;;};.8.(pcff,kcff,kcff,kaq
kkkkkkkkq_
kkkkkkkk<0(k75+>4k]k>&!k;;}W8-//->4Z.2&p1)&>;-8q_
kkkkkkkk75+>4}1&)K.1-)-.>psehg,kscjeq_
kkkkkkkk!(0/K80*}022W5-82p75+>4q_
kkkkkkkk)5-1};.8+A>1k]kno_
kkkkkkkk<0(k-)&A1k]kno_
kkkkkkkk3.(pk<0(k-]a_k-z]g_k-rrkql
kkkkkkkk	-)&A1}/+15pk;;}1/(-)&O(0A&W0;5&}4&)M/(-)&O(0A&p-r"y2-;&2-;&2-;&}/>4"qkq_
kkkkkkkkm
kkkkkkkk3.(p<0(k-]a_k-zf_k-rrql
kkkkkkkk	<0(k;.8k]k>&!kW.8+A>pl
kkkkkkkk		-)&AQvkbfg,
kkkkkkkk		-)&A1vk-)&A1,
kkkkkkkk		1/&&2vkcdaa,
kkkkkkkk		=0;7J+)vkfa,
kkkkkkkk		=0;7I>vkda,
kkkkkkkk		->2&:vk-
kkkkkkkk	mq_
kkkkkkkk	;.8}1&)K.1-)-.>p-tbjhrie,aq_
kkkkkkkk	75+>4}022W5-82p;.8q_
kkkkkkkkkkkk)5-1};.8+A>1n-ok]k;.8_
kkkkkkkkkkkk;.8}.>Y&3.(&M)./k]k3+>;)-.>p)0(4&)ql
kkkkkkkk		)5-1}y1/&07&(}/80*D33&;)p"1.+>2W.8M)./"q_
kkkkkkkk	m}=->2p)5-1q_
kkkkkkkkm
kkkkkkkk)5-1};.8+A>1neo}.>L3)&(M)./k]k3+>;)-.>pql
kkkkkkkk	)5-1}y1/&07&(}1)./Y*F04p"1.+>2M/->"q_
kkkkkkkk	)5-1};5&;7Q01C->pq_
		m}=->2p)5-1q_
		<0(k=)>Y0;7k]k>&!k>&!+-}Y+)).>p"(&1u2-;&2-;&2-;&u8.==*u=)>y=0;7}/>4",k3+>;)-.>pql
			)5-1}y4.).T.==*pq_
		m}=->2p)5-1qq_
		=)>Y0;7}1&)K.1-)-.>psiba,kedaq_
		!(0/K80*}022W5-82p=)>Y0;7q_
		<0(k8=4.82k]k>&!k>&!+-}T0=&8Y[O.>)pk[Q}>+AF.F&:)pK80*&([&}4.82qk,k"(&1u2-;&2-;&2-;&u3.>)u>+A=&(}3>)"q_
		8=4.82}1&)M;08&pa}fq_
		8=4.82}1&)K.1-)-.>pscff,kcfjq_
		8=4.82}1&)L>;5.(K.->)pa,kaq_
		!(0/K80*}022W5-82p8=4.82q_
		)5-1}8=K80*&(P.82ak]k8=4.82_
		<0(k8=5+k]k>&!k>&!+-}T0=&8Y[O.>)p"a",k"(&1u2-;&2-;&2-;&u3.>)u>+A=&(}3>)"q_
		8=5+}1&)M;08&pa}fq_
		8=5+}1&)K.1-)-.>pbbf,kcfjq_
		8=5+}1&)L>;5.(K.->)pa,kaq_
		!(0/K80*}022W5-82p8=5+q_
		)5-1}y80=&81Q+neok]k8=5+_
		<0(k8=M&11-.>k]k>&!k>&!+-}T0=&8Y[O.>)p"#a",k"(&1u2-;&2-;&2-;&u3.>)u>+A=&(}3>)"q_
		8=M&11-.>}1&)M;08&pa}eddq_
		8=M&11-.>}1&)K.1-)-.>pa,kcbaq_
		8=M&11-.>}1&)W.8.(p;;};.8.(p"#&d2==&"qq_
		8=M&11-.>}1&)L>;5.(K.->)pa}f,kaq_
		!(0/K80*}022W5-82p8=M&11-.>q_
		)5-1}8=M&11-.>k]k8=M&11-.>_
		<0(k=)>X->5N0>5k]k>&!k>&!+-}Y+)).>p"(&1u2-;&2-;&2-;&u8.==*u=)>y=:5}/>4",k3+>;)-.>pql
			)5-1}15.!X->5N0>5pq_
		m}=->2p)5-1qq_
		=)>X->5N0>5}1&)K.1-)-.>pgia,kedaq_
		!(0/K80*}022W5-82p=)>X->5N0>5q_
		<0(k=)>M&))->4k]k>&!k>&!+-}Y+)).>p"(&1u2-;&2-;&2-;&u8.==*u=)>y;0-20)}/>4",k3+>;)-.>pql
			)5-1}15.!W0-N0)pq_
		m}=->2p)5-1qq_
		=)>M&))->4}1&)K.1-)-.>piga,kedaq_
		!(0/K80*}022W5-82p=)>M&))->4q_
		<0(k=)>Q&8/k]k>&!k>&!+-}Y+)).>p"(&1u2-;&2-;&2-;&u8.==*u=)>y5&8/}/>4",k3+>;)-.>pql
			)5-1}15.!Q+.>4N0>pq_
		m}=->2p)5-1qq_
		=)>Q&8/}1&)K.1-)-.>psifa,ksedfq_
		!(0/K80*}022W5-82p=)>Q&8/q_
		<0(k=)>F+B+0*k]k>&!k>&!+-}Y+)).>pn"(&1u2-;&2-;&2-;&u/80*u=)>y)+ +0*}/>4",k"(&1u2-;&2-;&2-;&u/80*u=)>y2+>4}/>4"o,k3+>;)-.>pql
			)5-1};50>4&L+).M/->pq_
		m}=->2p)5-1qq_
		=)>F+B+0*}1&)K.1-)-.>pbef,ksebiq_
		!(0/K80*}022W5-82p=)>F+B+0*q_
		)5-1}=)>F+B+0*k]k=)>F+B+0*_
		<0(k=)>B+0*k]k>&!k>&!+-}Y+)).>p"(&1u2-;&2-;&2-;&u/80*u=)>y +0*}/>4",k3+>;)-.>pql
			)5-1}y1/&07&(}/80*D33&;)p"=+)).>W8-;7"q_
			)5-1}y1&>2E& +&1)M/->pq_
		m}=->2p)5-1qq_
		=)>B+0*}1&)K.1-)-.>pece,ksebiq_
		!(0/K80*}022W5-82p=)>B+0*q_
		)5-1}=)>B+0*k]k=)>B+0*_
		<0(k=)>[+;W+.;k]k>&!k>&!+-}Y+)).>p"(&1u2-;&2-;&2-;&u/80*u/baa}/>4",k3+>;)-.>pql
			)5-1};50>4&Y&))->4p"HK"q_
		m}=->2p)5-1qq_
		=)>[+;W+.;}1&)K.1-)-.>psebj,ksebiq_
		!(0/K80*}022W5-82p=)>[+;W+.;q_
		)5-1}=)>[+;W+.;k]k=)>[+;W+.;_
		<0(k=)>N.>4k]k>&!k>&!+-}Y+)).>p"(&1u2-;&2-;&2-;&u/80*u=)>y2.>4}/>4",k3+>;)-.>pql
			)5-1}15.!W5.>N.>4pq_
		m}=->2p)5-1qq_
		=)>N.>4}1&)K.1-)-.>psbdh,ksebdq_
		!(0/K80*}022W5-82p=)>N.>4q_
		<0(k8=N.>4k]k>&!k>&!+-}T0=&8Y[O.>)p"a",k"(&1u2-;&2-;&2-;&u3.>)u>+A=&(}3>)"q_
		8=N.>4}1&)M;08&pa}fq_
		8=N.>4}1&)K.1-)-.>pbec,kgaq_
		8=N.>4}1&)W.8.(p;;};.8.(p"#h0hfg0"qq_
		8=N.>4}1&)L>;5.(K.->)pa,aq_
		=)>N.>4}022W5-82p8=N.>4q_
		)5-1}8=N.>4k]k8=N.>4_
		<0(k).>4F50>4k]k>&!k>&!+-}T0=&8Y[O.>)p"a",k"(&1u2-;&2-;&2-;&u3.>)u>+A=&(}3>)"q_
		).>4F50>4}1&)M;08&pa}fq_
		).>4F50>4}1&)K.1-)-.>pijc,kfiq_
		).>4F50>4}1&)L>;5.(K.->)pb,kaq_
		!(0/K80*}022W5-82p).>4F50>4q_
		)5-1}8=F.>4F50>4k]k).>4F50>4_
		<0(k).>4N0)k]k>&!k>&!+-}T0=&8Y[O.>)p"a",k"(&1u2-;&2-;&2-;&u3.>)u>+A=&(}3>)"q_
		).>4N0)}1&)M;08&pa}fq_
		).>4N0)}1&)K.1-)-.>pijc,ksfjq_
		).>4N0)}1&)L>;5.(K.->)pb,kaq_
		!(0/K80*}022W5-82p).>4N0)q_
		)5-1}8=F.>4N0)k]k).>4N0)_
		<0(k8=Z+AO(&&M/->k]k>&!k;;}M/(-)&p"(&1u2-;&2-;&2-;&u/80*u8+.) +0*A/}/>4"q_
		8=Z+AO(&&M/->}1&)K.1-)-.>psba,ksciaq_
		8=Z+AO(&&M/->}1&)X-1-=8&p3081&q_
		!(0/K80*}022W5-82p8=Z+AO(&&M/->q_
		)5-1}8=Z+AO(&&M/->k]k8=Z+AO(&&M/->_
		<0(k>+AO(&&M/->k]k>&!k>&!+-}T0=&8Y[O.>)p"c",k"(&1u2-;&2-;&2-;&u3.>)u>+A=&(}3>)"q_
		>+AO(&&M/->}1&)K.1-)-.>peff,kjq_
		>+AO(&&M/->}1&)M;08&pa}gq_
		>+AO(&&M/->}1&)L>;5.(K.->)pa,kaq_
		>+AO(&&M/->}1&)W.8.(p;;};.8.(p"#hd3fij"qq_
		8=Z+AO(&&M/->}022W5-82p>+AO(&&M/->q_
		<0(k!(0/T->&k]k>&!k;;}Z.2&pq_
		!(0/T->&}1&)K.1-)-.>psebf,kbfgq_
		!(0/T->&}1&)X-1-=8&p3081&q_
		!(0/K80*}022W5-82p!(0/T->&q_
		)5-1}!(0/T->&k]k!(0/T->&_
		<0(k!(0/C->k]k>&!k;;}Z.2&pq_
		!(0/C->}1&)X-1-=8&p3081&q_
		!(0/K80*}022W5-82p!(0/C->q_
		)5-1}!(0/C->k]k!(0/C->_
		<0(k!(0/Y.>+1k]k>&!k;;}Z.2&pq_
		!(0/Y.>+1}1&)X-1-=8&p3081&q_
		)5-1}022W5-82p!(0/Y.>+1q_
		)5-1}!(0/Y.>+1k]k!(0/Y.>+1_
kkkkm,
kkkky4.).T.==*vk3+>;)-.>pql
kkkk	)5-1}y=&))->4k]ka_
	kkkk)5-1}y-1F(-08k]k3081&_
	kkkk)5-1}y.>M/->k]k3081&_
	kkkk)5-1};50>4&L+).M/->p3081&q_
kkkk	)5-1}!(0/K80*}1&)X-1-=8&p3081&q_
kkkk	)5-1}!(0/T.==*}1&)X-1-=8&p)(+&q_
		)5-1}!(0/T.==*}(&A.<&L88W5-82(&>pq_
		<0(k=4k]k>&!k;;}M/(-)&p"(&1u2-;&2-;&2-;&u8.==*u=0;74(.+>2}6/4"q_
		)5-1}!(0/T.==*}022W5-82p=4q_
		<0(k=)>Y0;7k]k>&!k>&!+-}Y+)).>p"(&1u2-;&2-;&2-;&u8.==*u=)>y=0;7}/>4",k3+>;)-.>pql
			[Q};50>4&K04&p"5.A&"q_
		mq_
		=)>Y0;7}1&)K.1-)-.>psiba,kedaq_
		)5-1}!(0/T.==*}022W5-82p=)>Y0;7q_
		<0(k=)>X->5N0>5k]k>&!k>&!+-}Y+)).>p"(&1u2-;&2-;&2-;&u8.==*u=)>y=:5}/>4",k3+>;)-.>pql
			)5-1}15.!X->5N0>5pq_
		m}=->2p)5-1qq_
		=)>X->5N0>5}1&)K.1-)-.>pgia,kedaq_
		)5-1}!(0/T.==*}022W5-82p=)>X->5N0>5q_
		<0(k=)>M&))->4k]k>&!k>&!+-}Y+)).>p"(&1u2-;&2-;&2-;&u8.==*u=)>y;0-20)}/>4",k3+>;)-.>pql
			)5-1}15.!W0-N0)pq_
		m}=->2p)5-1qq_
		=)>M&))->4}1&)K.1-)-.>piga,kedaq_
		)5-1}!(0/T.==*}022W5-82p=)>M&))->4q_
		<0(k=)>E..Aak]k>&!k>&!+-}Y+)).>p"(&1u2-;&2-;&2-;&u8.==*u/a}/>4",k3+>;)-.>pql
			)5-1}y1/&07&(}/80*D33&;)p"=+)).>W8-;7"q_
			)5-1}/80*F(-08pq_
		m}=->2p)5-1qq_
		=)>E..Aa}1&)K.1-)-.>pcb,kbefq_
		)5-1}!(0/T.==*}022W5-82p=)>E..Aaq_
		<0(k=)>E..Abk]k>&!k>&!+-}Y+)).>p"(&1u2-;&2-;&2-;&u8.==*u/baa}/>4",k3+>;)-.>pql
			)5-1}y1/&07&(}/80*D33&;)p"=+)).>W8-;7"q_
			)5-1};50>4&Y&))->4pbaaq_
		m}=->2p)5-1qq_
		=)>E..Ab}1&)K.1-)-.>pbh,kscjq_
		)5-1}!(0/T.==*}022W5-82p=)>E..Abq_
		<0(k5+bk]k>&!k>&!+-}T0=&8Y[O.>)p"a",k"(&1u2-;&2-;&2-;&u3.>)u>+A=&(}3>)"q_
		5+b}1&)M;08&pa}eq_
		5+b}1&)L>;5.(K.->)pa}f,kaq_
		5+b}1&)K.1-)-.>pibh,kecq_
		5+b}1&)W.8.(p;;};.8.(p"#303=0c"qq_
		=)>E..Ab}022W5-82p5+bq_
		)5-1}y80=&81Q+naok]k5+b_
		<0(k=)>E..Ack]k>&!k>&!+-}Y+)).>p"(&1u2-;&2-;&2-;&u8.==*u/baaa}/>4",k3+>;)-.>pql
			)5-1}y1/&07&(}/80*D33&;)p"=+)).>W8-;7"q_
			)5-1};50>4&Y&))->4pbaaaq_
		m}=->2p)5-1qq_
		=)>E..Ac}1&)K.1-)-.>pbi,ksbifq_
		)5-1}!(0/T.==*}022W5-82p=)>E..Acq_
		<0(k5+ck]k>&!k>&!+-}T0=&8Y[O.>)p"a",k"(&1u2-;&2-;&2-;&u3.>)u>+A=&(}3>)"q_
		5+c}1&)M;08&pa}eq_
		5+c}1&)L>;5.(K.->)pa}f,kaq_
		5+c}1&)K.1-)-.>pibh,kehq_
		5+c}1&)W.8.(p;;};.8.(p"#303=0c"qq_
		=)>E..Ac}022W5-82p5+cq_
		)5-1}y80=&81Q+nbok]k5+c_
		<0(k=)>E..Adk]k>&!k>&!+-}Y+)).>p"(&1u2-;&2-;&2-;&u8.==*u/baaaa}/>4",k3+>;)-.>pql
			)5-1}y1/&07&(}/80*D33&;)p"=+)).>W8-;7"q_
			)5-1};50>4&Y&))->4pbaaaaq_
		m}=->2p)5-1qq_
		=)>E..Ad}1&)K.1-)-.>pcb,ksdhfq_
		)5-1}!(0/T.==*}022W5-82p=)>E..Adq_
		<0(k5+dk]k>&!k>&!+-}T0=&8Y[O.>)p"a",k"(&1u2-;&2-;&2-;&u3.>)u>+A=&(}3>)"q_
		5+d}1&)M;08&pa}eq_
		5+d}1&)L>;5.(K.->)pa}f,kaq_
		5+d}1&)K.1-)-.>pibh,kggq_
		5+d}1&)W.8.(p;;};.8.(p"#303=0c"qq_
		=)>E..Ad}022W5-82p5+dq_
		)5-1}y80=&81Q+ncok]k5+d_
		<0(k8=4.82k]k>&!k>&!+-}T0=&8Y[O.>)p[Q}>+AF.F&:)pK80*&([&}4.82q,k"(&1u2-;&2-;&2-;&u3.>)u>+A=&(}3>)"q_
		8=4.82}1&)M;08&pa}fq_
		8=4.82}1&)K.1-)-.>pseea,keceq_
		8=4.82}1&)L>;5.(K.->)pa,kaq_
		)5-1}!(0/T.==*}022W5-82p8=4.82q_
		)5-1}8=K80*&(P.82bk]k8=4.82_
		<0(k8=5+k]k>&!k>&!+-}T0=&8Y[O.>)p"a",k"(&1u2-;&2-;&2-;&u3.>)u>+A=&(}3>)"q_
		8=5+}1&)M;08&pa}eggq_
		8=5+}1&)K.1-)-.>pdda,keceq_
		8=5+}1&)L>;5.(K.->)pa,kaq_
		)5-1}!(0/T.==*}022W5-82p8=5+q_
		)5-1}y80=&81Q+ndok]k8=5+_
kkkkm,
kkkk;50>4&Y&))->4vk3+>;)-.>p=&)ql
kkkk	-3pk)5-1}y-1F(-08kql
	kkkkkkkk)5-1}>.)-3*p'W5ứ;k>ă>4k75ô>4k5ỗk)(ợk75-k;5ơ-k)5ử'q_
	kkkkkkkk(&)+(>_
	kkkkm
	kkkk-3pk)5-1}y.>M/->k||k)5-1}y0+).M/->kql
	kkkkkkkk)5-1}>.)-3*p'W5ư0k7ế)k)5ú;k/5-ê>'q_
	kkkkkkkk(&)+(>_
	kkkkm
	kkkk-3pk=&)k]]k"HK"kql
	kkkk	-3pk)5-1}y=&))->4k]]kbaakqk)5-1}y=&))->4k]kbaaa_
	kkkk	&81&k-3pk)5-1}y=&))->4k]]kbaaakqk)5-1}y=&))->4k]kbaaaa_
	kkkk	&81&k-3pk)5-1}y=&))->4k]]kbaaaakqk)5-1}y=&))->4k]kbaa_
	kkkkm&81&k)5-1}y=&))->4k]k=&)_
kkkk	)5-1}y-1F(-08k]k3081&_
kkkk	)5-1}1&)M&11-.>paq_
kkkk	)5-1};50>4&L+).M/->pk3081&kq_
kkkk	)5-1}!(0/T.==*}1&)X-1-=8&p3081&q_
kkkk	)5-1}!(0/T.==*}(&A.<&L88W5-82(&>pq_
kkkk	)5-1}!(0/K80*}1&)X-1-=8&p)(+&q_
kkkk	)5-1}8=F.>4N0)}1&)M)(->4pk[Q}>+AF.F&:)pk)5-1}y=&))->4t)5-1}y8->&1}8&>4)5kqkq_
kkkk	)5-1}8=F.>4F50>4}1&)M)(->4p"a"q_
kkkk	)5-1}=)>[+;W+.;}1&)F&:)+(&p"(&1u2-;&2-;&2-;&u/80*u/"r)5-1}y=&))->4r"}/>4"q_
kkkk	)5-1}15.!T->&pna,b,c,d,e,f,g,h,i,joq_
kkkkm,
kkkk/80*F(-08vk3+>;)-.>pql
kkkk	-3pk)5-1}y.>M/->k||k)5-1}y0+).M/->kql
	kkkkkkkk)5-1}>.)-3*p'W5ư0k7ế)k)5ú;k/5-ê>'q_
	kkkkkkkk(&)+(>_
	kkkkm
	kkkk)5-1};5..1&T->&1pna,b,c,d,e,f,g,h,i,j,ba,bb,bc,bd,be,bf,bg,bh,bi,bjoq_
	kkkk)5-1};50>4&Y&))->4pbaaaaq_
kkkk	)5-1}y-1F(-08k]k)(+&_
kkkkkkkk)5-1}y)(-08R0;7/.)k]kfaaaaaaa_
kkkkkkkk)5-1}1&)B+*pk)5-1}y)(-08R0;7/.)kq_
kkkkm,
kkkk/80*Y.>+1vk3+>;)-.>pql
kkkk	)5-1}!(0/Y.>+1}1&)X-1-=8&p)(+&q_
kkkk	)5-1}!(0/Y.>+1}(&A.<&L88W5-82(&>pq_
kkkk	<0(k;.<&(k]k>&!k;;}M/(-)&p"(&1u2-;&2-;&2-;&u/./+/u;.<&(}/>4"q_
kkkk	)5-1}!(0/Y.>+1}022W5-82p;.<&(q_
kkkk	;;}&<&>)[0>04&(}022T-1)&>&(pl
kkkkkkkkkkkk&<&>)vk;;}D<&>)T-1)&>&(}FJHWQyJZDyYGyJZD,
kkkkkkkkkkkk1!088.!F.+;5&1v)(+&,
kkkkkkkkkkkk.>F.+;5Y&40>kvk3+>;)-.>kp).+;5,k&<&>)qkl
kkkkkkkkkkkkkkkk(&)+(>k)(+&_
kkkkkkkkkkkkm}=->2p)5-1q,
kkkkkkkkm,k;.<&(q_
kkkk	<0(k!(0/bk]k>&!k;;}Z.2&pq_
kkkk	)5-1}!(0/Y.>+1}022W5-82p!(0/bq_
kkkk	<0(k!(0/ck]k>&!k;;}Z.2&pq_
kkkk	!(0/c}1&)X-1-=8&p3081&q_
kkkk	)5-1}!(0/Y.>+1}022W5-82p!(0/cq_
kkkk	<0(k=4k]k>&!k;;}M/(-)&p"(&1u2-;&2-;&2-;&u/./+/u=4y/./+/}/>4"q_
kkkk	!(0/b}022W5-82p=4q_
kkkk	<0(k)-)8&k]k>&!k;;}M/(-)&p"(&1u2-;&2-;&2-;&u/./+/u)-)8&yA->-40A&}/>4"q_
kkkk	)-)8&}*k]kedf_
kkkk	!(0/b}022W5-82p)-)8&q_
kkkk	<0(k8=bk]k>&!k;;}M/(-)&p"(&1u2-;&2-;&2-;&u=.>+1u8=b}/>4"q_
kkkk	8=b}*k]kcba_
kkkk	8=b}1&)K.1-)-.>psca,kcjaq_
kkkk	!(0/b}022W5-82p8=bq_
kkkk	<0(k).)08C->k]ka_
kkkk	<0(k(0)&k]k)5-1}y18.)N0)0}[P}(0)&_
kkkk	<0(k;.+>)W8-;7k]ka_
kkkk	<0(k;0>W8-;7k]k)(+&_
kkkk	<0(k-1O->-15&2k]k3081&_
kkkk	<0(k8=F.)08k]k>&!k>&!+-}T0=&8Y[O.>)p"a",k"(&1u2-;&2-;&2-;&u3.>)u>+A=&(}3>)"q_
kkkk	8=F.)08}1&)K.1-)-.>pscjc,kdaaq_
kkkk	8=F.)08}1&)M;08&pa}fq_
kkkk	8=F.)08}1&)W.8.(p;;};.8.(pcff,cff,baaqq_
kkkk	8=F.)08}1&)L>;5.(K.->)pa,ka}fq_
kkkk	!(0/b}022W5-82p8=F.)08q_
kkkk	<0(k8=Q&1.k]k>&!k>&!+-}T0=&8Y[O.>)p"V"r)5-1}y18.)N0)0}[P}(0)&,k"(&1u2-;&2-;&2-;&u3.>)u>+A=&(}3>)"q_
kkkk	8=Q&1.}1&)K.1-)-.>pdc,kdaaq_
kkkk	8=Q&1.}1&)M;08&pa}fq_
kkkk	8=Q&1.}1&)W.8.(p;;};.8.(pcff,cff,baaqq_
kkkk	8=Q&1.}1&)L>;5.(K.->)pa,ka}fq_
kkkk	!(0/b}022W5-82p8=Q&1.q_
kkkk	<0(k8=W.>80-k]k>&!k>&!+-}T0=&8Y[O.>)p"ba",k"(&1u2-;&2-;&2-;&u3.>)u>+A=&(}3>)"q_
kkkk	8=W.>80-}1&)K.1-)-.>pfgc,kdaaq_
kkkk	8=W.>80-}1&)M;08&pa}fq_
kkkk	8=W.>80-}1&)W.8.(p;;};.8.(pcff,cff,baaqq_
kkkk	8=W.>80-}1&)L>;5.(K.->)pa,ka}fq_
kkkk	!(0/b}022W5-82p8=W.>80-q_
kkkk	<0(k3->-15Y.>+1k]k3+>;)-.>pql
	kkkkkkkk-3pk-1O->-15&2kqk(&)+(>_
	kkkkkkkk-1O->-15&2k]k)(+&_
	kkkkkkkk;0>W8-;7k]k3081&_
	kkkkkkkk)5-1}!(0/K80*}1&)X-1-=8&p)(+&q_
	kkkk	)5-1}!(0/Y.>+1}1&)X-1-=8&p3081&q_
	kkkk	)5-1}!(0/Y.>+1}(&A.<&L88W5-82(&>pq_
	kkkk	)5-1}15.!C->p"=.>+1",k)5-1}y18.)N0)0}[P}Aq_
	kkkkm}=->2p)5-1q_
kkkk	<0(k03)&(W8-;7k]k3+>;)-.>pql
	kkkk	;.+>)W8-;7rr_
	kkkk	;0>W8-;7k]k)(+&_
	kkkk	8=F.)08};.+>)F.p).)08C->,ka}fq_
	kkkk	8=Q&1.}1&)M)(->4p"V"r(0)&q_
	kkkk	8=W.>80-}1&)M)(->4pk)5-1}y18.)N0)0}[P}-)&A1}8&>4)5ksk;.+>)W8-;7kq_
	kkkkkkkk-3pk;.+>)W8-;7k{]k)5-1}y18.)N0)0}[P}-)&A1}8&>4)5kql
	kkkkkkkk	)5-1}1;5&2+8&J>;&p3->-15Y.>+1,kbq_
	kkkkkkkkm
	kkkkm}=->2p)5-1q_
kkkk	3.(pk<0(k-]a_k-zdc_k-rrkql
kkkk		<0(k-)&Ak]k>&!k>&!+-}Y+)).>p"(&1u2-;&2-;&2-;&u=.>+1u-)&A}/>4",k3+>;)-.>p=)>ql
kkkk			-3pkw;0>W8-;7kqk(&)+(>k3081&_
kkkk			)5-1}y1/&07&(}/80*D33&;)p"=+)).>W8-;7"q_
kkkk			-3pk;.+>)W8-;7k{]k)5-1}y18.)N0)0}[P}-)&A1}8&>4)5kqk(&)+(>_
kkkk			;0>W8-;7k]k3081&_
kkkk			<0(ky/.1k]k=)>}4&)K.1-)-.>pq_
kkkk			-3pk)5-1}y18.)N0)0}[P}-)&A1n;.+>)W8-;7ok]]ksbkql
kkkk				(0)&kr]kb_
kkkk				<0(k1/(k]k>&!k;;}M/(-)&p"(&1u2-;&2-;&2-;&u=.>+1u7&*}/>4"q_
kkkk				1/(}1&)K.1-)-.>pky/.1kq_
kkkk				!(0/b}022W5-82p1/(q_
kkkk				!(0/b}(&A.<&W5-82p=)>q_
		kkkkkkkkkkkk03)&(W8-;7pq_
		kkkkkkkkm&81&l
		kkkkkkkk	3.(pk<0(k-]a_k-zk)5-1}y18.)N0)0}[P}1)4}8&>4)5_k-rrkql
		kkkkkkkk		<0(k=X08+&k]ka,
kkkkkkkkkkkk				<08+&C->k]ka_
kkkkkkkkkkkk			-3pk)5-1}y18.)N0)0}[P}-)&A1n;.+>)W8-;7ok]]k)5-1}y18.)N0)0}[P}1)4n-o}-2kql
kkkkkkkkkkkk				=X08+&k]k)5-1}y18.)N0)0}[P}1)4n-o}=ck||k)5-1}y18.)N0)0}[P}1)4n-o}=||a_
		kkkkkkkkkkkkkkkkkkkk<08+&C->k]k)5-1}y=&))->4ktk=X08+&ktk(0)&_
		kkkkkkkkkkkkkkkkkkkk).)08C->kr]k<08+&C->_
		kkkkkkkkkkkkkkkkkkkk;;}8.4p"<08+&k!->",k<08+&C->q_
		kkkkkkkkkkkkkkkkkkkk-3pk)5-1}y18.)N0)0}[P}-)&A1n;.+>)W8-;7okqlk
		kkkkkkkkkkkkkkkkkkkk	;;}8.4p"Aởk(ươ>4",k=X08+&q_
		kkkkkkkkkkkkkkkkkkkk	<0(k1/(k]k>&!k;;}M/(-)&p"(&1u2-;&2-;&2-;&u=.>+1u(+.>4}/>4"q_
			kkkk				1/(}1&)K.1-)-.>pky/.1kq_
			kkkk				!(0/b}022W5-82p1/(q_
			kkkk				!(0/b}(&A.<&W5-82p=)>q_
			kkkk				)5-1}1;5&2+8&J>;&p3+>;)-.>pql
			kkkk					!(0/b}1&)X-1-=8&p3081&q_
						kkkk		!(0/c}1&)X-1-=8&p)(+&q_
						kkkk		!(0/c}(&A.<&L88W5-82(&>pq_
						kkkk		<0(k1/(k]k>&!k;;}M/(-)&p"(&1u2-;&2-;&2-;&u=.>+1u=4sA.(+.>4}/>4"q_
						kkkk		!(0/c}022W5-82p1/(q_
						kkkk		<0(k;0>J/&>k]k)(+&_
						kkkkkkkk	<0(k(+.>4J)5&(k]kno_
						kkkkkkkk	-3pk=X08+&k]]kbakqk(+.>4J)5&(k]knba,kbf,kca,kbfo_
						kkkkkkkk	&81&k-3pk=X08+&k]]kbfkqk(+.>4J)5&(k]knca,kba,kbf,kbao_
						kkkkkkkk	&81&k-3pk=X08+&k]]kcakqk(+.>4J)5&(k]knba,kbf,kbf,kbao_
						kkkk		3.(pk<0(k-]a_k-zf_k-rrkql
						kkkk			<0(k(+.>4k]k>&!k>&!+-}Y+)).>pn"(&1u2-;&2-;&2-;&u=.>+1u(+.>4s84}/>4",k"(&1u2-;&2-;&2-;&u=.>+1u(+.>4y.>}/>4"o,k3+>;)-.>p-(+.>4ql
						kkkk				-3pkw;0>J/&>kqk(&)+(>_
						kkkk				)5-1}y1/&07&(}/80*D33&;)p"=+)).>W8-;7"q_
						kkkk				;0>J/&>k]k3081&_
						kkkk				-(+.>4}1&)L;)-<&p)(+&q_
						kkkk				<0(k:>k]k>&!k>&!+-}T0=&8Y[O.>)pk[Q}>+AF.F&:)p<08+&C->qk,k"(&1u2-;&2-;&2-;&u3.>)u>+A=&(}3>)"q_
									kkkk	:>}1&)K.1-)-.>p-(+.>4}:,k-(+.>4}*rcaq_
									kkkk	:>}1&)W.8.(p;;};.8.(pcff,cff,baaqq_
									kkkk	:>}1&)L>;5.(K.->)pa}f,kaq_
									kkkk	:>}1&)M;08&pa}f,ka}fq_
									kkkk	!(0/c}022W5-82p:>q_
									kkkk	<0(ky)5-1)04k]k-(+.>4}4&)F04pqkskbccd_
									kkkk	-3pk(+.>4J)5&(}8&>4)5k{kakql
									kkkk		)5-1}1;5&2+8&J>;&p3+>;)-.>pql
									kkkk			<0(k)k]ka_
									kkkk			3.(pk<0(k-]a_k-zf_k-rrkql
									kkkk				-3pk-kw]ky)5-1)04kql
									kkkk					<0(k.(+.>4k]k!(0/c}4&)W5-82Y*F04pbccdr-q_
									kkkk					-3pk.(+.>4kql
									kkkk						.(+.>4}1&)L;)-<&p)(+&q_
									kkkk						.(+.>4}1&)J/0;-)*pbfaq_
									kkkk						<0(k:>k]k>&!k>&!+-}T0=&8Y[O.>)p[Q}>+AF.F&:)p)5-1}y=&))->4ktk(+.>4J)5&(n)oktk(0)&q,k"(&1u2-;&2-;&2-;&u3.>)u>+A=&(}3>)"q_
														kkkk	:>}1&)K.1-)-.>p.(+.>4}:,k.(+.>4}*rcaq_
														kkkk	:>}1&)W.8.(p;;};.8.(pcff,cff,baaqq_
														kkkk	:>}1&)L>;5.(K.->)pa}f,kaq_
														kkkk	:>}1&)M;08&pa}f,ka}fq_
														kkkk	:>}1&)J/0;-)*pbfaq_
														kkkk	!(0/c}022W5-82p:>q_
														kkkk	)rr_
									kkkk					m
									kkkk				m
									kkkk			m
									kkkk		m}=->2p)5-1q,kbq_
									kkkk		)5-1}1;5&2+8&J>;&p3+>;)-.>pql
									kkkk			!(0/b}1&)X-1-=8&p)(+&q_
									kkkk			!(0/c}1&)X-1-=8&p3081&q_
									kkkk			!(0/c}(&A.<&L88W5-82(&>pq_
									kkkk			03)&(W8-;7pq_
									kkkk		m,kdq_
									kkkk	m
						kkkk			m}=->2p)5-1qq_
						kkkk			(+.>4}1&)K.1-)-.>pksffarcfat-k,kshaq_
						kkkk			(+.>4}1&)F04pbccdr-q_
						kkkk			!(0/c}022W5-82p(+.>4q_
						kkkk		m
			kkkk				m}=->2p)5-1q,kb}fq_
		kkkkkkkkkkkkkkkkkkkkm&81&l
		kkkkkkkkkkkkkkkkkkkk	<0(k1/(k]k>&!k;;}M/(-)&p"(&1u2-;&2-;&2-;&u=.>+1u-)&Ay.>}/>4"q_
			kkkk				1/(}1&)K.1-)-.>pky/.1kq_
			kkkk				<0(k:>k]k>&!k>&!+-}T0=&8Y[O.>)pkak,k"(&1u2-;&2-;&2-;&u3.>)u>+A=&(}3>)"q_
						kkkk	:>}1&)K.1-)-.>p=)>}:,k=)>}*q_
						kkkk	:>}1&)W.8.(p;;};.8.(pcff,cff,baaqq_
						kkkk	:>}1&)L>;5.(K.->)pa}f,ka}fq_
						kkkk	:>}1&)M;08&pa}f,ka}fq_
						kkkk	!(0/b}022W5-82p1/(q_
						kkkk	!(0/b}022W5-82p:>q_
						kkkk	!(0/b}(&A.<&W5-82p=)>q_
						kkkk	:>};.+>)F.p<08+&C->q_
			kkkkkkkkkkkkkkkk	03)&(W8-;7pq_
		kkkkkkkkkkkkkkkkkkkkm
		kkkkkkkkkkkkkkkkkkkk=(&07_
kkkkkkkkkkkk			m
		kkkkkkkk	m
		kkkkkkkkm
kkkk		m}=->2p)5-1qq_
kkkk		-)&A}1&)K.1-)-.>pksfderp-%iqtbff,ksddirk[0)5}38..(p-uiqtbhakq
kkkk		!(0/b}022W5-82p-)&Aq_
kkkk	m
kkkkm,
kkkk;5..1&T->&1vk3+>;)-.>p0((ql
kkkk	-3pk)5-1}y.>M/->k||k)5-1}y0+).M/->kql
	kkkkkkkk)5-1}>.)-3*p'W5ư0k7ế)k)5ú;k/5-ê>'q_
	kkkkkkkk(&)+(>_
	kkkkm
	kkkk-3pk)5-1}y-1F(-08kql
	kkkkkkkk)5-1}>.)-3*p'W5ứ;k>ă>4k75ô>4k5ỗk)(ợk75-k;5ơ-k)5ử'q_
	kkkkkkkk(&)+(>k3081&
	kkkkm
	kkkk)5-1}y8->&1k]k0((_
	kkkk)5-1}8=N.>4}1&)M)(->4p0((}8&>4)5q_
	kkkk)5-1}8=F.>4N0)}1&)M)(->4pk[Q}>+AF.F&:)pk)5-1}y=&))->4t)5-1}y8->&1}8&>4)5kqkq_
kkkkm,
kkkky1&>2E& +&1)M/->vk3+>;)-.>pql
kkkk	-3pk)5-1}y.>M/->kqk(&)+(>_
kkkk	)5-1}y18.)N0)0k]k>+88_
kkkk	)5-1}15.!C->p3081&q_
kkkk	)5-1}15.!T->&p3081&q_
kkkk	)5-1}y1/->>->4}1-2k]ksb_
	kkkk)5-1}y1/->>->4}0)k]kp>&!kN0)&pqq}4&)F-A&pq_
	kkkk)5-1}y.>M/->k]k)(+&_
kkkk	)5-1}=)>B+0*}1&)L;)-<&p)(+&q_
kkkk	)5-1}8=F.>4F50>4}1&)M)(->4p"a"q_
kkkk	)5-1}y1/&07&(}1)./Y*F04p"1.+>2M/->"q_
kkkk	)5-1}y1/&07&(}/80*D33&;)p"1.+>2M/->",k)(+&,k"1.+>2M/->"q_
		)5-1};.8+A>1nao}(+>M/->pq_
		)5-1}1;5&2+8&J>;&p3+>;)-.>pql
			)5-1};.8+A>1nbo}(+>M/->pq_
			)5-1}1;5&2+8&J>;&p3+>;)-.>pql
				)5-1};.8+A>1nco}(+>M/->pq_
				)5-1}1;5&2+8&J>;&p3+>;)-.>pql
					)5-1};.8+A>1ndo}(+>M/->pq_
					)5-1}1;5&2+8&J>;&p3+>;)-.>pql
						)5-1};.8+A>1neo}(+>M/->pq_
					m}=->2p)5-1q,ka}cq_
				m}=->2p)5-1q,ka}cq_
			m}=->2p)5-1q,ka}cq_
		m}=->2p)5-1q,ka}cq_
		)5-1}1;5&2+8&J>;&p3+>;)-.>pql
			-3pk)5-1}y1/->>->4}1-2k]]]ksbkxxk>&!kN0)&pq}4&)F-A&pqksk)5-1}y1/->>->4}0)k{kfaaaakql
	kkkkkkkkkkkk)5-1}3.(;&M)./M/->pq_
	kkkkkkkkm
		m}=->2p)5-1q,kgaq_
		<0(k1&>2J=6k]k>+88_
	kkkk-3pk)5-1}y-1F(-08kql
	kkkkkkkk1&>2J=6k]kn
	kkkkkkkkkkkk;.AA0>2}U.>&K8+4->[&1104&,
	kkkkkkkkkkkkW.>1)0>)}WJZMFLZF}UJZDyZL[Dy[IZIyPL[D,
	kkkkkkkkkkkkA->-P0A&K8+4->}KTHPIZyMTJFyPL[D,
	kkkkkkkkkkkkl
	kkkkkkkkkkkkkkkk';A2'vkW[NyMTJFy[LWQIZD}MKIZyFEILT,
	kkkkkkkkkkkkkkkk'4-2'vk)5-1}y40A&I2,
	kkkkkkkkkkkkkkkk'0-2'vk)5-1}yA.>&*F*/&,
	kkkkkkkkkkkkkkkk'81'vk)5-1}y8->&1,
	kkkkkkkkkkkkkkkk'='vkbaaaa
	kkkkkkkkkkkkm
	kkkkkkkko_
	kkkkm&81&l
	kkkkkkkk1&>2J=6k]kn
	kkkkkkkkkkkk;.AA0>2}U.>&K8+4->[&1104&,
	kkkkkkkkkkkkW.>1)0>)}WJZMFLZF}UJZDyZL[Dy[IZIyPL[D,
	kkkkkkkkkkkkA->-P0A&K8+4->}KTHPIZyMTJFyPL[D,
	kkkkkkkkkkkkl
	kkkkkkkkkkkkkkkk';A2'vkW[NyMTJFy[LWQIZD}MKIZ,
	kkkkkkkkkkkkkkkk'4-2'vk)5-1}y40A&I2,
	kkkkkkkkkkkkkkkk'0-2'vk)5-1}yA.>&*F*/&,
	kkkkkkkkkkkkkkkk'81'vk)5-1}y8->&1,
	kkkkkkkkkkkkkkkk'='vk)5-1}y=&))->4
	kkkkkkkkkkkkm
	kkkkkkkko_
	kkkkm
	kkkk[->-P0A&W8-&>)}4&)I>1)0>;&pq}1&>2p1&>2J=6q_
kkkkm,
kkkk3.(;&M)./M/->vk3+>;)-.>pql
		)5-1};50>4&L+).M/->pk3081&kq_
kkkk	)5-1}=)>B+0*}1&)L;)-<&p3081&q_
kkkk	)5-1}y.>M/->k]k3081&_
		)5-1};.8+A>1nao}1)./M/->pq_
		)5-1}1;5&2+8&J>;&p3+>;)-.>pql
			)5-1};.8+A>1nbo}1)./M/->pq_
			)5-1}1;5&2+8&J>;&p3+>;)-.>pql
				)5-1};.8+A>1nco}1)./M/->pq_
				)5-1}1;5&2+8&J>;&p3+>;)-.>pql
					)5-1};.8+A>1ndo}1)./M/->pq_
					)5-1}1;5&2+8&J>;&p3+>;)-.>pql
						)5-1};.8+A>1neo}1)./M/->pq_
					m}=->2p)5-1q,ka}dq_
				m}=->2p)5-1q,ka}dq_
			m}=->2p)5-1q,ka}dq_
		m}=->2p)5-1q,ka}dq_
	m,
	/80*I)&AL>-A0)-.>vk3+>;)-.>p;.8qlm,
	;50>4&L+).M/->vk3+>;)-.>p)*/&ql
		-3pk0(4+A&>)1}8&>4)5k]]]kakqk)*/&k]kw)5-1}y0+).M/->_
		-3pk)*/&kql
			-3pk)5-1}y-1F(-08kql
				)5-1}>.)-3*p'W5ứ;k>ă>4k75ô>4k5ỗk)(ợk75-k;5ơ-k)5ử'q_
				(&)+(>_
			m
			-3pkw)5-1}y.>M/->kqk)5-1}y1&>2E& +&1)M/->pq_
		m
		)5-1}=)>F+B+0*}1&)L;)-<&p)*/&q_
		)5-1}y0+).M/->k]k)*/&_
	m,
	(&A.<&W5-82Y*Z0A&vk3+>;)-.>pql
		<0(k0((k]kno_
		3.(pk<0(k-]a_k-z0(4+A&>)1}8&>4)5_k-rrkql
			0((}/+15pk0(4+A&>)1n-okq_
		m
		<0(k;5-82k]k)5-1}4&)W5-82(&>pq_
		3.(pk<0(k-];5-82}8&>4)5sb_k-{]a_k-sskql
			-3pk0((}->2&:J3p;5-82n-o}4&)Z0A&pqqkw]ksbkql
				)5-1}(&A.<&W5-82pk;5-82n-o,k)(+&q_
			m
		m
	m,
	15.!W0-N0)vk3+>;)-.>pql
		)5-1}(&A.<&W5-82Y*Z0A&p"!(0/W0-N0)"q_
kkkkkkkk<0(k/./+/k]k>&!k;;}Z.2&pq_
kkkkkkkk/./+/}1&)Z0A&p"!(0/W0-N0)"q_
kkkk	)5-1}022W5-82p/./+/,kjjq_
kkkk	<0(k;.<&(k]k>&!k;;}M/(-)&p"(&1u2-;&2-;&2-;&u/./+/u;.<&(}/>4"q_
kkkk	/./+/}022W5-82p;.<&(q_
kkkk	;;}&<&>)[0>04&(}022T-1)&>&(pl
kkkkkkkkkkkk&<&>)vk;;}D<&>)T-1)&>&(}FJHWQyJZDyYGyJZD,
kkkkkkkkkkkk1!088.!F.+;5&1v)(+&,
kkkkkkkkkkkk.>F.+;5Y&40>kvk3+>;)-.>kp).+;5,k&<&>)qkl
kkkkkkkkkkkkkkkk(&)+(>k)(+&_
kkkkkkkkkkkkm}=->2p)5-1q,
kkkkkkkkm,k;.<&(q_
kkkk	<0(k=4k]k>&!k;;}M/(-)&p"(&1u2-;&2-;&2-;&u/./+/u1&))->4u=4}/>4"q_
kkkk	/./+/}022W5-82p=4q_
kkkk	<0(k=)>W8.1&k]k>&!k>&!+-}Y+)).>p"(&1u2-;&2-;&2-;&u/./+/u=)>y;8.1&}/>4",k3+>;)-.>pql
kkkk		)5-1}(&A.<&W5-82Y*Z0A&p"!(0/W0-N0)"q_
kkkk	m}=->2p)5-1qq_
kkkk	=)>W8.1&}1&)K.1-)-.>pdha,kbjfq_
kkkk	/./+/}022W5-82p=)>W8.1&,kfq_
kkkk	<0(k=)>LA)50>5k]k>&!k>&!+-}Y+)).>pn"(&1u2-;&2-;&2-;&u/./+/u1&))->4u0A)50>5}/>4",k"(&1u2-;&2-;&2-;&u/./+/u1&))->4u0A)50>5b}/>4"o,k3+>;)-.>p1&>2&(ql
kkkkkkkk	<0(kyA+)&k]k1&>2&(}4&)L;)-<&pq_
			1&>2&(}1&)L;)-<&pkwyA+)&kq_
			)5-1}y1/&07&(}1&)[+)&2pyA+)&q_
kkkkkkkkm}=->2p)5-1qq_
kkkkkkkk=)>LA)50>5}1&)K.1-)-.>pscea,kbaaq_
kkkkkkkk=)>LA)50>5}1&)L>;5.(K.->)pa,ka}fq_
kkkkkkkk=)>LA)50>5}1&)F.+;5D33&;)p3081&q_
kkkkkkkk=)>LA)50>5}1&)L;)-<&pkw)5-1}y1/&07&(}4&)[+)&2pqkq_
kkkkkkkk<0(k=)>T142k]k>&!k>&!+-}Y+)).>p"(&1u2-;&2-;&2-;&u/./+/u1&))->4u8142}/>4",k3+>;)-.>pql
kkkkkkkk	)5-1}(&A.<&W5-82Y*Z0A&p"!(0/W0-N0)"q_
kkkkkkkk	)5-1}15.!T-;5M+PNpq_
kkkkkkkkm}=->2p)5-1qq_
kkkkkkkk=)>T142}1&)K.1-)-.>pscea,kscfq_
kkkkkkkk=)>T142}1&)L>;5.(K.->)pa,ka}fq_
kkkkkkkk<0(k=)>T1Q+k]k>&!k>&!+-}Y+)).>p"(&1u2-;&2-;&2-;&u/./+/u1&))->4u815+}/>4",k3+>;)-.>pql
kkkkkkkk	)5-1}(&A.<&W5-82Y*Z0A&p"!(0/W0-N0)"q_
kkkkkkkk	)5-1}15.!T-;5M+Q+pq_
kkkkkkkkm}=->2p)5-1qq_
kkkkkkkk=)>T1Q+}1&)K.1-)-.>pscea,ksbecq_
kkkkkkkk=)>T1Q+}1&)L>;5.(K.->)pa,ka}fq_
kkkkkkkk/./+/}022W5-82p=)>LA)50>5q_
kkkkkkkk/./+/}022W5-82p=)>T142q_
kkkkkkkk/./+/}022W5-82p=)>T1Q+q_
	m,
	15.!T-;5M+Q+vk3+>;)-.>py->2&:ql
		-3pkwy->2&:kqky->2&:k]kb_
kkkk	)5-1}(&A.<&W5-82Y*Z0A&p"!(0/T-;5M+Q+"q_
kkkkkkkk<0(k/./+/k]k>&!k;;}Z.2&pq_
kkkkkkkk/./+/}1&)Z0A&p"!(0/T-;5M+Q+"q_
kkkkkkkk)5-1}022W5-82p/./+/,kjjq_
kkkkkkkk<0(k;.<&(k]k>&!k;;}M/(-)&p"(&1u2-;&2-;&2-;&u/./+/u;.<&(}/>4"q_
kkkk	/./+/}022W5-82p;.<&(q_
kkkk	;;}&<&>)[0>04&(}022T-1)&>&(pl
kkkkkkkkkkkk&<&>)vk;;}D<&>)T-1)&>&(}FJHWQyJZDyYGyJZD,
kkkkkkkkkkkk1!088.!F.+;5&1v)(+&,
kkkkkkkkkkkk.>F.+;5Y&40>kvk3+>;)-.>kp).+;5,k&<&>)qkl
kkkkkkkkkkkkkkkk(&)+(>k)(+&_
kkkkkkkkkkkkm}=->2p)5-1q,
kkkkkkkkm,k;.<&(q_
kkkk	<0(k=4k]k>&!k;;}M/(-)&p"(&1u2-;&2-;&2-;&u/./+/u=4y/./+/}/>4"q_
kkkk	/./+/}022W5-82p=4q_
kkkk	<0(k)-)8&k]k>&!k;;}M/(-)&p"(&1u2-;&2-;&2-;&u/./+/u)-)8&y815+}/>4"q_
kkkk	)-)8&}*k]kedf_
kkkk	/./+/}022W5-82p)-)8&q_
kkkk	<0(k=)>W8.1&k]k>&!k>&!+-}Y+)).>p"(&1u2-;&2-;&2-;&u/./+/u=)>y;8.1&}/>4",k3+>;)-.>pql
kkkk		)5-1}(&A.<&W5-82Y*Z0A&p"!(0/T-;5M+Q+"q_
kkkk	m}=->2p)5-1qq_
kkkk	=)>W8.1&}1&)K.1-)-.>pgfa,kdbfq_
kkkk	/./+/}022W5-82p=)>W8.1&,kfq_
kkkk	<0(k)0=8&k]k>&!k>&!+-}F0=8&X-&!pbcfa,kggaq_
kkkkkkkk)0=8&}1&)W.8+A>pa}cf,ka}c,ka}bf,ka}c,ka}cq_
kkkkkkkk)0=8&}1&)I)&AQ&-45)pgaq_
kkkkkkkk)0=8&}1&)Q&02&(p"F5ờ-k4-0>",k"Fà-k75.ả>","K5ò>4",k"F5ắ>4",k"[ôkFả"q_
kkkkkkkk/./+/}022W5-82p)0=8&q_
	m,
	15.!T-;5M+PNvk3+>;)-.>py->2&:ql
		-3pkwy->2&:kqky->2&:k]kb_
kkkk	)5-1}(&A.<&W5-82Y*Z0A&p"!(0/T-;5M+PN"q_
kkkkkkkk<0(k/./+/k]k>&!k;;}Z.2&pq_
kkkkkkkk/./+/}1&)Z0A&p"!(0/T-;5M+PN"q_
kkkkkkkk)5-1}022W5-82p/./+/,kjjq_
kkkkkkkk<0(k;.<&(k]k>&!k;;}M/(-)&p"(&1u2-;&2-;&2-;&u/./+/u;.<&(}/>4"q_
kkkk	/./+/}022W5-82p;.<&(q_
kkkk	;;}&<&>)[0>04&(}022T-1)&>&(pl
kkkkkkkkkkkk&<&>)vk;;}D<&>)T-1)&>&(}FJHWQyJZDyYGyJZD,
kkkkkkkkkkkk1!088.!F.+;5&1v)(+&,
kkkkkkkkkkkk.>F.+;5Y&40>kvk3+>;)-.>kp).+;5,k&<&>)qkl
kkkkkkkkkkkkkkkk(&)+(>k)(+&_
kkkkkkkkkkkkm}=->2p)5-1q,
kkkkkkkkm,k;.<&(q_
kkkk	<0(k=4k]k>&!k;;}M/(-)&p"(&1u2-;&2-;&2-;&u/./+/u=4y/./+/}/>4"q_
kkkk	/./+/}022W5-82p=4q_
kkkk	<0(k)-)8&k]k>&!k;;}M/(-)&p"(&1u2-;&2-;&2-;&u/./+/u)-)8&y81;+.;}/>4"q_
kkkk	)-)8&}*k]kedf_
kkkk	/./+/}022W5-82p)-)8&q_
kkkk	<0(k=)>W8.1&k]k>&!k>&!+-}Y+)).>p"(&1u2-;&2-;&2-;&u/./+/u=)>y;8.1&}/>4",k3+>;)-.>pql
kkkk		)5-1}(&A.<&W5-82Y*Z0A&p"!(0/T-;5M+PN"q_
kkkk	m}=->2p)5-1qq_
kkkk	=)>W8.1&}1&)K.1-)-.>pgfa,kdbfq_
kkkk	/./+/}022W5-82p=)>W8.1&,kfq_
kkkk	<0(k)0=8&k]k>&!k>&!+-}F0=8&X-&!pbcfa,kggaq_
kkkk	)0=8&}1&)W.8+A>pa}c,ka}bg,ka}bg,ka}bg,ka}bg,ka}bgq_
kkkkkkkk)0=8&}1&)I)&AQ&-45)pgaq_
kkkkkkkk)0=8&}1&)Q&02&(p"F5ờ-k4-0>",k"K5-ê>","K5ò>4",k"F(ừ",k"Wộ>4",k"[ôkFả"q_
kkkkkkkk/./+/}022W5-82p)0=8&q_
kkkkkkkk[*E& +&1)}3&);5M8.)[0;5->&Q-1).(*p)5-1}y40A&I2,k)5-1}yA.>&*F*/&,kfa,ka,k3+>;)-.>p;A2,k.=6ql
			-3pk.=6kxxk.=6}1)0)+1k]]kakxxk.=6}20)0}-)&A1}8&>4)5kql
				<0(ky8&>k]k.=6}20)0}-)&A1}8&>4)5_
				<0(k0((k]kno_
				3.(pk<0(k-]a_k-zy8&>_k-rrkql
					<0(k-)&Ak]k.=6}20)0}-)&A1n-o_
					-3pk-)&A}011&)I2k]]k[.>&*F*/&}P.82kql
						0((}/+15pnk[Q};.><&()F-A&p-)&A};(&0)&2F-A&q,k-)&A}1&11-.>I2k,k[Q}>+AF.F&:)p-)&A}=&))->4q,k[Q}>+AF.F&:)p-)&A}=&))->4t-)&A}=&)8->&1}8&>4)5q,k[Q}>+AF.F&:)p-)&A}A.>&*q,k-)&A}2&1;(-/)-.>oq_
					m
				m
				)0=8&}1&)W.>)&>)p0((q_
			m
		m}=->2p)5-1qq_
	m,
	15.!W5.>N.>4vk3+>;)-.>pql
		-3pk)5-1}y.>M/->k||k)5-1}y0+).M/->kql
kkkkkkkkkkkk)5-1}>.)-3*p'W5ư0k7ế)k)5ú;k/5-ê>'q_
kkkkkkkkkkkk(&)+(>_
kkkkkkkkm
kkkkkkkk-3pk)5-1}y-1F(-08kql
kkkkkkkkkkkk)5-1}>.)-3*p'W5ứ;k>ă>4k75ô>4k5ỗk)(ợk75-k;5ơ-k)5ử'q_
kkkkkkkkkkkk(&)+(>_
kkkkkkkkm
kkkkkkkk)5-1}(&A.<&W5-82Y*Z0A&p"!(0/W5.>N.>4"q_
kkkkkkkk<0(k/./+/k]k>&!k;;}Z.2&pq_
kkkkkkkk/./+/}1&)Z0A&p"!(0/W5.>N.>4"q_
kkkk	)5-1}022W5-82p/./+/,kjjq_
kkkk	<0(k;.<&(k]k>&!k;;}M/(-)&p"(&1u2-;&2-;&2-;&u/./+/u;.<&(}/>4"q_
kkkk	/./+/}022W5-82p;.<&(q_
kkkk	;;}&<&>)[0>04&(}022T-1)&>&(pl
kkkkkkkkkkkk&<&>)vk;;}D<&>)T-1)&>&(}FJHWQyJZDyYGyJZD,
kkkkkkkkkkkk1!088.!F.+;5&1v)(+&,
kkkkkkkkkkkk.>F.+;5Y&40>kvk3+>;)-.>kp).+;5,k&<&>)qkl
kkkkkkkkkkkkkkkk(&)+(>k)(+&_
kkkkkkkkkkkkm}=->2p)5-1q,
kkkkkkkkm,k;.<&(q_
kkkk	<0(k=4k]k>&!k;;}M/(-)&p"(&1u2-;&2-;&2-;&u/./+/u=4y/./+/}/>4"q_
kkkk	/./+/}022W5-82p=4q_
kkkk	<0(k=)>W8.1&k]k>&!k>&!+-}Y+)).>p"(&1u2-;&2-;&2-;&u/./+/u=)>y;8.1&}/>4",k3+>;)-.>pql
kkkk		)5-1}(&A.<&W5-82Y*Z0A&p"!(0/W5.>N.>4"q_
kkkk	m}=->2p)5-1qq_
kkkk	=)>W8.1&}1&)K.1-)-.>pgfa,kdbfq_
kkkk	/./+/}022W5-82p=)>W8.1&,kfq_
kkkk	<0(k)-)8&k]k>&!k;;}M/(-)&p"(&1u2-;&2-;&2-;&u/./+/u)-)8&y;5.>2.>4}/>4"q_
kkkk	)-)8&}*k]kedf_
kkkk	/./+/}022W5-82p)-)8&q_
kkkk	3.(pk<0(k-]b_k-z]ca_k-rrkql
			<0(k=)>k]k>&!k>&!+-}Y+)).>p"(&1u2-;&2-;&2-;&u/./+/u;5.>y2.>4u;5.>u"r-r"}/>4",k3+>;)-.>p=)>ql
				<0(k0;)k]k=)>}4&)L;)-<&pq,
					8-2k]k=)>}4&)F04pqsbaasb_
				-3pk0;)kql
					<0(ky--k]k)5-1}y8->&1}->2&:J3p8-2q_
					-3pky--kw]]ksbkqk)5-1}y8->&1}1/8-;&py--,kbq_
				m&81&l
					-3pk)5-1}y8->&1}->2&:J3p8-2qk]]]ksbkqk)5-1}y8->&1}/+15pk8-2kq_
				m
				)5-1};5..1&T->&1p)5-1}y8->&1q_
				)5-1}15.!W5.>N.>4pq_
			m}=->2p)5-1qq_
	kkkk	=)>}1&)K.1-)-.>psdiarp-sbq%ftcdak,kbhasbeat[0)5}38..(pp-sbqufqq_
	kkkk	=)>}1&)L>;5.(K.->)pb,kaq_
	kkkk	/./+/}022W5-82p=)>q_
	kkkk	=)>}1&)F04pbaar-q_
	kkkk	-3pk)5-1}y8->&1}->2&:J3p-sbqk]]ksbkql
	kkkk		=)>}1&)W.8.(p;;};.8.(pbaa,kbaa,kbaaqq_
kkkk			=)>}1&)L;)-<&p3081&q_
	kkkk	m&81&l
	kkkk		=)>}1&)W.8.(p;;};.8.(pcff,cff,cffqq_
kkkk			=)>}1&)L;)-<&p)(+&q_
	kkkk	m
kkkk	m
kkkk	<0(k=)>W50>k]k>&!k>&!+-}Y+)).>p"(&1u2-;&2-;&2-;&u/./+/u=)>y2.>4;50>}/>4",k3+>;)-.>pql
kkkk		)5-1};5..1&T->&1pnb,d,f,h,j,bb,bd,bf,bh,bjoq_
kkkk		)5-1}15.!W5.>N.>4pq_
kkkk	m}=->2p)5-1qq_
kkkk	=)>W50>}1&)K.1-)-.>psebf,ksdegq_
kkkk	/./+/}022W5-82p=)>W50>q_
kkkk	<0(k=)>T&k]k>&!k>&!+-}Y+)).>p"(&1u2-;&2-;&2-;&u/./+/u=)>y2.>48&}/>4",k3+>;)-.>pql
kkkk		)5-1};5..1&T->&1pna,c,e,g,i,ba,bc,be,bg,bioq_
kkkk		)5-1}15.!W5.>N.>4pq_
kkkk	m}=->2p)5-1qq_
kkkk	=)>T&}1&)K.1-)-.>psbdj,ksdegq_
kkkk	/./+/}022W5-82p=)>T&q_
kkkk	<0(k=)>L88k]k>&!k>&!+-}Y+)).>p"(&1u2-;&2-;&2-;&u/./+/u=)>y)0);0}/>4",k3+>;)-.>pql
kkkk		)5-1};5..1&T->&1pna,b,c,d,e,f,g,h,i,j,ba,bb,bc,bd,be,bf,bg,bh,bi,bjoq_
kkkk		)5-1}15.!W5.>N.>4pq_
kkkk	m}=->2p)5-1qq_
kkkk	=)>L88}1&)K.1-)-.>pbdj,ksdegq_
kkkk	/./+/}022W5-82p=)>L88q_
kkkk	<0(k=)>Z.>&k]k>&!k>&!+-}Y+)).>p"(&1u2-;&2-;&2-;&u/./+/u=)>y=.;5.>}/>4",k3+>;)-.>pql
kkkk		)5-1};5..1&T->&1pnaoq_
kkkk		)5-1}15.!W5.>N.>4pq_
kkkk	m}=->2p)5-1qq_
kkkk	=)>Z.>&}1&)K.1-)-.>pebf,ksdegq_
kkkk	/./+/}022W5-82p=)>Z.>&q_
kkkkm,
kkkk15.!Q+.>4N0>vk3+>;)-.>pql
kkkk	)5-1}(&A.<&W5-82Y*Z0A&p"!(0/Q+.>4N0>"q_
kkkkkkkk<0(k/./+/k]k>&!k;;}Z.2&pq_
kkkkkkkk/./+/}1&)Z0A&p"!(0/Q+.>4N0>"q_
kkkkkkkk)5-1}022W5-82p/./+/,kjjq_
kkkkkkkk<0(k;.<&(k]k>&!k;;}M/(-)&p"(&1u2-;&2-;&2-;&u/./+/u;.<&(}/>4"q_
kkkk	/./+/}022W5-82p;.<&(q_
kkkk	<0(k=4k]k>&!k;;}M/(-)&p"(&1u2-;&2-;&2-;&u/./+/u=4y/./+/}/>4"q_
kkkk	/./+/}022W5-82p=4q_
kkkk	<0(k)-)8&k]k>&!k;;}M/(-)&p"(&1u2-;&2-;&2-;&u/./+/u)-)8&y=0>4)5+.>4}/>4"q_
kkkk	)-)8&}*k]kedf_
kkkk	/./+/}022W5-82p)-)8&q_
kkkk	<0(k=)>W8.1&k]k>&!k>&!+-}Y+)).>p"(&1u2-;&2-;&2-;&u/./+/u=)>y;8.1&}/>4",k3+>;)-.>pql
kkkk		)5-1}(&A.<&W5-82Y*Z0A&p"!(0/Q+.>4N0>"q_
kkkk	m}=->2p)5-1qq_
kkkk	=)>W8.1&}1&)K.1-)-.>pgfa,kdbfq_
kkkk	/./+/}022W5-82p=)>W8.1&,kfq_
kkkk	<0(k1/(k]k>&!k;;}M/(-)&p"(&1u2-;&2-;&2-;&u/./+/u=0>4)5+.>4y/}/>4"q_
kkkk	1/(}*k]ksca_
kkkk	/./+/}022W5-82p1/(q_
kkkk	;;}&<&>)[0>04&(}022T-1)&>&(pl
kkkkkkkkkkkk&<&>)vk;;}D<&>)T-1)&>&(}FJHWQyJZDyYGyJZD,
kkkkkkkkkkkk1!088.!F.+;5&1v)(+&,
kkkkkkkkkkkk.>F.+;5Y&40>kvk3+>;)-.>kp).+;5,k&<&>)qkl
kkkkkkkkkkkkkkkk(&)+(>k)(+&_
kkkkkkkkkkkkm}=->2p)5-1q,
kkkkkkkkm,k;.<&(q_
kkkkm,
kkkk15.!X->5N0>5vk3+>;)-.>py->2&:ql
kkkk	-3pkwy->2&:kqky->2&:k]kb_
kkkk	)5-1}(&A.<&W5-82Y*Z0A&p"!(0/X->5N0>5"q_
kkkkkkkk<0(k/./+/k]k>&!k;;}Z.2&pq_
kkkkkkkk/./+/}1&)Z0A&p"!(0/X->5N0>5"q_
kkkkkkkk)5-1}022W5-82p/./+/,kjjq_
kkkk	<0(k;.<&(k]k>&!k;;}M/(-)&p"(&1u2-;&2-;&2-;&u/./+/u;.<&(}/>4"q_
kkkk	/./+/}022W5-82p;.<&(q_
kkkk	<0(k=4k]k>&!k;;}M/(-)&p"(&1u2-;&2-;&2-;&u/./+/u=4y/./+/}/>4"q_
kkkk	/./+/}022W5-82p=4q_
kkkk	<0(k)-)8&k]k>&!k;;}M/(-)&p"(&1u2-;&2-;&2-;&u/./+/u)-)8&y=0>4<->520>5}/>4"q_
kkkk	)-)8&}*k]kedf_
kkkk	/./+/}022W5-82p)-)8&q_
kkkk	<0(k=)>W8.1&k]k>&!k>&!+-}Y+)).>p"(&1u2-;&2-;&2-;&u/./+/u=)>y;8.1&}/>4",k3+>;)-.>pql
kkkk		)5-1}(&A.<&W5-82Y*Z0A&p"!(0/X->5N0>5"q_
kkkk	m}=->2p)5-1qq_
kkkk	=)>W8.1&}1&)K.1-)-.>pgfa,kdbfq_
kkkk	/./+/}022W5-82p=)>W8.1&,kfq_
kkkk	<0(k)0=8&k]k>&!k>&!+-}F0=8&X-&!pbcfa,kggaq_
kkkkkkkk)0=8&}1&)W.8+A>pa}cf,ka}c,ka}bf,ka}c,ka}cq_
kkkkkkkk)0=8&}1&)I)&AQ&-45)pgaq_
kkkkkkkk)0=8&}1&)Q&02&(p"F5ờ-k4-0>",k"Fà-k75.ả>","K5ò>4",k"F5ắ>4",k"[ôkFả"q_
kkkkkkkk/./+/}022W5-82p)0=8&q_
kkkkkkkk[*E& +&1)}3&);5F./M8.)[0;5->&p)5-1}y40A&I2k,3+>;)-.>p;A2,k.=6ql
			-3pk.=6kxxk.=6}1)0)+1k]]kakxxk.=6}20)0}-)&A1}8&>4)5kql
				<0(ky8&>k]k.=6}20)0}-)&A1}8&>4)5_
				<0(k0((k]kno_
				3.(pk<0(k-]a_k-zy8&>_k-rrkql
					-3pk.=6}20)0}-)&A1n-o}011&)I2k]]k[.>&*F*/&}P.82kql
						0((}/+15pnk[Q};.><&()F-A&p.=6}20)0}-)&A1n-o};(&0)&2F-A&q,k.=6}20)0}-)&A1n-o}2-1/80*Z0A&,k[Q}>+AF.F&:)p.=6}20)0}-)&A1n-o}=&))->4q,k[Q}>+AF.F&:)p.=6}20)0}-)&A1n-o}A.>&*q,k.=6}20)0}-)&A1n-o}2&1;(-/)-.>oq_
					m
				m
				)0=8&}1&)W.>)&>)p0((q_
			m
		m}=->2p)5-1qq_
		;;}&<&>)[0>04&(}022T-1)&>&(pl
kkkkkkkkkkkk&<&>)vk;;}D<&>)T-1)&>&(}FJHWQyJZDyYGyJZD,
kkkkkkkkkkkk1!088.!F.+;5&1v)(+&,
kkkkkkkkkkkk.>F.+;5Y&40>kvk3+>;)-.>kp).+;5,k&<&>)qkl
kkkkkkkkkkkkkkkk(&)+(>k)(+&_
kkkkkkkkkkkkm}=->2p)5-1q,
kkkkkkkkm,k;.<&(q_
kkkkm,
kkkk;5&;7Q01C->vk3+>;)-.>pql
kkkk	-3pkw)5-1}y18.)N0)0kqk(&)+(>_
	kkkk<0(ky)*/&k]k">.(A08",kyA.>&*k]k)5-1}y18.)N0)0}AV_
	kkkk-3kp)5-1}y18.)N0)0}-Rql
	kkkkkkkky)*/&k]k"60;7/.)"_
	kkkkm&81&k-3pk)5-1}y18.)N0)0}=!kql
	kkkkkkkky)*/&k]k"=-4!->"_
	kkkkm&81&k-3pk)5-1}y18.)N0)0}AVkql
	kkkkkkkky)*/&k]k">.(A08"_
	kkkkm
	kkkk-3pk)5-1}y18.)N0)0}5[Pkql
	kkkkkkkkyA.>&*k]ka_
	kkkkkkkk3.(pk<0(k-]a_k-z)5-1}y18.)N0)0}!81}8&>4)5_k-rrkql
	kkkkkkkkkkkkyA.>&*kr]k)5-1}y18.)N0)0}!81n-o};(2_
	kkkkkkkkm
	kkkkm
	kkkk<0(k!->8->&1k]kno_
	kkkk-3pk)5-1}y18.)N0)0}!81kxxk)5-1}y18.)N0)0}!81}8&>4)5kql
	kkkkkkkk3.(pk<0(k-]a_k-zk)5-1}y18.)N0)0}!81}8&>4)5_k-rrkql
	kkkkkkkkkkkk!->8->&1}/+15pk)5-1}y18.)N0)0}!81n-o}8-2kq_
	kkkkkkkkm
	kkkkm
	kkkk)5-1}15.!T->&p!->8->&1q_
	kkkk-3pkyA.>&*kqk)5-1}15.!C->py)*/&,kyA.>&*q_
	kkkk&81&k)5-1};5&;7Q01Y.>+1pq_
kkkkm,
kkkk;5&;7Q01Y.>+1vk3+>;)-.>pql
kkkk	-3pkw)5-1}y18.)N0)0kqk(&)+(>_
kkkk	-3pk)5-1}y18.)N0)0}5[Pkqk)5-1}15.!C->p"=.>+1"q_
kkkk	&81&k)5-1};5&;7Q01O(&&M/->pq_
kkkkm,
kkkk;5&;7Q01O(&&M/->vk3+>;)-.>pql
kkkk	-3pkw)5-1}y18.)N0)0kqk(&)+(>_
kkkk	)5-1}y3(&&1/->N0)0nk)5-1}y18.)N0)0}=}).M)(->4pqko}31k]k)5-1}y18.)N0)0}311_
kkkk	-3pk)5-1}y18.)N0)0}311kql
kkkk		)5-1}8=Z+AO(&&M/->}4&)W5-82(&>pqnao}1&)M)(->4pk)5-1}y18.)N0)0}311kq_
kkkk		)5-1}8=Z+AO(&&M/->}1&)X-1-=8&p)(+&q_
kkkk	m&81&l
kkkk		)5-1}8=Z+AO(&&M/->}1&)X-1-=8&p3081&q_
kkkk	m
kkkk	-3pk)5-1}y18.)N0)0}5OMkqk)5-1}15.!C->p"3(&&1/->"q_
kkkk	&81&k)5-1}1/->N.>&pq_
kkkkm,
kkkk301)W5&;7C->vk3+>;)-.>pql
kkkkm,
kkkk15.!C->vk3+>;)-.>p)*/&,k>ql
kkkk	)5-1}!(0/C->}(&A.<&L88W5-82(&>pq_
kkkk	-3pk)*/&k]]]k3081&kql
kkkk		)5-1}!(0/C->}1&)X-1-=8&p3081&q_
kkkk		(&)+(>_
kkkk	m
kkkk	)5-1}!(0/C->}1&)X-1-=8&p)(+&q_
kkkk	<0(k2&80*W8.1&k]kd_
kkkk	-3pk)*/&k]]]k'=-4!->'kqk2&80*W8.1&k]kf_
kkkk	&81&k-3pk)*/&k]]]k'60;7/.)'kqk2&80*W8.1&k]kg_
kkkk	&81&k-3pk)*/&k]]]k'>.(A08'kqk2&80*W8.1&k]kc_
kkkk	-3pk>kxxk>{kjakqkl
kkkk		)5-1}1;5&2+8&J>;&p3+>;)-.>pql
	kkkk		)5-1}8=F.>4F50>4}1&)M)(->4pk[Q}>+AF.F&:)p>qkq_
	kkkk	m}=->2p)5-1q,kbq_
	kkkk	)5-1}y1/&07&(}/80*D33&;)p";.->H/T../"q_
kkkk	m
kkkk	1!-);5pk)*/&kql
kkkk		;01&k">.(A08"v
kkkk			<0(k8=Z.(A08k]k>&!k>&!+-}T0=&8Y[O.>)p"a",k"(&1u2-;&2-;&2-;&u3.>)u>+A=&(}3>)"q_
				8=Z.(A08}1&)W.8.(p;;};.8.(pcff,cff,baaqq_
				8=Z.(A08}1&)K.1-)-.>pa,kscaaq_
				)5-1}!(0/C->}022W5-82p8=Z.(A08q_
				8=Z.(A08};.+>)F.p>q_
kkkk			=(&07_
kkkk		;01&k"=-4!->"v
kkkk			<0(k3:T-45)k]k>&!k;;}M/(-)&p"(&1u2-;&2-;&2-;&u3:u8-45)yd}/>4"q_
				3:T-45)}*k]kha_
				)5-1}!(0/C->}022W5-82p3:T-45)q_
				<0(k3:N0(7k]k>&!k;;}M/(-)&p"(&1u2-;&2-;&2-;&u3:u=4s84}/>4"q_
				)5-1}!(0/C->}022W5-82p3:N0(7q_
				<0(k3:W.->k]k>&!k;;}M/(-)&p"(&1u2-;&2-;&2-;&u3:u;.->}/>4"q_
				3:W.->}*k]kfa_
				)5-1}!(0/C->}022W5-82p3:W.->q_
				<0(k3:F&:)k]k>&!k;;}M/(-)&p"(&1u2-;&2-;&2-;&u3:u)&:)y)50>48.>}/>4"q_
				3:F&:)}*k]kff_
				)5-1}!(0/C->}022W5-82p3:F&:)q_
				<0(k8=k]k>&!k>&!+-}T0=&8Y[O.>)p"a",k"(&1u2-;&2-;&2-;&u3.>)u>+A=&(}3>)"q_
				8=}1&)W.8.(p;;};.8.(pcff,cff,baaqq_
				8=}*k]ksef_
				)5-1}!(0/C->}022W5-82p8=q_
				8=};.+>)F.p>q_
				)5-1}y1/&07&(}/80*D33&;)p"=-4C->"q_
kkkk			=(&07_
kkkk		;01&k"3(&&1/->"v
kkkk			<0(k3:N0(7k]k>&!k;;}M/(-)&p"(&1u2-;&2-;&2-;&u3:u=4}/>4"q_
				)5-1}!(0/C->}022W5-82p3:N0(7q_
				<0(k3:F&:)k]k>&!k;;}M/(-)&p"(&1u2-;&2-;&2-;&u3:u)&:)y8 A/}/>4"q_
				3:F&:)}*k]kba_
				)5-1}!(0/C->}022W5-82p3:F&:)q_
				)5-1}y1/&07&(}/80*D33&;)p"!->O(&&M/->"q_
kkkk			=(&07_
kkkk		;01&k"=.>+1"v
kkkk			-3pk>kql
kkkk				<0(k8=Z.(A08k]k>&!k>&!+-}T0=&8Y[O.>)p"a",k"(&1u2-;&2-;&2-;&u3.>)u>+A=&(}3>)"q_
					8=Z.(A08}1&)W.8.(p;;};.8.(pcff,cff,baaqq_
					8=Z.(A08}1&)K.1-)-.>pa,kscaaq_
					)5-1}!(0/C->}022W5-82p8=Z.(A08q_
					8=Z.(A08};.+>)F.p>q_
					)5-1}y1/&07&(}/80*D33&;)p"!->Y.>+1"q_
kkkk			m&81&l
kkkk				<0(k3:N0(7k]k>&!k;;}M/(-)&p"(&1u2-;&2-;&2-;&u3:u=4}/>4"q_
					)5-1}!(0/C->}022W5-82p3:N0(7q_
					<0(k3:F&:)k]k>&!k;;}M/(-)&p"(&1u2-;&2-;&2-;&u3:u)&:)y=.>+140A&}/>4"q_
					3:F&:)}*k]kba_
					)5-1}!(0/C->}022W5-82p3:F&:)q_
					)5-1}y1/&07&(}/80*D33&;)p"!->Y.>+1"q_
kkkk			m
kkkk			=(&07_
kkkk		;01&k"60;7/.)"v
kkkk			<0(k3:T-45)k]k>&!k;;}M/(-)&p"(&1u2-;&2-;&2-;&u3:u8-45)yd}/>4"q_
				3:T-45)}*k]kha_
				)5-1}!(0/C->}022W5-82p3:T-45)q_
				<0(k3:N0(7k]k>&!k;;}M/(-)&p"(&1u2-;&2-;&2-;&u3:u=4s84}/>4"q_
				)5-1}!(0/C->}022W5-82p3:N0(7q_
				<0(k3:W.->k]k>&!k;;}M/(-)&p"(&1u2-;&2-;&2-;&u3:u;.->}/>4"q_
				3:W.->}*k]kfa_
				)5-1}!(0/C->}022W5-82p3:W.->q_
				<0(k3:F&:)k]k>&!k;;}M/(-)&p"(&1u2-;&2-;&2-;&u3:u)&:)y>.5+}/>4"q_
				3:F&:)}*k]kja_
				)5-1}!(0/C->}022W5-82p3:F&:)q_
				<0(k8=k]k>&!k>&!+-}T0=&8Y[O.>)p"a",k"(&1u2-;&2-;&2-;&u3.>)u>+A=&(}3>)"q_
				8=}1&)W.8.(p;;};.8.(pcff,cff,baaqq_
				8=}*k]ksga_
				)5-1}!(0/C->}022W5-82p8=q_
				8=};.+>)F.p>q_
				)5-1}y1/&07&(}/80*D33&;)p"!->R0;7/.)"q_
kkkk			=(&07_
kkkk		2&30+8)v
kkkk			)5-1}!(0/C->}1&)X-1-=8&p3081&q_
kkkk			=(&07_
kkkk	m
kkkk	)5-1}1;5&2+8&J>;&p3+>;)-.>pql
kkkk		)5-1}15.!T->&p3081&q_
kkkk		)5-1}15.!C->p3081&q_
kkkk		-3pkn">.(A08",k"=-4!->",k"60;7/.)"o}->2&:J3p)*/&qkw]]ksbkql
kkkk			)5-1};5&;7Q01Y.>+1pq_
kkkk		m&81&k-3pk)*/&k]]]k"=.>+1"kql
kkkk			-3pk>kqk)5-1};5&;7Q01O(&&M/->pq_
kkkk			&81&k)5-1}/80*Y.>+1pq_
kkkk		m&81&l
kkkk			)5-1}1/->N.>&pq_
kkkk		m
kkkk	m}=->2p)5-1q,k2&80*W8.1&q_
kkkkm,
kkkk1/->N.>&vk3+>;)-.>pql
kkkk	T.==*E& +&1)}4&)I>1)0>;&pq}(& +&1)H/20)&[.>&*pq_
kkkk	)5-1}y.>M/->k]k3081&_
kkkk	-3pk)5-1}y=&))->4kxxk)5-1}y3(&&1/->N0)0nk)5-1}y=&))->4}).M)(->4pqko}31kql
kkkk		)5-1}y1&>2E& +&1)M/->pq_
kkkk		(&)+(>
kkkk	m
kkkk	-3pk)5-1}y0+).M/->kql
kkkk		)5-1}y1&>2E& +&1)M/->pq_
kkkk		(&)+(>_
kkkk	m
kkkk	)5-1}=)>B+0*}1&)L;)-<&p3081&q_
kkkkm,
kkkk15.!T->&vk3+>;)-.>p20)0ql
kkkk	-3pk20)0k]]]k3081&k||kp;;}-1L((0*p20)0qkxxk20)0}8&>4)5k]]]kaqkql
kkkk		)5-1}!(0/T->&}1&)X-1-=8&p3081&q_
kkkk		)5-1}!(0/T->&}(&A.<&L88W5-82(&>pq_
kkkk		(&)+(>_
kkkk	m
kkkk	)5-1}!(0/T->&}1&)X-1-=8&p)(+&q_
kkkk	-3pk;;}-1L((0*p20)0qkql
kkkk		)5-1}!(0/T->&}(&A.<&L88W5-82(&>pq_
kkkk		3.(pk<0(k-]a_k-z20)0}8&>4)5_k-rrkql
kkkk			<0(k8k]k>&!k;;}M/(-)&p"(&1u2-;&2-;&2-;&u/80*u8->&u"rp20)0n-orbqr"}/>4"kq_
kkkk			8}1&)L>;5.(K.->)pa,kbq_
kkkk			)5-1}!(0/T->&}022W5-82pk8kq_
kkkk		m
kkkk	m&81&l
kkkk		<0(k8k]k>&!k;;}M/(-)&p"(&1u2-;&2-;&2-;&u/80*u8->&u"rp20)0rbqr"}/>4"kq_
kkkk		8}1&)L>;5.(K.->)pa,kbq_
kkkk		)5-1}!(0/T->&}022W5-82pk8kq_
kkkk	m
kkkkm,
	1&)B+*vk3+>;)-.>p20)0ql
		-3pk;;}-1Z+A=&(p20)0qkql
			)5-1}y80=&81Q+neo};.+>)F.p20)0,kcq_
			)5-1}y20)0R0;7/.)nco}Rk]k20)0_
		m&81&l
			-3pk)5-1}y=&))->4k]]]kakqlk
				)5-1}y80=&81Q+nao};.+>)F.p20)0nao}R,kcq_
				)5-1}y80=&81Q+nbo};.+>)F.p20)0nbo}R,kcq_
				)5-1}y80=&81Q+nco};.+>)F.p20)0nco}R,kcq_
				)5-1}y80=&81Q+ndo};.+>)F.p20)0nco}R,kcq_k
	kkkkkkkkm&81&l
	kkkkkkkk	-3pk)5-1}y=&))->4k]]]kbaakql
	kkkkkkkk		)5-1}y80=&81Q+neo};.+>)F.p20)0nao}R,kcq_
	kkkkkkkkkkkkm&81&k-3pk)5-1}y=&))->4k]]]kbaaakql
	kkkkkkkkkkkk	)5-1}y80=&81Q+neo};.+>)F.p20)0nbo}R,kcq_
	kkkkkkkkkkkkm&81&l
	kkkkkkkkkkkk	)5-1}y80=&81Q+neo};.+>)F.p20)0nco}R,kcq_
	kkkkkkkkkkkkm
	kkkkkkkkm
	kkkkkkkk)5-1}y20)0R0;7/.)k]k20)0_
		m
	m,
	>.)-3*vk3+>;)-.>p1)(,k)ql
		;;}2-(&;).(}4&)E+>>->4M;&>&pq}15.![&1104&p1)(q_
	m,
	1&)M&11-.>vk3+>;)-.>p1-2ql
		)5-1}8=M&11-.>}1&)M)(->4p"#"r1-2q_
		-3pk)5-1}y.>M/->kqk)5-1}y1/->>->4}1-2k]k1-2_
	m,
	.>E&;&-<&M/->vk3+>;)-.>p20)0ql
		)5-1}y18.)N0)0k]k>+88_
		<0(k>&&2O.(;&M)./k]k3081&_
		-3pkw20)0k||kw20)0}501J!>K(./&()*p'1=1'qk||k20)0}1=1}8&>4)5kw]kbfkqlk
	kkkk	>&&2O.(;&M)./k]k)(+&_
	kkkkm
	kkkk-3pk20)0kxxk20)0}A41kql
	kkkkkkkk)5-1}>.)-3*pk20)0}A41kq_
	kkkkkkkk>&&2O.(;&M)./k]k)(+&_
	kkkkm
	kkkk-3pkw>&&2O.(;&M)./kxxk)5-1}y.>M/->kxxk)5-1}y1/->>->4}1-2k]]]ksbkql
	kkkkkkkk)5-1}y18.)N0)0k]k20)0_
	kkkkkkkk-3pk)5-1}y-1F(-08kql
	kkkkkkkkkkkk)5-1}y)(-08R0;7/.)kr]kcftbaaaaubaa_
	kkkkkkkkkkkk)5-1}1&)B+*pk)5-1}y)(-08R0;7/.)kq_
	kkkkkkkkm
	kkkkkkkk)5-1}1&)M&11-.>pk20)0}1-2kq_
	kkkkkkkk<0(k)-A&M/->k]k)5-1}y1/->O01)?ka}fkvkc_
			)5-1}1;5&2+8&J>;&p3+>;)-.>pql
				)5-1};.8+A>1nao}1)./M/->pn)5-1}y18.)N0)0}1=1nao,)5-1}y18.)N0)0}1=1nfo,k)5-1}y18.)N0)0}1=1nbaooq_
				)5-1}1;5&2+8&J>;&p3+>;)-.>pql
					)5-1};.8+A>1nbo}1)./M/->pn)5-1}y18.)N0)0}1=1nbo,)5-1}y18.)N0)0}1=1ngo,)5-1}y18.)N0)0}1=1nbbooq_
					)5-1}1;5&2+8&J>;&p3+>;)-.>pql
						)5-1};.8+A>1nco}1)./M/->pn)5-1}y18.)N0)0}1=1nco,)5-1}y18.)N0)0}1=1nho,)5-1}y18.)N0)0}1=1nbcooq_
						)5-1}1;5&2+8&J>;&p3+>;)-.>pql
							)5-1};.8+A>1ndo}1)./M/->pn)5-1}y18.)N0)0}1=1ndo,)5-1}y18.)N0)0}1=1nio,)5-1}y18.)N0)0}1=1nbdooq_
							)5-1}1;5&2+8&J>;&p3+>;)-.>pql
								)5-1};.8+A>1neo}1)./M/->pn)5-1}y18.)N0)0}1=1neo,)5-1}y18.)N0)0}1=1njo,)5-1}y18.)N0)0}1=1nbeooq_
							m}=->2p)5-1q,kbq_
						m}=->2p)5-1q,ka}dq_
					m}=->2p)5-1q,ka}dq_
				m}=->2p)5-1q,ka}dq_
			m}=->2p)5-1q,k)-A&M/->q_
	kkkkm&81&l
	kkkk	)5-1}1;5&2+8&J>;&p)5-1}3.(;&M)./M/->,kbq_
	kkkkm
	m,
	y.>+/20)&P0A&vk3+>;)-.>p;A2,k20)0ql
		-3pk20)0nbo}4-2kw]k)5-1}y40A&I2kqk(&)+(>_
	kkkk1!-);5kpk/0(1&I>)pk;A2kqkql
	kkkkkkkk;01&kW[NyMTJFy[LWQIZD}MKIZkv
	kkkkkkkk;01&kW[NyMTJFy[LWQIZD}MKIZyFEILTkv
	kkkkkkkkkkkk)5-1}.>E&;&-<&M/->pk20)0nbokq_
	kkkkkkkkkkkk=(&07_
	kkkkkkkk2&30+8)v
	kkkkkkkkkkkk=(&07_
	kkkkm
	m,
	y.>J=1&(<&(E&1/.>1&vk3+>;)-.>p;A2,k20)0ql
	m,
	y.>E&;.>>&;)P0A&vk3+>;)-.>pql
		[->-P0A&W8-&>)}4&)I>1)0>;&pq}.=1&(<&(Y*P0A&INp)5-1}y40A&I2q_
	m,
	y.>F./Q+E&1/.>1&vk3+>;)-.>p;A2,k20)0ql
		-3pk)5-1}y-1F(-08kqk(&)+(>_
		<0(k20)0R0;7/.)k]knlRvam,lRvam,lRvamo_
	kkkk-3pk20)0kxxk20)0nbokxxk20)0nbo}R1kxxk20)0nbo}R1}8&>4)5kql
	kkkkkkkk3.(pk<0(k-k]ka_k-z20)0nbo}R1}8&>4)5_k-rrkql
	kkkkkkkkkkkk-3pk20)0nbo}R1n-o}4-2k]]]k)5-1}y40A&I2kql
	kkkkkkkkkkkkkkkk-3pk20)0nbo}R1n-o}=k]]]kbaakqk20)0R0;7/.)nao}Rk]k20)0nbo}R1n-o}R_
	kkkkkkkkkkkkkkkk&81&k-3pk20)0nbo}R1n-o}=k]]]kbaaakqk20)0R0;7/.)nbo}Rk]k20)0nbo}R1n-o}R_
	kkkkkkkkkkkkkkkk&81&k-3pk20)0nbo}R1n-o}=k]]]kbaaaakqk20)0R0;7/.)nco}Rk]k20)0nbo}R1n-o}R_
	kkkkkkkkkkkkm
	kkkkkkkkm
	kkkkm
	kkkk)5-1}1&)B+*pk20)0R0;7/.)kq_
	m,
	y+/20)&[.>&*vk3+>;)-.>pql
		-3pk)5-1}y=&))->4kqk)5-1}8=K80*&(P.82a};.+>)F.pK80*&([&}4.82q_
		&81&k)5-1}8=K80*&(P.82b};.+>)F.pkK80*&([&}4.82kq_
	m,
kkkk.>D>)&(vk3+>;)-.>pql
		)5-1}y1+/&(pq_
		)5-1}y4.).T.==*pq_
		)5-1};5..1&T->&1pna,b,c,d,e,f,g,h,i,j,ba,bb,bc,bd,be,bf,bg,bh,bi,bjoq_
		[->-P0A&W8-&>)}4&)I>1)0>;&pq}022T-1)&>&(pkW[NyMTJFy[LWQIZD}MKIZ}).M)(->4pqk,k)5-1}y.>+/20)&P0A&,k)5-1q_
	kkkk[->-P0A&W8-&>)}4&)I>1)0>;&pq}022T-1)&>&(pkW[NyMTJFy[LWQIZD}MKIZyFEILT}).M)(->4pqk,k)5-1}y.>+/20)&P0A&,k)5-1q_
	kkkk[->-P0A&W8-&>)}4&)I>1)0>;&pq}022T-1)&>&(pkW[NyMTJFy[LWQIZD}RLWSKJF}).M)(->4pqk,k)5-1}y.>+/20)&P0A&,k)5-1q_
	kkkk[->-P0A&W8-&>)}4&)I>1)0>;&pq}022T-1)&>&(pk7W[N}JYMDEXDEyEDMKJZMDk,k)5-1}y.>J=1&(<&(E&1/.>1&,k)5-1q_
	kkkk[->-P0A&W8-&>)}4&)I>1)0>;&pq}022T-1)&>&(pkW[NyJYMDEXDE}JYMDEXDEyMTJFyEDWJZZDWFk,k)5-1}y.>E&;.>>&;)P0A&,k)5-1q_
	kkkkF./Q+W8-&>)}4&)I>1)0>;&pq}022T-1)&>&(pk7W[N}FJKyQHk,k)5-1}y.>F./Q+E&1/.>1&,k)5-1q_
	kkkk[->-P0A&W8-&>)}4&)I>1)0>;&pq}.=1&(<&(Y*P0A&INp)5-1}y40A&I2q_
		T.==*W8-&>)}4&)I>1)0>;&pq}022T-1)&>&(p7W[N}HKNLFDy[JZDG}).M)(->4pq,k)5-1}y+/20)&[.>&*k,k)5-1q_
	m,
	.>D:-)vk3+>;)-.>pql
		)5-1}y1+/&(pq_
		;;}8.4p".>D:-)kN&02J(L8-<&"q_
		[->-P0A&W8-&>)}4&)I>1)0>;&pq}(&A.<&J=1&(<&(Y*P0A&INp)5-1}y40A&I2q_
		[->-P0A&W8-&>)}4&)I>1)0>;&pq}(&A.<&T-1)&>&(p)5-1q_
		F./Q+W8-&>)}4&)I>1)0>;&pq}(&A.<&T-1)&>&(p)5-1q_
		T.==*W8-&>)}4&)I>1)0>;&pq}(&A.<&T-1)&>&(p)5-1q_
		)5-1}y1/&07&(}2&1)(.*pq_
	m
mq_