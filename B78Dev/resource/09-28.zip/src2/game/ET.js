<0(kDFk]k;;}Z.2&}&:)&>2pl
	40A&I2vkW.>1)0>)}PL[DyIN}[IZIPL[D}DF,
	=&))->4vkbaaa,
	8->&1vkna,b,c,d,e,f,g,h,i,j,ba,bb,bc,bd,be,bf,bg,bh,bi,bjo,
	0+).K80*vk3081&,
	A.>&*F*/&vk[.>&*F*/&}P.82,
	y20)0R0;7/.)vknlRvam,lRvam,lRvamo,
	y.>M/->vk3081&,
	y1/->O01)vk3081&,
	y18.)N0)0vk>+88,
	y1&11-.>vk3081&,
	y1/->>->4vkl
kkkk	1-2vka,
kkkk	0)vka
kkkkm,
kkkk;).(vk3+>;)-.>p20)0ql
kkkk	)5-1}y1+/&(pq_
kkkk	)5-1}1&)K.1-)-.>p;;}/p;;}!->M-9&}!-2)5uc,k;;}!->M-9&}5&-45)ucqq_
		<0(k=4k]k>&!k;;}M/(-)&p"(&1u&)u=74}/>4"q_
		)5-1}022W5-82p=4,scq_
		<0(k)&:)F./k]k>&!k;;}M/(-)&p"(&1u&)u8.4.}/>4"q_
		)&:)F./}1&)K.1-)-.>psbbe,kceaq_
		)5-1}022W5-82p)&:)F./,ksbq_
		<0(k80=&8B+*k]k>&!k>&!+-}T0=&8Y[O.>)p"",k"(&1u&)u3.>)uDFs3.>)cs&:/.()}3>)"q_
		80=&8B+*}1&)M;08&pa}fq_
		80=&8B+*}1&)L>;5.(K.->)p;;}/pak,aqq_
		80=&8B+*}1&)K.1-)-.>p;;}/psbhi,kbdfqq_
kkkkkkkk)5-1}022W5-82p80=&8B+*q_
kkkkkkkk)5-1}80=&8B+*k]k80=&8B+*_
		<0(k1)&>;-8k]k>&!k;;}N(0!Z.2&pq_
kkkkkkkk1)&>;-8}2(0!K.8*p
kkkkkkkkkkkkn;;}/pa,kaq,;;}/pcif,kaq,;;}/pcif,cifq,;;}/pa,kcifqo,
kkkkkkkkkkkk;;};.8.(pcff,ka,ka,kcffq,
kkkkkkkkkkkka,
kkkkkkkkkkkk;;};.8.(pcff,kcff,kcff,kaq
kkkkkkkkq_
kkkkkkkk<0(k75+>4k]k>&!k;;}W8-//->4Z.2&p1)&>;-8q_
kkkkkkkk75+>4}1&)K.1-)-.>p;;}/psbjg,ksbheqq_
kkkkkkkk)5-1}022W5-82p75+>4,kcq_
kkkkkkkk)5-1};.8+A>1k]kno_
kkkkkkkk<0(k-)&A1k]kno,k-)&A1Y8+(k]kno_
kkkkkkkk3.(pk<0(k-]a_k-z]f_k-rrkql
kkkkkkkk	-)&A1}/+15pk;;}1/(-)&O(0A&W0;5&}4&)M/(-)&O(0A&p-r"y&)}/>4"qkq_
kkkkkkkk	-)&A1Y8+(}/+15pk;;}1/(-)&O(0A&W0;5&}4&)M/(-)&O(0A&p-r"y=8+(y&)}/>4"qkq_
kkkkkkkkm
	kkkk3.(p<0(k-]a_k-zd_k-rrql
kkkkkkkk	<0(k;.8k]k>&!kW.8+A>pl
kkkkkkkk		-)&AQvkjf,
kkkkkkkk		-)&A1vk-)&A1,
kkkkkkkk		-)&A1Y8+(vk-)&A1Y8+(,
kkkkkkkk		1/&&2vkbaia,
kkkkkkkk		=0;7J+)vkda,
kkkkkkkk		->2&:vk-
kkkkkkkk	mq_
kkkkkkkk	;.8}1&)K.1-)-.>p;;}/p-tjfreg,aqq_
kkkkkkkk	;.8}.>Y&3.(&M)./k]k3+>;)-.>p)0(4&)ql
kkkkkkkk		)5-1}/80*I)&AL>-A0)-.>p)0(4&)q_
kkkkkkkk	m}=->2p)5-1q_
kkkkkkkkkkkk75+>4}022W5-82p;.8q_
kkkkkkkkkkkk)5-1};.8+A>1n-ok]k;.8_
kkkkkkkkkkkk)5-1}/80*I)&AL>-A0)-.>p;.8q_
kkkkkkkkm
kkkkkkkk)5-1};.8+A>1nco}.>L3)&(M)./k]k3+>;)-.>pql
kkkkkkkk	)5-1}!->>&(D33pq_
kkkkkkkkm}=->2p)5-1q_
		)5-1}->-)Y+)).>pq_
		<0(k8.;0)-.>I>Z.2&k]k>+88_
kkkkkkkk<0(k1/(M-9&k]k>+88_
		;;}&<&>)[0>04&(}022T-1)&>&(pl
kkkkkkkkkkkk&<&>)vk;;}D<&>)T-1)&>&(}FJHWQyJZDyYGyJZD,
kkkkkkkkkkkk1!088.!F.+;5&1vk)(+&,
kkkkkkkkkkkk.>F.+;5Y&40>vk3+>;)-.>kp).+;5,k&<&>)qkl
kkkkkkkkkkkkkkkk1/(M-9&k]k=4}4&)W.>)&>)M-9&pq_
kkkkkkkkkkkkkkkk8.;0)-.>I>Z.2&k]k=4};.><&()F.Z.2&M/0;&p).+;5}4&)T.;0)-.>pqq_
kkkkkkkkkkkkkkkk<0(k(&;)k]k;;}(&;)pa,ka,k1/(M-9&}!-2)5,k1/(M-9&}5&-45)q_
kkkkkkkkkkkkkkkk-3kp;;}(&;)W.>)0->1K.->)p(&;),k8.;0)-.>I>Z.2&qql
kkkkkkkkkkkkkkkk	(&)+(>k)(+&_
kkkkkkkkkkkkkkkkm
kkkkkkkkkkkkkkkk(&)+(>k3081&_
kkkkkkkkkkkkm,
kkkkkkkkkkkk.>F.+;5[.<&2vk3+>;)-.>kp).+;5,k&<&>)qkl
kkkkkkkkkkkkkkkk<0(k)Tk]k).+;5}4&)T.;0)-.>pq_
kkkkkkkkkkkkkkkk<0(k>&!K.1k]k;;}/pk)T}:kr1/(M-9&}!-2)5ucksk8.;0)-.>I>Z.2&}:,k)T}*r1/(M-9&}5&-45)ucksk8.;0)-.>I>Z.2&}*kq_
kkkkkkkkkkkkkkkk-3pk>&!K.1}:kzksbgakqk>&!K.1}:k]ksbga_
kkkkkkkkkkkkkkkk&81&k-3pk>&!K.1}:k{kbdjakqk>&!K.1}:k]kbdja_
kkkkkkkkkkkkkkkk-3pk>&!K.1}*kzkshfkqk>&!K.1}*k]kshf_
kkkkkkkkkkkkkkkk&81&k-3pk>&!K.1}*k{khaakqk>&!K.1}*k]khaa_
kkkkkkkkkkkkkkkk)5-1}1&)K.1-)-.>pk>&!K.1kq_
kkkkkkkkkkkkm}=->2p)5-1q,
kkkkkkkkm,k)5-1q_
kkkkkkkk)5-1}2(0!T->&pq_
kkkkkkkk;;}8.4p"1)0()kDFk",k20)0q_k
kkkkkkkk-3p20)0ql
kkkkkkkk	-3pk20)0}81kqk)5-1}8->&1k]k20)0}81_
kkkkkkkk	-3pk20)0}301)kqk)5-1};50>4&M/->O01)p)(+&q_
kkkkkkkk	-3pk20)0}=&)kqk)5-1};50>4&Y&))->4p20)0}=&)q_
kkkkkkkk	)5-1};50>4&L+).M/->p)(+&q_
kkkkkkkkm
kkkkm,
kkkk->-)Y+)).>vk3+>;)-.>pql
kkkk	<0(k=)>X->5N0>5k]k>&!k>&!+-}Y+)).>p"(&1u&)u-;.>s<->520>5}/>4",k3+>;)-.>pql
kkkk		)5-1}15.!X->5N0>5pq_
kkkk	m}=->2p)5-1qq_
kkkk	=)>X->5N0>5}1&)K.1-)-.>pbde,kbfcq_
kkkk	)5-1}022W5-82p=)>X->5N0>5q_
kkkk	<0(k=)>Q&8/k]k>&!k>&!+-}Y+)).>p"(&1u&)u-;.>s5+.>420>}/>4",k3+>;)-.>pql
kkkk		)5-1}15.!Q+.>4N0>pq_
kkkk	m}=->2p)5-1qq_
kkkk	=)>Q&8/}1&)K.1-)-.>pbja,kbfcq_
kkkk	)5-1}022W5-82p=)>Q&8/q_
kkkk	<0(k=)>T-;5M+k]k>&!k>&!+-}Y+)).>p"(&1u&)u-;.>s-}/>4",k3+>;)-.>pql
kkkk		)5-1}15.!T-;5M+pq_
kkkk	m}=->2p)5-1qq_
kkkk	)5-1}022W5-82p=)>T-;5M+q_
kkkk	=)>T-;5M+}1&)K.1-)-.>phg,kbfcq_
kkkk	<0(k=)>W8.1&k]k>&!k>&!+-}Y+)).>p"(&1u&)u&:-)s40A&}/>4",k3+>;)-.>pql
kkkk		)5-1};8.1&pq_
kkkk	m}=->2p)5-1qq_
kkkk	=)>W8.1&}1&)K.1-)-.>pcfa,kbiaq_
kkkk	)5-1}022W5-82p=)>W8.1&q_
kkkk	<0(k=)>N.>4k]k>&!k>&!+-}Y+)).>p"(&1u&)u=+)).>s2.>4}/>4",k3+>;)-.>pql
kkkk		)5-1}15.!W5.>N.>4pq_
kkkk	m}=->2p)5-1qq_
kkkk	=)>N.>4}1&)K.1-)-.>pbii,khbq_
kkkk	)5-1}022W5-82p=)>N.>4q_
kkkk	<0(k8=N.>4k]k>&!k;;}T0=&8FFOpk)5-1}8->&1}8&>4)5k,k[Q}4&)O.>)p"HF[yM5.!;0(2"q,kci,;;}1-9&pbaa,kfaq,k;;}FDVFyLTIPZ[DZFyWDZFDEq_
kkkk	8=N.>4}1&)K.1-)-.>pjf,kcaq_
kkkk	=)>N.>4}022W5-82p8=N.>4q_
kkkk	)5-1}=)>N.>4k]k=)>N.>4_
kkkk	<0(k=)>M-&+F.;k]k>&!k>&!+-}Y+)).>pn"(&1u&)u=+)).>s1-&+).;c}/>4",k"(&1u&)u=+)).>s1-&+).;}/>4"o,k3+>;)-.>pql
kkkk		)5-1};50>4&M/->O01)pq_
kkkk	m}=->2p)5-1qq_
kkkk	=)>M-&+F.;}1&)K.1-)-.>pbii,khq_
kkkk	)5-1}022W5-82p=)>M-&+F.;q_
kkkk	)5-1}=)>M-&+F.;k]k=)>M-&+F.;_
kkkk	<0(k=)>B+0*k]k>&!k>&!+-}Y+)).>p"(&1u&)u=+)).>s +0*}/>4",k3+>;)-.>pql
kkkk		)5-1}y1&>2E& +&1)M/->pq_
kkkk	m}=->2p)5-1qq_
kkkk	=)>B+0*}1&)K.1-)-.>pbii,ksbcaq_
kkkk	)5-1}022W5-82p=)>B+0*q_
kkkk	<0(k=)>F+B+0*k]k>&!k>&!+-}Y+)).>pn"(&1u&)u=+)).>s)+ +0*}/>4",k"(&1u&)u=+)).>s)+ +0*c}/>4"o,k3+>;)-.>pql
kkkk		)5-1};50>4&L+).M/->pq_
kkkk	m}=->2p)5-1qq_
kkkk	=)>F+B+0*}1&)K.1-)-.>pbii,ksfgq_
kkkk	)5-1}022W5-82p=)>F+B+0*q_
kkkk	)5-1}=)>F+B+0*k]k=)>F+B+0*_
kkkk	<0(k=)>baak]k>&!k>&!+-}Y+)).>pn"(&1u&)ubaay->0;)-<&}/>4",k"(&1u&)ubaa}/>4"o,k3+>;)-.>pql
kkkk		)5-1};50>4&Y&))->4pbaaq_
kkkk	m}=->2p)5-1qq_
kkkk	=)>baa}1&)K.1-)-.>pscga,keiq_
kkkk	)5-1}022W5-82p=)>baaq_
kkkk	)5-1}=)>baak]k=)>baa_
kkkk	<0(k=)>bSk]k>&!k>&!+-}Y+)).>pn"(&1u&)ub7y->0;)-<&}/>4",k"(&1u&)ub7}/>4"o,k3+>;)-.>pql
kkkk		)5-1};50>4&Y&))->4pbaaaq_
kkkk	m}=->2p)5-1qq_
kkkk	=)>bS}1&)K.1-)-.>pscga,ksciq_
kkkk	)5-1}022W5-82p=)>bSq_
kkkk	)5-1}=)>bSk]k=)>bS_
kkkk	<0(k=)>baSk]k>&!k>&!+-}Y+)).>pn"(&1u&)uba7y->0;)-<&}/>4",k"(&1u&)uba7}/>4"o,k3+>;)-.>pql
kkkk		)5-1};50>4&Y&))->4pbaaaaq_
kkkk	m}=->2p)5-1qq_
kkkk	=)>baS}1&)K.1-)-.>pscga,ksbaeq_
kkkk	)5-1}022W5-82p=)>baSq_
kkkk	)5-1}=)>baSk]k=)>baS_
kkkkm,
	y1&>2E& +&1)M/->vk3+>;)-.>pql
		-3pk)5-1}y.>M/->kqk(&)+(>_
kkkk	)5-1}y18.)N0)0k]k>+88_
kkkk	)5-1}y1/->>->4}1-2k]ksb_
	kkkk)5-1}y1/->>->4}0)k]kp>&!kN0)&pqq}4&)F-A&pq_
	kkkk)5-1}y.>M/->k]k)(+&_
		)5-1}(&A.<&W5-82Y*Z0A&p"!->>&(D33",k"2(0!T->&"q_
		)5-1};.8+A>1nao}(+>M/->pq_
		)5-1};.8+A>1nbo}(+>M/->pq_
		)5-1};.8+A>1nco}(+>M/->pq_
		)5-1}1;5&2+8&J>;&p3+>;)-.>pql
			-3pk)5-1}y1/->>->4}1-2k]]]ksbkxxk>&!kN0)&pq}4&)F-A&pqksk)5-1}y1/->>->4}0)k{kfaaaakql
	kkkkkkkkkkkk)5-1}3.(;&M)./M/->pq_
	kkkkkkkkm
		m}=->2p)5-1q,kgaq_
		<0(	1&>2J=6k]kn
			;.AA0>2}U.>&K8+4->[&1104&,
			W.>1)0>)}WJZMFLZF}UJZDyZL[Dy[IZIyPL[D,
			A->-P0A&K8+4->}KTHPIZyMTJFyPL[D,
			l
				';A2'vW[NyMTJFy[LWQIZD}MKIZ,
				'4-2'v)5-1}40A&I2,
				'0-2'v)5-1}A.>&*F*/&,
				'81'v)5-1}8->&1,
				'='v)5-1}=&))->4
			m
		o_
		[->-P0A&W8-&>)}4&)I>1)0>;&pq}1&>2p1&>2J=6q_
	m,
	3.(;&M)./M/->vk3+>;)-.>pql
		)5-1};.8+A>1nao}1)./M/->pq_
		)5-1}1;5&2+8&J>;&p3+>;)-.>pql
			)5-1};.8+A>1nbo}1)./M/->pq_
			)5-1}1;5&2+8&J>;&p3+>;)-.>pql
				)5-1};.8+A>1nco}1)./M/->pq_
			m}=->2p)5-1q,kbq_
		m}=->2p)5-1q,ka}eq_
		)5-1};50>4&L+).M/->pk3081&kq_
		)5-1}y.>M/->k]k3081&_
	m,
	.>E&;&-<&M/->vk3+>;)-.>p20)0ql
		)5-1}y18.)N0)0k]k>+88_
		<0(k>&&2O.(;&M)./k]k3081&_
		-3pkw20)0k||kw20)0}501J!>K(./&()*p'1=1'qk||k20)0}1=1}8&>4)5kw]kjkqlk
	kkkk	>&&2O.(;&M)./k]k)(+&_
	kkkkm
	kkkk-3pk20)0kxxk20)0}A41kql
	kkkkkkkk)5-1}>.)-3*pk20)0}A41kq_
	kkkkkkkk>&&2O.(;&M)./k]k)(+&_
	kkkkm
	kkkk-3pkw>&&2O.(;&M)./kxxk)5-1}y.>M/->kxxk)5-1}y1/->>->4}1-2k]]]ksbkql
	kkkk	)5-1}y18.)N0)0k]k20)0_
	kkkk	)5-1}1&)M&11-.>pk20)0}1-2kq_
	kkkk	<0(k)-A&M/->k]k)5-1}y1/->O01)?ka}fkvkc_
	kkkk	)5-1}1;5&2+8&J>;&p3+>;)-.>pql
	kkkk		)5-1};.8+A>1nao}1)./M/->pq_
				)5-1}1;5&2+8&J>;&p3+>;)-.>pql
					)5-1};.8+A>1nbo}1)./M/->pq_
					)5-1}1;5&2+8&J>;&p3+>;)-.>pql
						)5-1};.8+A>1nco}1)./M/->pq_
					m}=->2p)5-1q,kbq_
				m}=->2p)5-1q,ka}eq_
	kkkk	m}=->2p)5-1q,k)-A&M/->q_
	kkkkm&81&l
	kkkk	)5-1}1;5&2+8&J>;&p)5-1}3.(;&M)./M/->,ka}fq_
	kkkkm
	m,
	>.)-3*vk3+>;)-.>p1)(ql
		;;}2-(&;).(}4&)E+>>->4M;&>&pq}15.![&1104&p1)(q_
	m,
	1&)M&11-.>vk3+>;)-.>p1-2ql
		)5-1}y1&11-.>k]k1-2_
	m,
	/80*I)&AL>-A0)-.>vk3+>;)-.>p;.8ql
		<0(k0((k]knc,kd,ke,kfo_
		<0(k-)&A1k]k;.8}4&)W5-82(&>pq_
		3.(pk<0(k-]-)&A1}8&>4)5sb_k-{]a_k-sskql
			-3pk0((}->2&:J3pk-)&A1n-o}-)&AI2kqkw]ksbkql
				<0(k0>-Ak]k;;};(&0)&M/->&p"(&1u&)u-)&AuI;.>s"r-)&A1n-o}-)&AI2r"}61.>",k"(&1u&)u-)&AuI;.>s"r-)&A1n-o}-)&AI2r"}0)801"q_
				0>-A}1&)L>-A0)-.>pa,k"I28&",k)(+&q_
				0>-A}-)&AI2k]k-)&A1n-o}-)&AI2_
				0>-A}1&)K.1-)-.>p-)&A1n-o}4&)K.1-)-.>pqq_
				0>-A}1&)F04p-)&A1n-o}4&)F04pqq_
				0>-A}1&)Z0A&p"0>-A0)-.>"q_
				;.8}022W5-82p0>-Aq_
				;.8}(&A.<&W5-82p-)&A1n-o,k)(+&q_
			m
		m
	m,
	1)./I)&AL>-A0)-.>vk3+>;)-.>p-)&Aql
	m,
	;8.1&vk3+>;)-.>pql
		[Q};8.1&P0A&pk)5-1}4&)Z0A&pqkq_
	m,
	./&>vk3+>;)-.>pql
		)5-1}1&)X-1-=8&p)(+&q_
		)5-1}1&)K.1-)-.>p;;}!->M-9&}!-2)5uc,k;;}!->M-9&}5&-45)ucrbaaq_
	m,
	1&)B+*vk3+>;)-.>p0((ql
		<0(ky>&!_
		1!-);5pk)5-1}=&))->4kql
			;01&kbaav
				y>&!k]k0((nao}R_
				=(&07_
			;01&kbaaav
				y>&!k]k0((nbo}R_
				=(&07_
			;01&kbaaaav
				y>&!k]k0((nco}R_
				=(&07_
			2&30+8)v
				y>&!k]ka_
				=(&07_
		m
		)5-1}80=&8B+*};.+>)F.py>&!,kbq_
		)5-1}y20)0R0;7/.)k]k0((_
	m,
	;50>4&Y&))->4vk3+>;)-.>p=&)ql
		-3pk)5-1}y.>M/->kql
			)5-1}>.)-3*p"S5ô>4kđượ;k;5ọ>k75-kđ0>4k +0*"q_
			(&)+(>_
		m
		1!-);5p=&)ql
			;01&kbaav
				)5-1}=)>baa}1&)L;)-<&p)(+&q_
				)5-1}=)>bS}1&)L;)-<&p3081&q_
				)5-1}=)>baS}1&)L;)-<&p3081&q_
				)5-1}=&))->4k]k=&)_
				=(&07_
			;01&kbaaav
				)5-1}=)>baa}1&)L;)-<&p3081&q_
				)5-1}=)>bS}1&)L;)-<&p)(+&q_
				)5-1}=)>baS}1&)L;)-<&p3081&q_
				)5-1}=&))->4k]k=&)_
				=(&07_
			;01&kbaaaav
				)5-1}=)>baa}1&)L;)-<&p3081&q_
				)5-1}=)>bS}1&)L;)-<&p3081&q_
				)5-1}=)>baS}1&)L;)-<&p)(+&q_
				)5-1}=&))->4k]k=&)_
				=(&07_
		m
	m,
	;50>4&L+).M/->vk3+>;)-.>p1ql
		-3pk0(4+A&>)1}8&>4)5k]]kakqk1k]kw)5-1}0+).K80*_
		-3pk1kxxkw)5-1}y.>M/->kqk)5-1}y1&>2E& +&1)M/->pq_
		)5-1}0+).K80*k]k1_
		)5-1}=)>F+B+0*}1&)L;)-<&p1q_
	m,
	;50>4&M/->O01)vk3+>;)-.>p1ql
		;;}8.4p".>k;504&k3011)",k)5-1q_
		-3pk0(4+A&>)1}8&>4)5k]]kakqk1k]kw)5-1}y1/->O01)_
		)5-1}y1/->O01)k]k1_
		)5-1}=)>M-&+F.;}1&)L;)-<&p1q_
	m,
	15.!W5.>N.>4vk3+>;)-.>pql
		-3pk)5-1}y.>M/->kql
			)5-1}>.)-3*p"S5ô>4kđượ;k;5ọ>k75-kđ0>4k +0*"q_
			(&)+(>_
		m
		<0(k/./+/k]k>&!k[QK./+/Tpq_
		/./+/}1&)F-)8&p"(&1u&)u/-;78->&u)&:)s2.>420);+.;}/>4"q_
		<0(k!(0/k]k>&!k;;}Z.2&pq_
		<0(k=)>W50>k]k>&!k>&!+-}Y+)).>p"(&1u&)u/-;78->&u/./+/s=+)).>e}/>4",k3+>;)-.>pql
			)5-1}8->&1k]knb,d,f,h,j,bb,bd,bf,bh,bjo_
			)5-1}=)>N.>4};5-82(&>nao}1)(->4k]k)5-1}8->&1}8&>4)5_
			3.(pk<0(k-]a_k-zca_k-rrkql
				-3pk)5-1}8->&1}->2&:J3p-qk]]ksbkqk!(0/};5-82(&>n-o}1&)L;)-<&p3081&q_
				&81&k!(0/};5-82(&>n-o}1&)L;)-<&p)(+&q_
			m
		m}=->2p)5-1qq_
		=)>W50>}1&)K.1-)-.>pscgc,kscbhq_
		<0(k=)>T&k]k>&!k>&!+-}Y+)).>p"(&1u&)u/-;78->&u/./+/s=+)).>d}/>4",k3+>;)-.>pql
			)5-1}8->&1k]kna,c,e,g,i,ba,bc,be,bg,bio_
			)5-1}=)>N.>4};5-82(&>nao}1)(->4k]k)5-1}8->&1}8&>4)5_
			3.(pk<0(k-]a_k-zca_k-rrkql
				-3pk)5-1}8->&1}->2&:J3p-qk]]ksbkqk!(0/};5-82(&>n-o}1&)L;)-<&p3081&q_
				&81&k!(0/};5-82(&>n-o}1&)L;)-<&p)(+&q_
			m
		m}=->2p)5-1qq_
		=)>T&}1&)K.1-)-.>psih,kscbhq_
		<0(k=)>L88k]k>&!k>&!+-}Y+)).>p"(&1u&)u/-;78->&u/./+/s=+)).>c}/>4",k3+>;)-.>pql
			)5-1}8->&1k]kna,b,c,d,e,f,g,h,i,j,ba,bb,bc,bd,be,bf,bg,bh,bi,bjo_
			)5-1}=)>N.>4};5-82(&>nao}1)(->4k]k)5-1}8->&1}8&>4)5_
			3.(pk<0(k-]a_k-zca_k-rrkql
				-3pk)5-1}8->&1}->2&:J3p-qk]]ksbkqk!(0/};5-82(&>n-o}1&)L;)-<&p3081&q_
				&81&k!(0/};5-82(&>n-o}1&)L;)-<&p)(+&q_
			m
		m}=->2p)5-1qq_
		=)>L88}1&)K.1-)-.>pii,kscbhq_
		<0(k=)>Z.>&k]k>&!k>&!+-}Y+)).>p"(&1u&)u/-;78->&u/./+/s=+)).>b}/>4",k3+>;)-.>pql
			)5-1}8->&1k]knao_
			)5-1}=)>N.>4};5-82(&>nao}1)(->4k]k)5-1}8->&1}8&>4)5_
			3.(pk<0(k-]a_k-zca_k-rrkql
				-3pk)5-1}8->&1}->2&:J3p-qk]]ksbkqk!(0/};5-82(&>n-o}1&)L;)-<&p3081&q_
				&81&k!(0/};5-82(&>n-o}1&)L;)-<&p)(+&q_
			m
		m}=->2p)5-1qq_
		=)>Z.>&}1&)K.1-)-.>pcgd,kscbhq_
		/./+/}022W.>)&>)pk=)>W50>,k=)>T&,k=)>L88,k=)>Z.>&,k!(0/kq_
		3.(pk<0(k-]a_k-zca_k-rrkql
			<0(k=+)).>k]k>&!k>&!+-}Y+)).>pn"(&1u&)u/-;78->&u"rkp-rbqkr"yc}/>4","(&1u&)u/-;78->&u"rkp-rbqkr"}/>4"o,k3+>;)-.>p1&>2&(ql
				<0(k8-2k]k1&>2&(}8->&I2_
				<0(k->2&:k]k)5-1}8->&1}->2&:J3p8-2q_
				-3pk->2&:k]]]ksbkql
					)5-1}8->&1}/+15pk8-2kq_
					1&>2&(}1&)L;)-<&p)(+&q_
				m&81&l
					)5-1}8->&1}1/8-;&p->2&:,kbq_
					1&>2&(}1&)L;)-<&p3081&q_
				m
				)5-1}=)>N.>4};5-82(&>nao}1)(->4k]k)5-1}8->&1}8&>4)5_
			m}=->2p)5-1qq_
			=+)).>}8->&I2k]k-_
			=+)).>}:k]ksdcbkrbfitp-%fq_
			=+)).>}*k]kcbgkskbbatk[0)5}38..(p-ufqk_
			-3pk)5-1}8->&1}->2&:J3p-qk]]]ksbkql
				=+)).>}1&)L;)-<&p3081&q_
			m&81&l
				=+)).>}1&)L;)-<&p)(+&q_
			m
			!(0/}022W5-82p=+)).>q_
		m
		/./+/}15.!pq_
	m,
	15.!Q+.>4N0>vk3+>;)-.>pql
		<0(k/./+/k]k>&!k[QK./+/Tpq_
		/./+/}1&)F-)8&p"(&1u&)u/-;78->&u)&:)s2.>420);+.;}/>4"q_
		<0(k1/(k]k>&!k;;}M/(-)&p"(&1u&)u)&:)s)5&8&}/>4"q_
		1/(}*k]ksf_
		/./+/}1&)W.>)&>)pk1/(kq_
		/./+/}15.!pq_
	m,
	15.!T-;5M+vk3+>;)-.>pql
		<0(k/./+/k]k>&!k[QK./+/Tpq_
		/./+/}1&)F-)8&p"(&1u/./+/u)-)8&u)&:)sTMB+0*}/>4"q_
		/./+/}15.!pq_
		<0(k)0=8&k]k>&!k>&!+-}F0=8&X-&!pjjf,kfdaq_
kkkkkkkk)0=8&}1&)W.8+A>pa}c,ka}c,ka}bf,ka}bf,ka}dq_
kkkkkkkk)0=8&}1&)I)&AQ&-45)pgaq_
kkkkkkkk)0=8&}1&)Q&02&(p"K5-ê>",k"F5ờ-kP-0>",k"Wượ;",k"Z5ậ>",k"W5-kF-ế)"q_
kkkkkkkk/./+/}022W.>)&>)p)0=8&q_
kkkkkkkk[*E& +&1)}3&);5M8.)[0;5->&Q-1).(*p)5-1}40A&I2,k)5-1}A.>&*F*/&,kfa,ka,k3+>;)-.>p;A2,k.=6ql
kkkkkkkk	;;}8.4p"20)0",k.=6q_
			-3pk.=6kxxk.=6}1)0)+1k]]kakxxk.=6}20)0}-)&A1}8&>4)5kql
				<0(ky8&>k]k.=6}20)0}-)&A1}8&>4)5_
				<0(k0((k]kno_
				3.(pk<0(k-]a_k-zy8&>_k-rrkql
					<0(k-)&Ak]k.=6}20)0}-)&A1n-o_
					-3pk-)&A}011&)I2k]]k[.>&*F*/&}P.82kql
						0((}/+15pnk-)&A}1&11-.>I2k,k[Q};.><&()F-A&p-)&A};(&0)&2F-A&q,k[Q}>+AF.F&:)p-)&A}=&))->4q,k[Q}>+AF.F&:)p-)&A}A.>&*q,k-)&A}2&1;(-/)-.>oq_
					m
				m
				)0=8&}1&)W.>)&>)p0((q_
			m
		m}=->2p)5-1qq_
	m,
	15.!X->5N0>5vk3+>;)-.>pql
		<0(k/./+/k]k>&!k[QK./+/Tpq_
kkkkkkkk/./+/}1&)F-)8&p"(&1u/./+/u)-)8&u)&:)sY0>4X->5N0>5}/>4"q_
kkkkkkkk<0(k)0=8&k]k>&!k>&!+-}F0=8&X-&!pjjf,kfdaq_
kkkkkkkk)0=8&}1&)W.8+A>pa}cf,ka}c,ka}bf,ka}c,ka}cq_
kkkkkkkk)0=8&}1&)I)&AQ&-45)pgaq_
kkkkkkkk)0=8&}1&)Q&02&(p"F5ờ-k4-0>",k"Fà-k75.ả>","Wượ;",k"F5ắ>4",k"T.ạ-"q_
kkkkkkkk/./+/}022W.>)&>)p)0=8&q_
kkkkkkkk/./+/}15.!pq_
kkkkkkkk[*E& +&1)}3&);5F./M8.)[0;5->&p)5-1}40A&I2k,3+>;)-.>p;A2,k.=6ql
			-3pk.=6kxxk.=6}1)0)+1k]]kakxxk.=6}20)0}-)&A1}8&>4)5kql
				<0(ky8&>k]k.=6}20)0}-)&A1}8&>4)5_
				<0(k0((k]kno_
				3.(pk<0(k-]a_k-zy8&>_k-rrkql
					-3pk.=6}20)0}-)&A1n-o}011&)I2k]]k[.>&*F*/&}P.82kql
						0((}/+15pnk[Q};.><&()F-A&p.=6}20)0}-)&A1n-o};(&0)&2F-A&q,k.=6}20)0}-)&A1n-o}2-1/80*Z0A&,k[Q}>+AF.F&:)p.=6}20)0}-)&A1n-o}=&))->4q,k[Q}>+AF.F&:)p.=6}20)0}-)&A1n-o}A.>&*q,k.=6}20)0}-)&A1n-o}2&1;(-/)-.>oq_
					m
				m
				)0=8&}1&)W.>)&>)p0((q_
			m
		m}=->2p)5-1qq_
	m,
	2(0!T->&vk3+>;)-.>p8-21,k&33,k15.!.>&ql
		)5-1}(&A.<&W5-82Y*Z0A&p"2(0!T->&"q_
		<0(k2(0!T->&C(0/k]k>&!k;;}Z.2&pq_
		2(0!T->&C(0/}1&)Z0A&p"2(0!T->&"q_
		2(0!T->&C(0/}1&)K.1-)-.>psfc,ksciq_
		)5-1}022W5-82p2(0!T->&C(0/,kbq_k
		-3pk;;}-1L((0*p8-21qkql
			-3pkw&33kql
				3.(pk<0(k-]a_k-z8-21}8&>4)5_k-rrkql
					8-21n-or]b_
					<0(ky1(;k]k"(&1u&)u8->&u=)>T->&y"_
					-3pk8-21n-ozbakqky1(;kr]k"a"_
					y1(;kr]k8-21n-or"}/>4"_
					2(0!T->&C(0/}022W5-82pk>&!k;;}M/(-)&py1(;qkq_
				m
			m&81&l
				<0(k-]a_
				<0(k->)&(<08k]ka}b_
				-3pk;;}-1Z+A=&(p&33qkqk->)&(<08k]k&33_
				;;}2-(&;).(}4&)M;5&2+8&(pq}1;5&2+8&p3+>;)-.>pql
					-3pk-z8-21}8&>4)5kql
						8-21n-or]b_
						-3pk15.!.>&kqk2(0!T->&C(0/}(&A.<&L88W5-82(&>pq_
						<0(ky1(;k]k"(&1u&)u8->&u=)>T->&y"_
						-3pk8-21n-ozbakqky1(;kr]k"a"_
						y1(;kr]k8-21n-or"}/>4"_
						2(0!T->&C(0/}022W5-82pk>&!k;;}M/(-)&py1(;qkq_
						-rr_
					m&81&l
						-3pk15.!.>&kqk2(0!T->&C(0/}(&A.<&L88W5-82(&>pq_
						;;}2-(&;).(}4&)M;5&2+8&(pq}+>1;5&2+8&L88O.(F0(4&)p2(0!T->&C(0/q_
					m
				m,k2(0!T->&C(0/,k->)&(<08,k3081&q
			m
		m&81&l
			;;}8.4p"&((}k0((0*"q_
		m
	m,
	;5&;7Q01C->vk3+>;)-.>pql
	m,
	!->>&(D33vk3+>;)-.>pql
		-3pkw)5-1}y18.)N0)0kql
			)5-1};50>4&L+).M/->p3081&q_
			)5-1}1;5&2+8&J>;&p)5-1}1/->N.>&,kbq_
			(&)+(>_
		m
		<0(ky!81k]kno,
			y![.>&*k]ka_
		-3pk)5-1}y18.)N0)0}!81kxxk)5-1}y18.)N0)0}!81}8&>4)5kql
			y![.>&*k]k)5-1}y18.)N0)0}AV_
			3.(pk<0(k-]a_k-z)5-1}y18.)N0)0}!81}8&>4)5_k-rrkql
				y!81}/+15pk)5-1}y18.)N0)0}!81n-o}8-2kq_
			m
		m
		-3pky!81}8&>4)5kql
			<0(k80=&8k]k>&!k>&!+-}T0=&8Y[O.>)p[Q}>+AF.F&:)py![.>&*q,k"(&1u&)u3.>)uDFs3.>)bs&:/.()}3>)"q_
			<0(k)-A&W8.1&k]kd_
			<0(k!->>&(D33_
			-3pk)5-1}y18.)N0)0}=!k||k)5-1}y18.)N0)0}-Rkql
				!->>&(D33k]k>&!k;;}Z.2&pq_
				<0(k!->L>-Ak]k;;};(&0)&M/->&p"(&1u&)u3:uDFsF50>4sb}61.>",k"(&1u&)u3:uDFsF50>4sb}0)801"q_k
				-3pk)5-1}y18.)N0)0}-Rkqk!->L>-A}1&)L>-A0)-.>pa,k"Z.Q+",k)(+&q_
				&81&k!->L>-A}1&)L>-A0)-.>pa,k"F50>4sT.>",k)(+&q_
				!->>&(D33}022W5-82p!->L>-Aq_
				!->>&(D33}022W5-82p80=&8q_
				80=&8}*k]ksda_
				-3pk)5-1}0+).K80*kqk)-A&W8.1&k]kh_
				&81&k)-A&W8.1&k]kbf_
			m&81&l
				!->>&(D33k]k80=&8_
			m
			!->>&(D33}1&)Z0A&p"!->>&(D33"q_
			!->>&(D33}1&)K.1-)-.>psfg,kceq_
			!->>&(D33}1&)L>;5.(K.->)pa}f,ka}fq_
			)5-1}022W5-82p!->>&(D33,kdq_k
			80=&8};.+>)F.py![.>&*,kbq_
			)5-1}2(0!T->&py!81q_
			;;}2-(&;).(}4&)M;5&2+8&(pq}1;5&2+8&p3+>;)-.>pql
				)5-1}1/->N.>&pq_
			m}=->2p)5-1q,k!->>&(D33,ka,ka,k)-A&W8.1&,k3081&,k";8.1&C->>&(D33"q_
		m&81&l
			)5-1}1;5&2+8&J>;&p)5-1}1/->N.>&,kbq_
		m
	m,
	1/->N.>&vk3+>;)-.>pql
		T.==*E& +&1)}4&)I>1)0>;&pq}(& +&1)H/20)&[.>&*pq_
		)5-1}y.>M/->k]k3081&_
kkkk	-3pk)5-1}0+).K80*kql
kkkk		)5-1}y1&>2E& +&1)M/->pq_
kkkk	m&81&k-3pk)5-1}y18.)N0)0kxxk)5-1}y18.)N0)0}!81kql
kkkk		-3pkw)5-1}y18.)N0)0}=!kxxkw)5-1}y18.)N0)0}-Rkql
kkkk			)5-1}(&A.<&W5-82Y*Z0A&p"!->>&(D33"q_
kkkk			<0(ky!81k]kno_
kkkk			3.(pk<0(k-]a_k-z)5-1}y18.)N0)0}!81}8&>4)5_k-rrkql
					y!81}/+15pk)5-1}y18.)N0)0}!81n-o}8-2kq_
				m
				)5-1}2(0!T->&py!81,kb,k)(+&q_
kkkk		m
kkkk	m
	m,
	(&A.<&W5-82Y*Z0A&vk3+>;)-.>pql
		<0(k0((k]kno_
		3.(pk<0(k-]a_k-z0(4+A&>)1}8&>4)5_k-rrkql
			0((}/+15pk0(4+A&>)1n-okq_
		m
		<0(k;5-82k]k)5-1}4&)W5-82(&>pq_
		3.(pk<0(k-];5-82}8&>4)5sb_k-{]a_k-sskql
			-3pk0((}->2&:J3p;5-82n-o}4&)Z0A&pqqkw]ksbkql
				)5-1}(&A.<&W5-82pk;5-82n-o,k)(+&q_
			m
		m
	m,
	y.>J=1&(<&(E&1/.>1&vk3+>;)-.>pqlm,
	y.>E&;.>>&;)P0A&vk3+>;)-.>pql
		[->-P0A&W8-&>)}4&)I>1)0>;&pq}.=1&(<&(Y*P0A&INp)5-1}40A&I2q_
	m,
	y.>+/20)&P0A&vk3+>;)-.>p;A2,k20)0ql
		-3pk20)0nbo}4-2kw]k)5-1}40A&I2kqk(&)+(>_
		1!-);5pk/0(1&I>)p;A2qkql
			;01&kW[NyMTJFy[LWQIZD}RLWSKJFkv
				)5-1}1&)B+*pk20)0nbo}R1kq_
				=(&07_
			;01&kW[NyMTJFy[LWQIZD}MKIZkv
				)5-1}.>E&;&-<&M/->pk20)0nbokq_
				=(&07_
			2&30+8)v
				=(&07_
		m
	m,
	.>D>)&(vk3+>;)-.>pql
		)5-1}y1+/&(pq_
		-3pkw)5-1}0+).K80*kqk)5-1};50>4&Y&))->4pbaaaq_
		[->-P0A&W8-&>)}4&)I>1)0>;&pq}022T-1)&>&(pkW[NyMTJFy[LWQIZD}RLWSKJF}).M)(->4pqk,k)5-1}y.>+/20)&P0A&,k)5-1q_
		[->-P0A&W8-&>)}4&)I>1)0>;&pq}022T-1)&>&(pkW[NyMTJFy[LWQIZD}MKIZ}).M)(->4pqk,k)5-1}y.>+/20)&P0A&,k)5-1q_
	kkkk[->-P0A&W8-&>)}4&)I>1)0>;&pq}022T-1)&>&(pk7W[N}JYMDEXDEyEDMKJZMDk,k)5-1}y.>J=1&(<&(E&1/.>1&,k)5-1q_
	kkkk[->-P0A&W8-&>)}4&)I>1)0>;&pq}022T-1)&>&(pkW[NyJYMDEXDE}JYMDEXDEyMTJFyEDWJZZDWFk,k)5-1}y.>T.4->J(E&;.>>&;)M+;&11,k)5-1q_
	kkkk[->-P0A&W8-&>)}4&)I>1)0>;&pq}.=1&(<&(Y*P0A&INp)5-1}40A&I2q_
	m,
	.>D:-)vk3+>;)-.>pql
		)5-1}y1+/&(pq_
		-3pkw)5-1}0+).K80*kqk[->-P0A&W8-&>)}4&)I>1)0>;&pq}(&A.<&J=1&(<&(Y*P0A&INp)5-1}40A&I2q_
		[->-P0A&W8-&>)}4&)I>1)0>;&pq}(&A.<&T-1)&>&(p)5-1q_
	m
mq_