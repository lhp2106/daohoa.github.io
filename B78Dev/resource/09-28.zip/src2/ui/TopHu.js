<0(kF./Q+k]k;;}M/(-)&}&:)&>2pl
	y-)&AQvkia,
	y0;)-<&E..Avka,
kkkky20)0R0;7/.)vk>+88,
kkkk;).(vk3+>;)-.>p4-2ql
kkkkkkkk)5-1}y1+/&(p"(&1u)./5+u8-1)s5+}/>4"q_
kkkkkkkk)5-1}y8-1)k]kn
kkkkkkkkkkkkl80=&8vk>+88,k!(0/vk>+88,k47&*v"[IZIKJSDE",kRvka,k4>0A&vk"[->-K.7&("m,
kkkkkkkkkkkkl80=&8vk>+88,k!(0/vk>+88,k47&*v"DF",kRvka,k4>0A&vk"DF"m,
kkkkkkkkkkkkl80=&8vk>+88,k!(0/vk>+88,k47&*v"MIDHVD",kRvka,k4>0A&vk"[;B+&&>"m,
kkkkkkkkkkkkl80=&8vk>+88,k!(0/vk>+88,k47&*v"NIWDNIWDNIWD",kRvka,k4>0A&vk"N-;&N-;&N-;&"m,
kkkkkkkkkkkkl80=&8vk>+88,k!(0/vk>+88,k47&*v"NDLNJELTIXD",kRvka,k4>0A&vk"N&02J(L8-<&"m,
kkkkkkkkkkkkl80=&8vk>+88,k!(0/vk>+88,k47&*v"FLGNHSG",kRvka,k4>0A&vk"Fâ*kN+kSý"m
kkkkkkkko_
kkkkkkkk<0(k=)>baak]k>&!k>&!+-}Y+)).>pn"(&1u)./5+ubaas)0=}/>4"o,k3+>;)-.>pql
kkkkkkkkkkkk)5-1}y;50>4&E..Apbq_
kkkkkkkkm}=->2p)5-1qq_
kkkkkkkk=)>baa}1&)K.1-)-.>p;;}/pfc,kdfaqq_
kkkkkkkk)5-1}022W5-82p=)>baaq_
kkkkkkkk)5-1}=)>baak]k=)>baa_
kkkkkkkk<0(k=)>bSk]k>&!k>&!+-}Y+)).>pn"(&1u)./5+ub7s)0=}/>4"o,k3+>;)-.>pql
kkkkkkkkkkkk)5-1}y;50>4&E..Apcq_
kkkkkkkkm}=->2p)5-1qq_
kkkkkkkk=)>bS}1&)K.1-)-.>p;;}/pbde,kdfaqq_
kkkkkkkk)5-1}022W5-82p=)>bSq_
kkkkkkkk)5-1}=)>bSk]k=)>bS_
kkkkkkkk<0(k=)>baSk]k>&!k>&!+-}Y+)).>pn"(&1u)./5+uba7s)0=}/>4"o,k3+>;)-.>pql
kkkkkkkkkkkk)5-1}y;50>4&E..Apdq_
kkkkkkkkm}=->2p)5-1qq_
kkkkkkkk=)>baS}1&)K.1-)-.>p;;}/pcbf,kdfaqq_
kkkkkkkk)5-1}022W5-82p=)>baS,kfq_
kkkkkkkk)5-1}=)>baSk]k=)>baS_
kkkkkkkk<0(k1;(.88X-&!k]k>&!k;;+-}M;(.88X-&!pq_
kkkkkkkk1;(.88X-&!}1&)N-(&;)-.>p;;+-}M;(.88X-&!}NIEyXDEFIWLTq_
kkkkkkkk1;(.88X-&!}1&)Y.+>;&D>0=8&2p)(+&q_
kkkkkkkk1;(.88X-&!}1&)W.>)&>)M-9&p;;}1-9&pcff,kdbdqq_
kkkkkkkk1;(.88X-&!}1&)I>>&(W.>)0->&(M-9&p;;}1-9&pcff,k)5-1}y8-1)}8&>4)5t)5-1}y-)&AQqq_
kkkkkkkk1;(.88X-&!}1&)K.1-)-.>p;;}/pbdc,kbgdqq_
kkkkkkkk1;(.88X-&!}1&)L>;5.(K.->)p;;}/pa}f,ka}fqq_
kkkkkkkk)5-1}022W5-82p1;(.88X-&!q_
		3.(p<0(k-])5-1}y8-1)}8&>4)5sb_k-{]a_k-ssql
kkkkkkkkkkkk-3pkW.>1)0>)}PL[DyIN}YIPMTJF}501J!>K(./&()*p)5-1}y8-1)n-o}47&*qkql
kkkkkkkkkkkkkkkk)5-1}y8-1)n-o}4-2k]kW.>1)0>)}PL[DyIN}YIPMTJFn)5-1}y8-1)n-o}47&*o_
kkkkkkkkkkkkm&81&k-3pkW.>1)0>)}PL[DyIN}[IZIPL[D}501J!>K(./&()*p)5-1}y8-1)n-o}47&*qkql
kkkkkkkkkkkkkkkk)5-1}y8-1)n-o}4-2k]kW.>1)0>)}PL[DyIN}[IZIPL[Dn)5-1}y8-1)n-o}47&*o_
kkkkkkkkkkkkm&81&l
kkkkkkkkkkkkkkkk=(&07_
kkkkkkkkkkkkm
			<0(k!(0/k]k>&!k;;}M/(-)&p"(&1u)./5+u"r)5-1}y8-1)n-o}47&*}).T.!&(W01&pqr"}/>4"q_
			1;(.88X-&!}022W5-82p!(0/q_
			<0(k4>0A&k]k>&!k;;}T0=&8FFOp)5-1}y8-1)n-o}4>0A&,k[Q}4&)O.>)p"O.>)yN&30+8)"q,kce,k>+88,k;;}FDVFyLTIPZ[DZFyTDOF,k;;}XDEFIWLTyFDVFyLTIPZ[DZFyYJFFJ[q_
kkkkkkkkkkkk4>0A&}1&)L>;5.(K.->)pa,kaq_
	kkkkkkkk4>0A&}1&)K.1-)-.>p;;}/phe,kdjqq_
	kkkkkkkk!(0/}022W5-82p4>0A&q_
	kkkkkkkk<0(k460;7/.)k]k>&!k>&!+-}T0=&8Y[O.>)p"",k"(&1u3.>)1u3.>)s8-1)5+s&:/.()}3>)",k;;}FDVFyLTIPZ[DZFyTDOFq_
			460;7/.)}1&)M;08&pa}eq_
			460;7/.)}1&)L>;5.(K.->)p;;}/pak,aqq_
			460;7/.)}1&)K.1-)-.>p;;}/phe,khqq_
	kkkkkkkk!(0/}022W5-82p460;7/.)q_
kkkkkkkk	<0(k8->&k]k>&!k;;}M/(-)&p"(&1u)./5+u8-1)s=4}/>4"q_
kkkkkkkk	8->&}1&)K.1-)-.>p;;}/pbcb,kshqq_
kkkkkkkk	!(0/}022W5-82p8->&q_
kkkkkkkk	)5-1}y8-1)n-o}!(0/k]k!(0/_
kkkkkkkk	)5-1}y8-1)n-o}80=&8k]k460;7/.)_
		m
		)5-1}y.(2&(K.1pq_
kkkkkkkk)5-1}1&)K.1-)-.>p;;}/psegf,ksefqq_
kkkkkkkk)5-1}y;50>4&E..Apcq_
kkkkm,
kkkky(&>2&(vk3+>;)-.>pql
kkkkm,
kkkk1&)R0;7/.)vk3+>;)-.>p20)0ql
kkkkm,
kkkky;50>4&E..Avk3+>;)-.>p>qlkk
kkkk	)5-1}y0;)-<&E..Ak]k>_
kkkk	1!-);5p>ql
kkkk		;01&kbv
kkkk			)5-1}=)>baa}1&)J/0;-)*pcffq_
kkkk			)5-1}=)>bS}1&)J/0;-)*pbfaq_
kkkk			)5-1}=)>baS}1&)J/0;-)*pbfaq_
kkkk			=(&07_
kkkk		;01&kcv
kkkk			)5-1}=)>baa}1&)J/0;-)*pbfaq_
kkkk			)5-1}=)>bS}1&)J/0;-)*pcffq_
kkkk			)5-1}=)>baS}1&)J/0;-)*pbfaq_
kkkk			=(&07_
kkkk		;01&kdv
kkkk			)5-1}=)>baa}1&)J/0;-)*pbfaq_
kkkk			)5-1}=)>bS}1&)J/0;-)*pbfaq_
kkkk			)5-1}=)>baS}1&)J/0;-)*pcffq_
kkkk			=(&07_
kkkk	m
kkkkkkkk)5-1}y+/20)&R0;7/.)pq_
kkkkm,
kkkky+/20)&R0;7/.)vk3+>;)-.>p;A2,k20)0ql
kkkkkkkk-3p0(4+A&>)1}8&>4)5k]]kcql
kkkkkkkkkkkk)5-1}y20)0R0;7/.)k]k20)0_
kkkkkkkkm&81&l
kkkkkkkkkkkk20)0k]k)5-1}y20)0R0;7/.)_
kkkkkkkkm
kkkk	-3pk20)0kxxk20)0nbokxxk20)0nbo}R1kql
			3.(pk<0(k-k]k20)0nbo}R1}8&>4)5sb_k-{]a_k-sskql
				-3pk)5-1}y0;)-<&E..Ak]]]kbkxxk20)0nbo}R1n-o}=kw]]kbaak||k)5-1}y0;)-<&E..Ak]]]kckxxk20)0nbo}R1n-o}=kw]]kbaaak||k)5-1}y0;)-<&E..Ak]]]kdkxxk20)0nbo}R1n-o}=kw]]kbaaaakqk;.>)->+&_
				3.(pk<0(k6k]k)5-1}y8-1)}8&>4)5sb_k6{]a_k6sskql
					-3pk)5-1}y8-1)n6o}4-2k]]]k20)0nbo}R1n-o}4-2kql
kkkkkkkkkkkkkkkkkkkkkkkk-3pk)5-1}y8-1)n6o}Rkw]]k20)0nbo}R1n-o}Rkql
kkkkkkkkkkkkkkkkkkkkkkkkkkkk)5-1}y8-1)n6o}80=&8};.+>)F.p20)0nbo}R1n-o}R,kcq_
kkkkkkkkkkkkkkkkkkkkkkkkkkkk)5-1}y8-1)n6o}Rk]k20)0nbo}R1n-o}R_
kkkkkkkkkkkkkkkkkkkkkkkkm
					m
				m
			m
			)5-1}y.(2&(K.1pq_
		m
kkkkm,
kkkky.(2&(K.1vk3+>;)-.>pql
kkkk	)5-1}y8-1)}1.()p3+>;)-.>p0,k=ql(&)+(>k0}Rs=}Rmq_
kkkk	3.(p<0(k-])5-1}y8-1)}8&>4)5sb_k-{]a_k-ssql
kkkkkkkkkkkk)5-1}y8-1)n-o}!(0/}1)./L88L;)-.>1pq_
kkkk		<0(k0;)-.>k]k;;}A.<&F.pa}d,k;;}/pea,k-t)5-1}y-)&AQreaqq_
kkkk		)5-1}y8-1)n-o}!(0/}(+>L;)-.>pk0;)-.>kq_
kkkk	m
kkkkm,
kkkk.>D>)&(vk3+>;)-.>pql
kkkkkkkk)5-1}y1+/&(pq_
kkkkkkkkF./Q+W8-&>)}4&)I>1)0>;&pq}022T-1)&>&(pk7W[N}FJKyQHk,k)5-1}y+/20)&R0;7/.),k)5-1q_
kkkkm,
kkkk.>D:-)vk3+>;)-.>pql
kkkkkkkk)5-1}y1+/&(pq_
kkkkkkkkF./Q+W8-&>)}4&)I>1)0>;&pq}(&A.<&T-1)&>&(p)5-1q_
kkkkm
mq_