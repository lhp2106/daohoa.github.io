var MyDialog = cc.Node.extend({

});

var WithdrawMoneyDialog = MHPopupN.extend({
	ctor: function(listener){
		this._super();

		this.listener = listener;

		//
		this.setVisible(false);
		cc.director.getRunningScene().popupLayer.addChild(this);
		this.setCascadeOpacityNodes(this.getChildren());
	},
	hide: function(){
	    this.visible = false;
	},
	show: function(visible){
		this.isShow = visible;
		this.setVisible(visible);
		if( visible ){
			this.setScale(1.1);
	        this.setOpacity(0);
	        this.runAction( cc.scaleTo(0.2, 1) );
	        this.runAction( cc.fadeIn(0.2) );
		}else{
			this.hide();
		}
	},
	showDialog: function(isShow){
		this.show(false);
	},
	setEnableOutSizeClose: function(enable){
		this.enableOutSizeClose = enable;
	},
	onButtonDown: function(event){},
	okButtonHandler: function(){
		this.listener.onWithdrawMoney(this.moneyBet,this.isSitdown);
	},
	cancelButtonHandler: function(){
		this.hideDialog = true;
	    cc.log("hideDiloag");
	    this.hide();
	},
	showWithAnimationScale: function(){
		this.show(true);
	},
	showWithAnimationScaleDelay: function(){
		this.show(true);
	},
	showWithAnimationMove: function(){
		this.show(true);
	},
	setMessage: function(message){
		if(message) message = message.trim();
    	this.messageLabel.setString(message);
	},
	_updateGoldLabel: function(){
		var x = this.gradianSlider.x - this.gradianSlider.width/2;
        x += this.getPercent() / 100.0 * this.gradianSlider.width;
        this.bgMoney.x = x;

        var idx = Math.floor(this.getPercent() / 100.0 * (this._allStep.length - 1) + 0.00005);
        this.moneyLabel.setString(cc.Global.NumberFormat2(this._allStep[idx],2));
        this.moneyBet = this._allStep[idx];
	},
	setPercent: function(percent){
		var x = this.gradianSlider.x - this.gradianSlider.width/2;
	    x += percent / 100.0 * this.gradianSlider.width;
	    this.goldSlider.x = x;
	},
	getPercent: function(){
		var x = this.gradianSlider.x - this.gradianSlider.width/2;
	    var percent = 100* (this.goldSlider.x - x)/this.gradianSlider.width;
	    return percent;
	},
	subHander: function(){
		var idx = Math.floor(this.getPercent() / 100.0 * (this._allStep.length - 1) + 0.00005);
	    if(idx > 0){
	        idx--;
	        var rate = idx / (this._allStep.length - 1);
	        this.setPercent(rate * 100.0);
	        this._updateGoldLabel();
	    }
	},
	addHander: function(){
		var idx = Math.floor(this.getPercent() / 100.0 * (this._allStep.length - 1) + 0.00005);
	    if(idx < this._allStep.length - 1){
	        idx++;
	        var rate = idx / (this._allStep.length - 1);
	        this.setPercent(rate * 100.0);
	        this._updateGoldLabel();
	    }
	},
	_initSlotType1: function(){

	},
	_initSlotType2: function(){

	},
	setData: function(money, min, max, step, isSitdown){
		this.isSitdown = isSitdown;
        this.labelMyMoney.setString(cc.Global.NumberFormat2(money,2));
        var b = [];
        b.push(min);
        var val = min;
        while(val < max){
            val+=step;
            if(val <= max) b.push(val);
            else b.push(max);
        }

        this.moneyBet = b[b.length-1];
        this._initSlider(b[0], b[b.length-1], b);
        this.setPercent(100.0);
        this._updateGoldLabel();
	},
	_initSlider: function(min, max, step){
		var thiz = this;
        this._allStep = step;
        if( this.initDone ){
            thiz._updateGoldLabel();
            return;
        }
        this.initDone = true;

        var subBt = MyHelper.createButton("tru.png", true,function () {
            if(thiz.subHander ) thiz.subHander();
        }, false, cc.size(150, 60) , [10, 10, 10, 10] );
        subBt.setPosition(cc.p2(50  , this.bg.height/2  -50));
        subBt.displayGroup = null;
        this.bg.addChild(subBt);
        //MyHelper.addLblButton(subBt, "Úp", 16);

        var addBt = MyHelper.createButton("add.png", true,function () {
            if(thiz.addHander ) thiz.addHander();
        }, false, cc.size(150, 60) , [10, 10, 10, 10] );

        addBt.setPosition(cc.p2(650 , this.bg.height/2 -50));
        addBt.displayGroup = null;
        this.bg.addChild(addBt);


        var bgSlider = PIXI.Sprite.fromFrame("bg-slider.png");
        bgSlider.setAnchorPoint(.5,.5);
        bgSlider.setPosition(cc.p2(this.bg.width/2, this.bg.height/2-50));
        this.bg.addChild(bgSlider);
        this.bgSlider = bgSlider;


        var gradianSlider = PIXI.Sprite.fromFrame("raise_load_hor.png");
        gradianSlider.setAnchorPoint(.5,.5);
        gradianSlider.setPosition(bgSlider.x, bgSlider.y);
        this.bg.addChild(gradianSlider);
        this.gradianSlider = gradianSlider;

        var goldSlider = PIXI.Sprite.fromFrame("icon-slider.png");
	    goldSlider.setAnchorPoint(.5,.5);
	    goldSlider.setPosition(bgSlider.x, bgSlider.y);
	    this.bg.addChild(goldSlider);
	    this.goldSlider = goldSlider;

	    var minLabel = cc.LabelTTF(cc.Global.NumberFormat2(min), cc.res.font.Arial, 32, "null", "yellow");
	    minLabel.setAnchorPoint(0.5, 0.5);
	    minLabel.setPosition(bgSlider.x -bgSlider.width/2, bgSlider.y + 70);
	    this.bg.addChild(minLabel);

	    var maxLabel = cc.LabelTTF(cc.Global.NumberFormat2(max), cc.res.font.Arial, 32, "null", "yellow");
	    maxLabel.setAnchorPoint(0.5, 0.5);
	    maxLabel.setPosition(bgSlider.x + bgSlider.width/2, bgSlider.y + 70);
	    this.bg.addChild(maxLabel);


        var bgMoney = PIXI.Sprite.fromFrame("bg_money.png");
        bgMoney.setAnchorPoint(.5,.5);
        bgMoney.setPosition(300, bgSlider.y  -80);
        this.bg.addChild(bgMoney);
        this.bgMoney = bgMoney;

        var moneyLabel = cc.LabelTTF("100k", cc.res.font.Arial, 24, null, "black");
        moneyLabel.setAnchor(.5,.5);
        moneyLabel.setPosition(cc.p2(bgMoney.width/2 - 80, bgMoney.height/2 -60));
        bgMoney.addChild(moneyLabel);
        //moneyLabel.setScale(0.7);
        this.moneyLabel = moneyLabel;

        var onButtonDown = function(touch, event){
        	thiz.data = event.data;
            thiz.preTouchPoint = touch.getLocation();
            thiz.isTouched = true;
            thiz.isMoved = false;
            thiz.isAcpetTouch = true;
        };

        var onButtonMove = function(touch, event){
        	if(!thiz.isAcpetTouch ) return;
            var p = touch.getLocation();
            if(!thiz.isMoved){
                if(cc.pDistance(thiz.preTouchPoint, p) < 5.0){
                    return;
                }
                else{
                    thiz.isMoved = true;
                }
            }

            thiz.goldSlider.x += p.x - thiz.preTouchPoint.x;
            var min = thiz.gradianSlider.x - thiz.gradianSlider.width/2;
            var max = thiz.gradianSlider.x + thiz.gradianSlider.width/2;
            if(thiz.goldSlider.x > max ) thiz.goldSlider.x = max;
            if(thiz.goldSlider.x < min ) thiz.goldSlider.x = min;
            //thiz.goldSlider.y += p.y - thiz.preTouchPoint.y;
            //cc.log("thiz.goldSlider.x "+thiz.goldSlider.x);
            thiz._updateGoldLabel();

            thiz.preTouchPoint = p;
		};

		var onButtonUp = function(touch, event){
			thiz.isTouched = false;
            thiz.isAcpetTouch = false;
		};

        cc.eventManager.addListener({
            event: cc.EventListener.TOUCH_ONE_BY_ONE,
            swallowTouches: true,
            onTouchBegan: onButtonDown,
            onTouchMoved: onButtonMove,
            onTouchEnded: onButtonUp
        }, this.goldSlider);


        this._updateGoldLabel();

        var chbAutoRutTien = new newui.Button(["#solo_checked.png", "#solo_check.png"], function(btn){
        	thiz.listener.onListenerAutoRutTien(btn.getActive());
        });
	    chbAutoRutTien.displayGroup = MyPixi.popupLayer;
	    chbAutoRutTien.setTitleText("Tự động mua vào khi hết tiền");

	    chbAutoRutTien.setAnchorPoint(.5,.5);
	    chbAutoRutTien.setPosition(this.bg.width/4,this.labelMyMoney.y + 60);
	    this.bg.addChild(chbAutoRutTien);
	    //chbAutoRutTien.displayGroup = MyPixi.gamePlayerLayer;
	    chbAutoRutTien.visible = true;
	}

})